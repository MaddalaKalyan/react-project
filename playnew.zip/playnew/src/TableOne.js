import {React,useState} from 'react'
import { Container, Row,Col,Form,Card,} from 'react-bootstrap'
import { Outlet,useNavigate,Link } from 'react-router-dom'

const TableOne = () => {
  const navigate = useNavigate();
  const [show, setShow] = useState(false);
  
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
 
  return (
    <Container style={{'overflow':'scroll',"height":"850px"}}>
        <Row>
           <Card>
             <Row>
               <Col className='d-flex'>  
                  <button onClick={() => navigate(-1)} className="bi bi-arrow-left"></button>
                    <Form.Control
                      type="text"
                      id="inputPassword5"
                      aria-describedby="passwordHelpBlock"
                      placeholder="Big Deal Rule"/>
                     <span className='bi bi-unlock' style={{"fontSize":"30px","color":"red"}}></span>
                    <span>@Deals</span> 
              </Col>
            </Row>
        <br/>
        <Row>
          {/* <Link>+ Description</Link> */}
        </Row>
          <br/>
         <Card>
           <Card.Body>
             <Card.Title> <Row style={{"display":"flex"}}>
               <Col>
                 <h4 className='d-flex justify-content-start '>1.Trigger</h4></Col>
                  <Col><Link  to="AddedRow"className='d-flex justify-content-end bi bi-pencil'/></Col>
              </Row>
              </Card.Title>
           {/* <Card.Text> Trigger this workflow when a deal is <Link>Created or Edited</Link></Card.Text> */}
   
      </Card.Body>
   
    </Card>
     
        
          <br/>
      
        <Card style={{ width: '35rem' }}>
           
      <Card.Body>
        <Card.Title> 
          <Row style={{"display":"flex"}}>
          <Col><h4 className='d-flex justify-content-start '>2.Conditions</h4></Col>
          <Col><Link to="FarmFunction"className='d-flex justify-content-end bi bi-pencil'>
        </Link></Col>
          </Row>
          
        </Card.Title>
      
        <Card.Text>
        Trigger this workflow when a deal is <Link to="FarmThree">Created or Edited</Link>
       
        </Card.Text>
      
      </Card.Body>
      
        </Card>

    
        
      
        </Card>
        </Row>
        <Row><Outlet/></Row>
     </Container>
  )
}

export default TableOne
