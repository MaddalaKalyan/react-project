import {React,useState} from "react";
import { Container,Row,Form, Col, Card ,Button} from "react-bootstrap";
import { useNavigate } from "react-router-dom";



const TriggerPage =() => {
    const navigate = useNavigate();
    const [show, setShow] = useState(false);
    
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
   



    return(
        <Container>
            
                   <Card style={{ width: '35rem' }}>
                     <Card.Body>
                       <Row>
                          <p> Trigger this workflow when a deals is created</p>
                            <Col className="d-flex"> <Form.Check type="radio" aria-label="radio 1"/> Created</Col>
                            <Col className="d-flex"> <Form.Check type="radio" aria-label="radio 1"/> Created or Edited</Col>
                            <Col className="d-flex"> <Form.Check type="radio" aria-label="radio 1"/> Edited</Col>
                     </Row>
                   </Card.Body>
             
                  <Row>
                  <Col className='d-flex justify-content-end'><Button variant="success" onClick={handleClose } style={{"border-radius":'100px 100px 100px 100px'}}> save</Button> </Col>
                  </Row>
                 
                </Card>
        </Container>
    )
}
export default TriggerPage