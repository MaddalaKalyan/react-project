import React from 'react'
import { Col, Container, Row } from 'react-bootstrap';
import {  Link, } from 'react-router-dom';


function Settings() {
  return (
   <Container>
     <Row className='d-flex'>
        <Col>
           <ul>
           <Link to="/UsersandControls"><li><span>UsersandControls</span></li></Link>
            <li><span>UsersandControls</span></li>
            <li><span>UsersandControls</span></li>
            <li><span>UsersandControls</span></li>
           </ul>
        </Col>
        <Col>2
            
        </Col>
     </Row>
   </Container>
  )
}

export default Settings
