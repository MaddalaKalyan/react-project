import React from 'react'
import { Col, Container,Form, Row } from 'react-bootstrap'
import { Table,Tbody, Thead, Tr ,Th} from 'react-super-responsive-table'
import { Outlet } from 'react-router'

function TodaysTasks() {
  return (
    <Container>
    <Row >
     <Col>
     <Table style={{"border":"2px solid #E5EBEF","width":"100%"}} striped bordered hover >
       <Thead>
           <Tr>
               <Th> <Form.Check required   /></Th>
               <Th>Task Name <span className='bi bi-arrow-down-up'></span></Th>
               <Th>Due Date <span className='bi bi-arrow-down-up'></span></Th>
               <Th>Status <span className='bi bi-arrow-down-up'></span></Th>
               <Th>Priority <span className='bi bi-arrow-down-up'></span></Th>
               <Th>Related To <span className='bi bi-arrow-down-up'></span></Th>
               <Th>Owner <span className='bi bi-arrow-down-up'></span></Th>
               <Th></Th>
               <Th><span className='bi bi-plus'></span></Th>
           </Tr>
       </Thead>
       <Tbody>
          <Tr>
         
          </Tr>
       </Tbody>
    </Table>
     </Col>
    </Row>
     
     <Outlet/>
   </Container>
  )
}

export default TodaysTasks
