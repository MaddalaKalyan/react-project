import React from 'react'
import { Col, Container,Form, Row } from 'react-bootstrap'
import { Table,Tbody, Thead, Tr ,Th} from 'react-super-responsive-table'
import { Outlet } from 'react-router'

function RecentlyCreatedContacts() {
  return (
    <Container>
    <Row >
     <Col>
     <Table style={{"border":"2px solid #E5EBEF","width":"100%"}} striped bordered hover >
       <Thead>
           <Tr>
               <Th> <Form.Check required   /></Th>
               <Th>Contact Name <span className='bi bi-arrow-down-up'></span></Th>
               <Th>Company Name <span className='bi bi-arrow-down-up'></span></Th>
               <Th>Email <span className='bi bi-arrow-down-up'></span></Th>
               <Th>Phone <span className='bi bi-arrow-down-up'></span></Th>
               <Th>Contact Owner <span className='bi bi-arrow-down-up'></span></Th>
               <Th></Th>
               <Th><span className='bi bi-plus'></span></Th>
           </Tr>
       </Thead>
       <Tbody>
          <Tr>
         
          </Tr>
       </Tbody>
    </Table>
     </Col>
    </Row>
     
     <Outlet/>
   </Container>
  )
}

export default RecentlyCreatedContacts
