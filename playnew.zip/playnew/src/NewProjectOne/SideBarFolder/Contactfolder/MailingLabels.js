import React from 'react'
import { Col, Container,Form, Row } from 'react-bootstrap'
import { Table,Tbody, Thead, Tr ,Th} from 'react-super-responsive-table'
import { Outlet } from 'react-router'

function MailingLabels() {
  return (
    <Container>
     <Row >
      <Col>
      <Table style={{"border":"2px solid #E5EBEF","width":"100%"}} striped bordered hover >
        <Thead>
            <Tr>
                <Th> <Form.Check required   /></Th>
                <Th>Contact Name <span className='bi bi-arrow-down-up'></span></Th>
                <Th>Mailing Street <span className='bi bi-arrow-down-up'></span></Th>
                <Th>Mailing City<span className='bi bi-arrow-down-up'></span></Th>
                <Th>Mailing state <span className='bi bi-arrow-down-up'></span></Th>
                <Th>Mailing Country <span className='bi bi-arrow-down-up'></span></Th>
                <Th>Mailing Zip <span className='bi bi-arrow-down-up'></span></Th>
                <Th><span className='bi bi-plus'></span></Th>
            </Tr>
        </Thead>
        <Tbody>
           <Tr>
          
           </Tr>
        </Tbody>
     </Table>
      </Col>
     </Row>
      
      <Outlet/>
    </Container>
  )
}

export default MailingLabels
