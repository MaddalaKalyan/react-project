import React from 'react'
import  { useState } from 'react';
import Offcanvas from 'react-bootstrap/Offcanvas';
import { Col, Container,  Row ,Form,Button,Nav,NavDropdown} from 'react-bootstrap';
import { Link, } from 'react-router-dom';
import './Call.css'
function OffCanvasExample({ name, ...props }) {
    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
  
    return (
      <> 
        <Button variant="success" onClick={handleShow} className="me-2 CallButton">
         + Call
        </Button>
        <Nav className="justify-content-end flex-grow-1 TaskNav" >
                <NavDropdown  className='CallDropDown'>
                <NavDropdown.Item href="#action3">Import Companies</NavDropdown.Item>
                <NavDropdown.Item href="#action4">Import Notes</NavDropdown.Item>
                </NavDropdown>
                </Nav>
        <Offcanvas show={show} onHide={handleClose} {...props}>
          <Offcanvas.Header closeButton>
            <Offcanvas.Title>Create Call</Offcanvas.Title>
          </Offcanvas.Header>
          <hr/>
          <Offcanvas.Body>
          <Form>
                          <Row className='d-flex'>
                            <Col><h6>Call Information</h6></Col>
                            <Col><p>Owner : </p></Col>
                          </Row>
                        <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                          <Row>
                            <Col xs="3" lg="4"><Form.Label>To/From</Form.Label></Col>
                            <Col xs="3" lg="8"><Form.Control
                              type="text"
                              placeholder="Enter Product Name"
                              autoFocus
                              /></Col>
                          </Row>
                          </Form.Group>
                          <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                          <Row>
                            <Col xs="3" lg="4"><Form.Label>Call Start Time</Form.Label></Col>
                            <Col xs="3" lg="8">
                                <Row className='d-flex'>
                                    <Col lg="6"><Form.Control type="date"  autoFocus/></Col>
                                    <Col lg="6"><Form.Control type="time"  autoFocus/></Col>
                                </Row>
                            </Col>
                          </Row>
                          </Form.Group>
                          <Form.Group className="mb-3" id="formGridCheckbox">
                          <Form.Check type="checkbox" label="Remainder" />
                          </Form.Group>
                          <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                          <Row>
                            <Col xs="3" lg="4"><Form.Label>Call Type</Form.Label></Col>
                            <Col xs="3" lg="8"><Form.Select disabled aria-label="Default select example">
                                <option>-None-</option>
                                <option value="1">Hardware</option>
                                <option value="2">Software</option>
                                <option value="3">CRM Applications</option>
                            </Form.Select></Col>
                          </Row>
                          </Form.Group> 
                          <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                          <Row>
                            <Col xs="3" lg="4"><Form.Label>Related To</Form.Label></Col>
                            <Col xs="3" lg="8"><Form.Control
                              type="text"
                              placeholder="Search Companies/Deals"
                              autoFocus
                              /></Col>
                          </Row>
                          </Form.Group>
                          <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                          <Row>
                            <Col xs="3" lg="4"><Form.Label>Call Agenda</Form.Label></Col>
                            <Col xs="3" lg="8"><Form.Control
                              type="text"
                              placeholder="A few words about this product"
                              autoFocus
                              /></Col>
                          </Row>
                          </Form.Group>
                         
                        </Form>
                        <br/>
                        <hr/>
                        <Row className='d-flex justify-content-between'>
                          <Col xs="3" lg="6" ><Link to="/FieldSettings" >Field Settings</Link></Col>
                          <Col xs="3" lg="6" className='d-flex'>
                                <Button variant="white" onClick={handleClose} style={{"borderRadius":"100px 100px 100px 100px"}}>
                                  Cancel
                                </Button>
                              <Button variant="success" onClick={handleClose} style={{"borderRadius":"100px 100px 100px 100px"}}>
                                Save 
                              </Button>
                          </Col>
                        </Row>
          </Offcanvas.Body>
        </Offcanvas>
      </>
    );
  }

  
function Call() {
  return (
    <Container>
        <Row>
            <Col>
            {[ 'end' ].map((placement, idx) => (
                      <OffCanvasExample key={idx} placement={placement} name={placement} />
                     ))}
            </Col>
        </Row>
    </Container>
  )
}

export default Call
