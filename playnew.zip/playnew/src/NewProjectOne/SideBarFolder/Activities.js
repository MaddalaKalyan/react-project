import React from 'react';
import './Activities.css';
import { Col, Container, Row,} from 'react-bootstrap';
import {  Link, Outlet } from 'react-router-dom';
import Task from './Task';
import Event from './Event';
import Call from './Call';


function Activities() {
  return (
    <Container fluid className='ActivitiesContainer'>
      <Row className='ActivitiesRow'>
        <Col sm="6" lg="6" className='d-flex ActivitesCol1'>
            <Link to="Tasks">Tasks</Link>
            <Link to="Events">Events</Link>
            <Link to="Calls">Calls</Link>
        </Col>
        
        <Col sm="6" lg="6" className='d-flex justify-content-end ActivitesCol2'>
             <Col sm="4" lg="3" className='ActivitesCol3 d-flex justify-content-end'><Task/>

            </Col>
             <Col sm="4" lg="3" className='d-flex ActivitesCol3 justify-content-end'><Event/></Col>
             <Col sm="4" lg="3" className='d-flex ActivitesCol3 justify-content-end'><Call/>
             </Col>
        </Col>
      </Row>
    <Row>
     <Outlet/>
    </Row>
   
  </Container>
  )
}

export default Activities
