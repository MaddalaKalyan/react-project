import React from 'react';
import { Col, Form,Button, Container } from 'react-bootstrap';

function Signin() {
  return (
    <div>
      <Container>
        <Form noValidate>
        <div className='p-4'>
        <Col>
           <Form.Control type="text" name="username" placeholder="Full Name" /> 
        </Col><br/>
        <Col>
           <Form.Control type="email" name="email" placeholder="Email" /> 
        </Col><br/>
        <Col>
           <Form.Control type="password" name="password" placeholder="Password" /> 
        </Col><br/>
        <Col>
          <Form.Check type="checkbox" name="checkbox" label="Check me out" />
        </Col><br/>
        <Button variant="primary" type="submit">
        Submit
      </Button>
        </div>
     </Form>
      </Container>
    </div>
  )
}

export default Signin
