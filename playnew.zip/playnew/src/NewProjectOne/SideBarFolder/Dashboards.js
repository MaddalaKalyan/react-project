import React from 'react';
import { Col, Container, Row,Dropdown} from 'react-bootstrap';
import './Dashboards.css';
import { Link, Outlet } from 'react-router-dom'


function Dashboards() {
  return (
    <Container>
        <Row className='dashboard d-flex justify-content-between'>
        <Col xs="3" lg="2" className='d-flex'>
            <Dropdown className="d-inline mx-2 overview" >
                <Dropdown.Toggle id="dropdown-autoclose-true" className='btn btn-light' style={{"borderRadius":"100px 100px 100px 100px","marginTop":"5px","border":"1px solid #23ae73"}}>
                     Overview
                    </Dropdown.Toggle>
                    <Dropdown.Menu>
                    <Dropdown.Item ><Link to="Overview">Overview</Link></Dropdown.Item>
                    <Dropdown.Item ><Link to="DealsDashboard">DealsDashboard</Link></Dropdown.Item>
                    <Dropdown.Item ><Link to="TaskDashboard">TaskDashboard</Link></Dropdown.Item>
                    <Dropdown.Item ><Link to="EventsDashboard">EventsDashboard</Link></Dropdown.Item>
                    <Dropdown.Item ><Link to="CallAnalytics">CallAnalytics</Link></Dropdown.Item>
                    <Dropdown.Item ><Link to="EmailAnalytics">EmailAnalytics</Link></Dropdown.Item>
                    <Dropdown.Item ><Link to="CallsbyUsers">CallsbyUsers</Link></Dropdown.Item>
                </Dropdown.Menu>
            </Dropdown>
             <span className='bi bi-lock'></span>
            </Col>
            
            <Col lg={{span:6,offset:4}} className='d-flex justify-content-end'>
                <span className='bi bi-arrow-clockwise'></span>
                <Dropdown className="d-inline mx-2 component" >
                <Dropdown.Toggle id="dropdown-autoclose-true" className='btn btn-light' style={{"borderRadius":"100px 100px 100px 100px","marginTop":"5px","border":"1px solid #23ae73"}}>
                     + Component
                    </Dropdown.Toggle>
                    <Dropdown.Menu>
                    <Dropdown.Item ><Link to="">KPI</Link></Dropdown.Item>
                    <Dropdown.Item ><Link to="DashboardCharts">Charts</Link></Dropdown.Item>
                </Dropdown.Menu>
            </Dropdown>
            <Dropdown className="d-inline mx-2 component" >
                <Dropdown.Toggle id="dropdown-autoclose-true" className='btn btn-light' style={{"borderRadius":"100px 100px 100px 100px","marginTop":"5px","border":"1px solid #23ae73"}}>
                    
                    </Dropdown.Toggle>
                    <Dropdown.Menu>
                    <Dropdown.Item ><Link to="">View in Full Screen</Link></Dropdown.Item>
                    <Dropdown.Item ><Link to="">Delete</Link></Dropdown.Item>
                </Dropdown.Menu>
            </Dropdown>
           
            </Col>
         </Row>
         <br/>
     <Row>
      <Outlet/>
     </Row>
    </Container>
  )
}

export default Dashboards
