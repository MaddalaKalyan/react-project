import React from 'react'
import './Contacts.css'

import { Col, Container, Row,Button,Nav,NavDropdown,Dropdown } from 'react-bootstrap'

import { Link, Outlet } from 'react-router-dom'

function Contacts() {
   
  return (
   <Container fluid className='ContactContainer' >
     <Row className='contactRow d-flex justify-content-between'>
        <Col xs="3" lg="1" className='d-flex class1'>
        <Button variant='light' className='bi bi-filter class1-5' style={{"borderRadius":"100px 100px 100px 100px"}}></Button> 
        </Col>
        <Col xs="3" lg="3">
        <Dropdown className="d-inline mx-2 DropDown" >
        <Dropdown.Toggle id="dropdown-autoclose-true" className='btn btn-light DropDown1' style={{"borderRadius":"100px 100px 100px 100px","marginTop":"5px"}}>
            AllContacts
        </Dropdown.Toggle>
        <Dropdown.Menu>
          <Dropdown.Item ><Link to="allcontacts">AllContacts</Link></Dropdown.Item>
          <Dropdown.Item ><Link to="mailinglabels">Mailinglabels</Link></Dropdown.Item>
          <Dropdown.Item ><Link to="mycontacts">MyContacts</Link></Dropdown.Item>
          <Dropdown.Item ><Link to="newLastWeek">NewLastWeek</Link></Dropdown.Item>
          <Dropdown.Item ><Link to="newThisWeek">NewThisWeek</Link></Dropdown.Item>
          <Dropdown.Item ><Link to="reacentlyCreatedContacts">ReacentlyCreatedContacts</Link></Dropdown.Item>
          <Dropdown.Item ><Link to="recentlyModifiedContacts">RecentlyModifiedContacts</Link></Dropdown.Item>
          <Dropdown.Item ><Link to="notYetViewed">NotYetViewed</Link></Dropdown.Item>
          <Dropdown.Item ><Link to="unsubscribedContacts">UnsubscribedContacts</Link></Dropdown.Item>
        </Dropdown.Menu>
      </Dropdown>
        </Col>
        <Col xs="3" lg="4">
        
        </Col>
       <Col xs="3" lg="2" style={{"width":"25%"}}>
       <Row  className='d-flex justify-content-end ContactRow2 '>
           <Col xs="6" lg="8" className='d-flex justify-content-end ContactCol1'>
          
          <Button variant='success'  className='ContactBu1 bi bi-plus' >Company</Button>
             <Nav className="justify-content-end flex-grow-1 pe-3 ContactNav1" >
             <NavDropdown  className='ContactNavDropDown1'>
            <NavDropdown.Item href="#action3">Import Companies</NavDropdown.Item>
            <NavDropdown.Item href="#action4">Import Notes</NavDropdown.Item>
            </NavDropdown>
          </Nav>
            <Col xs="3" lg="4" className='d-flex class2 justify-content-end'>
           <Button variant='light' className='bi bi-three-dots-vertical' style={{"borderRadius":"100px 100px 100px 100px"}}></Button> 
       </Col>
      </Col>
   
           </Row>
       </Col>
            
          
           
       
     </Row>
     <br/>
      
     

     <br/>
     <Row>
      <Outlet/>
     </Row>
    
   </Container>
  )
}

export default Contacts
