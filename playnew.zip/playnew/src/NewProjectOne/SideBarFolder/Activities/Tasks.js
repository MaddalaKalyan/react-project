import React from 'react'
import { Col, Container, Row ,Dropdown, Button } from 'react-bootstrap'
import { Link, Outlet } from 'react-router-dom'

function Tasks() {
  return (
    <Container fluid>
    <Row className='contact d-flex justify-content-between'>
       <Col xs="3" lg="1" className='d-flex class1'>
         <Button variant='success' className='bi bi-filter' style={{"borderRadius":"100px 100px 100px 100px"}}></Button> 
       </Col>
       <Col xs="3" lg="3">
       <Dropdown className="d-inline mx-2">
       <Dropdown.Toggle id="dropdown-autoclose-true" className='btn btn-success' style={{"borderRadius":"100px 100px 100px 100px","marginTop":"5px"}}>
       AllContacts
       </Dropdown.Toggle>
       
       <Dropdown.Menu>
       <h5>PUBLIC VIEWS</h5>
       <br/>
         <Dropdown.Item ><Link to="AllTasks">AllTasks</Link></Dropdown.Item>
         <Dropdown.Item ><Link to="ClosedTasks">ClosedTasks</Link></Dropdown.Item>
         <Dropdown.Item ><Link to="MyOpenTasks">MyOpenTasks</Link></Dropdown.Item>
         <Dropdown.Item ><Link to="Next7DaysOverdue">Next7DaysOverdue</Link></Dropdown.Item>
         <Dropdown.Item ><Link to="Opentasks">Opentasks</Link></Dropdown.Item>
         <Dropdown.Item ><Link to="OverdueTasks">OverdueTasks</Link></Dropdown.Item>
         <Dropdown.Item ><Link to="TodayOverdueTasks">TodayOverdueTasks</Link></Dropdown.Item>
         <Dropdown.Item ><Link to="TodaysTasks">TodaysTasks</Link></Dropdown.Item>
         <Dropdown.Item ><Link to="TomorrowTasks">TomorrowTasks</Link></Dropdown.Item>
       </Dropdown.Menu>
     </Dropdown>
       </Col>
       <Col xs="3" lg="6">
       
       </Col>
       <Col xs="3" lg="1" >
          
          </Col>
      
       <Col xs="3" lg="1" className='d-flex class2 justify-content-end'>
       <Button variant='success' className='bi bi-three-dots-vertical' style={{"borderRadius":"100px 100px 100px 100px"}}></Button> 
       </Col>
    </Row>
    <Row>
     <Outlet/>
    </Row>
   
  </Container>
  )
}

export default Tasks
