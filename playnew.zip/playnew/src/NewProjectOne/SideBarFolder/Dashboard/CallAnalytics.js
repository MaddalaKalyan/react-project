import React from 'react'
import { Card, Col, Container, Row } from 'react-bootstrap'

function CallAnalytics() {
  return (
    <Container>
     <br/>
    <Row className='d-flex '>
       <Col xs="3" lg="3" >
            <Card style={{"height":"150px"}}>
            <Card.Body>
                <Card.Title>Calls Completed - This Month </Card.Title>
                    <Card.Text>
                    <p style={{"marginTop":"30px","marginLeft":"40px"}}>No data available1</p>
                    </Card.Text>
                </Card.Body>
            </Card>
        </Col>
        <Col xs="3" lg="3" >
            <Card  style={{"height":"150px"}}>
            <Card.Body>
                <Card.Title>Upcoming Calls - This Month </Card.Title>
                    <Card.Text>
                      <p style={{"marginTop":"30px","marginLeft":"40px"}}>No data available1</p>
                    </Card.Text>
                </Card.Body>
            </Card>
        </Col>
        <Col xs="3" lg="3">
            <Card  style={{"height":"150px"}}>
            <Card.Body>
                <Card.Title>Inbound Calls - This Month </Card.Title>
                    <Card.Text>
                    <p style={{"marginTop":"30px","marginLeft":"40px"}}>No data available1</p>
                    </Card.Text>
                </Card.Body>
            </Card>
        </Col>
        <Col xs="3" lg="3">
            <Card  style={{"height":"150px"}}>
            <Card.Body>
                <Card.Title>Outbound Calls - This Month </Card.Title>
                    <Card.Text>
                    <p style={{"marginTop":"30px","marginLeft":"40px"}}>No data available1</p>
                    </Card.Text>
                </Card.Body>
            </Card>
        </Col>
    </Row>
    <br/>
    <Row className='d-flex'>
       <Col xs="3" lg="3">
            <Card style={{"height":"150px"}}>
            <Card.Body>
                <Card.Title>Inbound Seconds - This Month </Card.Title>
                    <Card.Text>
                    <h1 className='d-flex'>
                    <span>0</span>
                    <span className='bi bi-caret-down-fill' style={{"color":"red","fontSize":"20px","marginTop":"14px"}}>100%</span></h1>
                    <p>Last Month: 1</p>
                    </Card.Text>
                </Card.Body>
            </Card>
        </Col>
        <Col xs="3" lg="3">
            <Card  style={{"height":"150px"}}>
            <Card.Body>
                <Card.Title>Outbound Seconds - This Month </Card.Title>
                    <Card.Text>
                      <p style={{"marginTop":"30px","marginLeft":"40px"}}>No data available1</p>
                    </Card.Text>
                </Card.Body>
            </Card>
        </Col>
        <Col xs="3" lg="3">
            <Card  style={{"height":"150px"}}>
            <Card.Body>
                <Card.Title>Missed Calls - This Month </Card.Title>
                    <Card.Text>
                    <p style={{"marginTop":"30px","marginLeft":"40px"}}>No data available1</p>
                    </Card.Text>
                </Card.Body>
            </Card>
        </Col>
        <Col xs="3" lg="3">
            <Card  style={{"height":"150px"}}>
            <Card.Body>
                <Card.Title>Average Call duration (seconds) </Card.Title>
                    <Card.Text>
                    <p style={{"marginTop":"30px","marginLeft":"40px"}}>No data available1</p>
                    </Card.Text>
                </Card.Body>
            </Card>
        </Col>
    </Row>
   <br/>
</Container>
  )
}

export default CallAnalytics
