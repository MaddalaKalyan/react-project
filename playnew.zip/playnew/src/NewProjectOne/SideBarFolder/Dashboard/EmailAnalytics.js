import React from 'react'
import { Card, Col, Container, Row } from 'react-bootstrap'

function EmailAnalytics() {
  return (
    <Container>
    <Row className='d-flex'>
       <Col xs="3" lg="3">
            <Card style={{"height":"150px"}}>
            <Card.Body>
                <Card.Title>Emails Sent - This Month </Card.Title>
                    <Card.Text>
                    <p style={{"marginTop":"30px","marginLeft":"40px"}}>No data available1</p>
                    </Card.Text>
                </Card.Body>
            </Card>
        </Col>
        <Col xs="3" lg="3">
            <Card  style={{"height":"150px"}}>
            <Card.Body>
                <Card.Title>Emails Opened - This Month </Card.Title>
                    <Card.Text>
                      <p style={{"marginTop":"30px","marginLeft":"40px"}}>No data available1</p>
                    </Card.Text>
                </Card.Body>
            </Card>
        </Col>
        <Col xs="3" lg="3">
            <Card  style={{"height":"150px"}}>
            <Card.Body>
                <Card.Title>Emails Clicked - This Month </Card.Title>
                    <Card.Text>
                    <p style={{"marginTop":"30px","marginLeft":"40px"}}>No data available1</p>
                    </Card.Text>
                </Card.Body>
            </Card>
        </Col>
    </Row>
    <br/>
    <Row className='d-flex'>
       <Col xs="3" lg="3">
            <Card style={{"height":"300px"}}>
            <Card.Body>
                <Card.Title>Users vs Emails Sent </Card.Title>
                    <Card.Text>
                    <h1 className='d-flex'>
                    <span>0</span>
                    <span className='bi bi-caret-down-fill' style={{"color":"red","fontSize":"20px","marginTop":"14px"}}>100%</span></h1>
                    <p>Last Month: 1</p>
                    </Card.Text>
                </Card.Body>
            </Card>
        </Col>
        <Col xs="3" lg="3">
            <Card  style={{"height":"300px"}}>
            <Card.Body>
                <Card.Title>Users vs Emails Opened </Card.Title>
                    <Card.Text>
                      <p style={{"marginTop":"30px","marginLeft":"40px"}}>No data available1</p>
                    </Card.Text>
                </Card.Body>
            </Card>
        </Col>
        <Col xs="3" lg="3">
            <Card  style={{"height":"300px"}}>
            <Card.Body>
                <Card.Title>Users vs Emails Clicked </Card.Title>
                    <Card.Text>
                    <p style={{"marginTop":"30px","marginLeft":"40px"}}>No data available1</p>
                    </Card.Text>
                </Card.Body>
            </Card>
        </Col>
    </Row>
   <br/>
</Container>
  )
}

export default EmailAnalytics
