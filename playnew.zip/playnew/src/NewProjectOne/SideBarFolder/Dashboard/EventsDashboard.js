import React from 'react'
import { Card, Col, Container, Row } from 'react-bootstrap';

function EventsDashboard() {
  return (
    <Container>
    <br/>
    <Row className='d-flex'>
       <Col xs="3" lg="3">
            <Card style={{"height":"150px"}}>
            <Card.Body>
                <Card.Title>Events Created - This Month </Card.Title>
                    <Card.Text>
                    <h1 className='d-flex'>
                    <span>0</span>
                    <span className='bi bi-caret-down-fill' style={{"color":"red","fontSize":"20px","marginTop":"14px"}}>100%</span></h1>
                    <p>Last Month: 1</p>
                    </Card.Text>
                </Card.Body>
            </Card>
        </Col>
        <Col xs="3" lg="3">
            <Card  style={{"height":"150px"}}>
            <Card.Body>
                <Card.Title>Events Completed - This Month </Card.Title>
                    <Card.Text>
                      <p style={{"marginTop":"30px","marginLeft":"40px"}}>No data available1</p>
                    </Card.Text>
                </Card.Body>
            </Card>
        </Col>
        <Col xs="3" lg="3">
            <Card  style={{"height":"150px"}}>
            <Card.Body>
                <Card.Title>Upcoming Events - This Month </Card.Title>
                    <Card.Text>
                    <p style={{"marginTop":"30px","marginLeft":"40px"}}>No data available1</p>
                    </Card.Text>
                </Card.Body>
            </Card>
        </Col>
        <Col xs="3" lg="3">
        <Card style={{"height":"150px"}}>
            <Card.Body>
                <Card.Title>Check ins - This Month </Card.Title>
                    <Card.Text>
                    <h1 className='d-flex'>
                    <span>0</span>
                    <span className='bi bi-caret-down-fill' style={{"color":"red","fontSize":"20px","marginTop":"14px"}}>100%</span></h1>
                    <p>Last Month: 1</p>
                    </Card.Text>
                </Card.Body>
            </Card>
        </Col>
    </Row>
    <br/>
   <Row className='d-flex'>
    <Col xs="3" lg="5">
    <Card style={{"height":"250px"}}>
            <Card.Body>
                <Card.Title>Top 5 Users by Completed Events </Card.Title>
                    <Card.Text>
                    <p style={{"marginTop":"100px","marginLeft":"100px"}}>No data available1</p>
                    </Card.Text>
                </Card.Body>
            </Card>
    </Col>
    <Col xs="3" lg="7">
    <Card style={{"height":"250px"}}>
            <Card.Body>
                <Card.Title>Completed Events by Month </Card.Title>
                    <Card.Text>
                    <p style={{"marginTop":"100px","marginLeft":"300px"}}>No data available1</p>
                    </Card.Text>
                </Card.Body>
            </Card>
    </Col>
   </Row>
   <br/>
   <Row className='d-flex'>
    <Col xs="3" lg="5">
    <Card style={{"height":"250px"}}>
            <Card.Body>
                <Card.Title>Top 5 Users by Check ins </Card.Title>
                    <Card.Text>
                    <p style={{"marginTop":"100px","marginLeft":"100px"}}>No data available1</p>
                    </Card.Text>
                </Card.Body>
            </Card>
    </Col>
    <Col xs="3" lg="7">
    <Card style={{"height":"250px"}}>
            <Card.Body>
                <Card.Title>Check ins by Month </Card.Title>
                    <Card.Text>
                    <p style={{"marginTop":"100px","marginLeft":"300px"}}>No data available1</p>
                    </Card.Text>
                </Card.Body>
            </Card>
    </Col>
   </Row>
</Container>
  )
}

export default EventsDashboard
