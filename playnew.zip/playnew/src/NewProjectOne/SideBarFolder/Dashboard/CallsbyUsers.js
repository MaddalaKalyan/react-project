import React from 'react'
import { Card, Col, Container, Row } from 'react-bootstrap'

function CallsbyUsers() {
  return (
    <Container >
    <Row className='d-flex'>
        <Col xs="3" lg="6">
            <Card  style={{"height":"250px"}}>
            <Card.Body>
                <Card.Title>Calls Completed - This Month</Card.Title>
                    <Card.Text>
                      <p style={{"marginTop":"30px","marginLeft":"40px"}}>No data available1</p>
                    </Card.Text>
                </Card.Body>
            </Card>
        </Col>
        <Col xs="3" lg="6">
            <Card  style={{"height":"250px"}}>
            <Card.Body>
                <Card.Title>Upcoming Calls - This Month </Card.Title>
                    <Card.Text>
                    <p style={{"marginTop":"30px","marginLeft":"40px"}}>No data available1</p>
                    </Card.Text>
                </Card.Body>
            </Card>
        </Col>
    </Row>
    <br/>
    <Row className='d-flex'>
        <Col xs="3" lg="6">
            <Card  style={{"height":"250px"}}>
            <Card.Body>
                <Card.Title>Inbound / Outbound calls</Card.Title>
                    <Card.Text>
                      <p style={{"marginTop":"30px","marginLeft":"40px"}}>No data available1</p>
                    </Card.Text>
                </Card.Body>
            </Card>
        </Col>
        <Col xs="3" lg="6">
            <Card  style={{"height":"250px"}}>
            <Card.Body>
                <Card.Title>Inbound / Outbound Seconds</Card.Title>
                    <Card.Text>
                    <p style={{"marginTop":"30px","marginLeft":"40px"}}>No data available1</p>
                    </Card.Text>
                </Card.Body>
            </Card>
        </Col>
    </Row>
    <br/>
    <Row className='d-flex'>
        <Col xs="3" lg="6">
            <Card  style={{"height":"250px"}}>
            <Card.Body>
                <Card.Title>Average Call duration (seconds) </Card.Title>
                    <Card.Text>
                      <p style={{"marginTop":"30px","marginLeft":"40px"}}>No data available1</p>
                    </Card.Text>
                </Card.Body>
            </Card>
        </Col>
    </Row>
 
</Container>
  )
}

export default CallsbyUsers
