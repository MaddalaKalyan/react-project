import React from 'react'
import { Card, Col, Container, Row } from 'react-bootstrap'

function Overview() {
  return (
    <Container >
        <Row className='d-flex'>
           <Col xs="3" lg="9" className='d-flex'>
             <Row>
             <Col xs="3" lg="4">
                <Card style={{"height":"150px"}}>
                <Card.Body>
                    <Card.Title>Contacts Created - This </Card.Title>
                        <Card.Text>
                        <h1 className='d-flex'>
                        <span>0</span>
                        <span className='bi bi-caret-down-fill' style={{"color":"red","fontSize":"20px","marginTop":"14px"}}>100%</span></h1>
                        <p>Last Month: 1</p>
                        </Card.Text>
                    </Card.Body>
                </Card>
            </Col>
            <Col xs="3" lg="4">
                <Card  style={{"height":"150px"}}>
                <Card.Body>
                    <Card.Title>Deals Won - This Month</Card.Title>
                        <Card.Text>
                          <p style={{"marginTop":"30px","marginLeft":"40px"}}>No data available1</p>
                        </Card.Text>
                    </Card.Body>
                </Card>
            </Col>
            <Col xs="3" lg="4">
                <Card  style={{"height":"150px"}}>
                <Card.Body>
                    <Card.Title>Deals Lost - This Month</Card.Title>
                        <Card.Text>
                        <p style={{"marginTop":"30px","marginLeft":"40px"}}>No data available1</p>
                        </Card.Text>
                    </Card.Body>
                </Card>
            </Col>
            <br/>
            <Col xs="3" lg="4">
                <Card style={{"height":"150px"}}>
                <Card.Body>
                    <Card.Title>Tasks Closed - This Month</Card.Title>
                        <Card.Text>
                        <p style={{"marginTop":"30px","marginLeft":"40px"}}>No data available1</p>
                        </Card.Text>
                    </Card.Body>
                </Card>
            </Col>
            <Col xs="3" lg="4">
                <Card  style={{"height":"150px"}}>
                <Card.Body>
                    <Card.Title>Events Completed - This Month </Card.Title>
                        <Card.Text>
                          <p style={{"marginTop":"30px","marginLeft":"40px"}}>No data available1</p>
                        </Card.Text>
                    </Card.Body>
                </Card>
            </Col>
            <Col xs="3" lg="4">
                <Card  style={{"height":"150px"}}>
                <Card.Body>
                    <Card.Title>Calls Completed - This Month </Card.Title>
                        <Card.Text>
                        <p style={{"marginTop":"30px","marginLeft":"40px"}}>No data available1</p>
                        </Card.Text>
                    </Card.Body>
                </Card>
            </Col>
             </Row>
           </Col>
           <Col xs="3" lg="3">
                <Card style={{"height":"320px"}}>
                <Card.Body>
                    <Card.Title>Top 5 Companies</Card.Title>
                        <Card.Text>
                        <p style={{"marginTop":"100px","marginLeft":"40px"}}>No data available1</p>
                        </Card.Text>
                    </Card.Body>
                </Card>
           </Col>
        </Row>
        <br/>
       <Row>
          <Col>
          <Card style={{"height":"250px"}}>
                <Card.Body>
                    <Card.Title>Revenue Won by Month</Card.Title>
                        <Card.Text>
                        <p style={{"marginTop":"100px","marginLeft":"500px"}}>No data available1</p>
                        </Card.Text>
                    </Card.Body>
                </Card>
          </Col>
       </Row>
       <Row>
        <Col xs="4" lg="6">
            
        </Col>
       </Row>
    </Container>
  )
}

export default Overview
