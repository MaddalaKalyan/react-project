import React from 'react'
import { Card, Col, Container, Row } from 'react-bootstrap'
function DealsDashboard() {
  return (
    <Container>
    <br/>
    <Row className='d-flex'>
       <Col xs="3" lg="3">
            <Card style={{"height":"150px"}}>
            <Card.Body>
                <Card.Title>Open Deals - This Month </Card.Title>
                    <Card.Text>
                    <h1 className='d-flex'>
                    <span>0</span>
                    <span className='bi bi-caret-down-fill' style={{"color":"red","fontSize":"20px","marginTop":"14px"}}>100%</span></h1>
                    <p>Last Month: 1</p>
                    </Card.Text>
                </Card.Body>
            </Card>
        </Col>
        <Col xs="3" lg="3">
            <Card  style={{"height":"150px"}}>
            <Card.Body>
                <Card.Title>Deals Won - This Month </Card.Title>
                    <Card.Text>
                      <p style={{"marginTop":"30px","marginLeft":"40px"}}>No data available1</p>
                    </Card.Text>
                </Card.Body>
            </Card>
        </Col>
        <Col xs="3" lg="3">
            <Card  style={{"height":"150px"}}>
            <Card.Body>
                <Card.Title>Deals Lost - This Month</Card.Title>
                    <Card.Text>
                    <p style={{"marginTop":"30px","marginLeft":"40px"}}>No data available1</p>
                    </Card.Text>
                </Card.Body>
            </Card>
        </Col>
        <Col xs="3" lg="3">
            <Card  style={{"height":"150px"}}>
            <Card.Body>
                <Card.Title>Deals Lost - This Month</Card.Title>
                    <Card.Text>
                    <p style={{"marginTop":"30px","marginLeft":"40px"}}>No data available1</p>
                    </Card.Text>
                </Card.Body>
            </Card>
        </Col>

    </Row>
    <br/>
   <Row>
      <Col>
      <Card style={{"height":"250px"}}>
            <Card.Body>
                <Card.Title>Revenue Won by Month</Card.Title>
                    <Card.Text>
                    <p style={{"marginTop":"100px","marginLeft":"500px"}}>No data available1</p>
                    </Card.Text>
                </Card.Body>
            </Card>
      </Col>
   </Row>
   <br/>
   <Row className='d-flex'>
    <Col xs="3" lg="4">
    <Card style={{"height":"250px"}}>
            <Card.Body>
                <Card.Title>Top 5 Users - Deals Won </Card.Title>
                    <Card.Text>
                    <p style={{"marginTop":"100px","marginLeft":"100px"}}>No data available1</p>
                    </Card.Text>
                </Card.Body>
            </Card>
    </Col>
    <Col xs="3" lg="8">
    <Card style={{"height":"250px"}}>
            <Card.Body>
                <Card.Title>Open Deals Amount by Stage </Card.Title>
                    <Card.Text>
                    <p style={{"marginTop":"100px","marginLeft":"300px"}}>No data available1</p>
                    </Card.Text>
                </Card.Body>
            </Card>
    </Col>
   </Row>
   <br/>
   <Row className='d-flex'>
    <Col xs="3" lg="4">
    <Card style={{"height":"250px"}}>
            <Card.Body>
                <Card.Title>Top 5 Users - Deals Won </Card.Title>
                    <Card.Text>
                    <p style={{"marginTop":"100px","marginLeft":"100px"}}>No data available1</p>
                    </Card.Text>
                </Card.Body>
            </Card>
    </Col>
    <Col xs="3" lg="8">
    <Card style={{"height":"250px"}}>
            <Card.Body>
                <Card.Title>Monthly Revenue by Users</Card.Title>
                    <Card.Text>
                    <p style={{"marginTop":"100px","marginLeft":"300px"}}>No data available1</p>
                    </Card.Text>
                </Card.Body>
            </Card>
    </Col>
   </Row>
</Container>
  )
}

export default DealsDashboard
