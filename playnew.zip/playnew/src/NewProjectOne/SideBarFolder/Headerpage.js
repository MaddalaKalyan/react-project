import React from 'react';
import './Headerpage.css';
import { Container,Row,Col,Image,Button,Nav,Form,NavDropdown} from 'react-bootstrap';
import biginlogo from './biginlogo.svg';
import { BrowserRouter, Link, Route, Routes } from 'react-router-dom';
import Settings from './Settings';


function Headerpage() {
  return (
    <Container fluid>
        <Row className='header'>
            <Col xs="1" lg="1"  className='d-flex Cls1'>
              <Image src={biginlogo} alt="bigin" style={{"width":"33px","margin-top":"-28px"}}/>
              <h4 style={{"fontSize":"28px","margin-top":"13px"}}>Bigin</h4>
            </Col>
            <Col xs="1" lg="3"  className='d-flex Cls1'>
        <Nav className="justify-content-end flex-grow-1 pe-3">
        <NavDropdown title="All" className='Cls2'>
                    <NavDropdown.Item href="#action3">ALL</NavDropdown.Item>
                    <NavDropdown.Item href="#action4">Deals</NavDropdown.Item>
                    <NavDropdown.Item href="#action5">Contacts</NavDropdown.Item>
                    <NavDropdown.Item href="#action6">Companies</NavDropdown.Item>
                    <NavDropdown.Item href="#action7">Products</NavDropdown.Item>
                    <NavDropdown.Item href="#action8">Tasks</NavDropdown.Item>
                    <NavDropdown.Item href="#action9">Events</NavDropdown.Item>
                    <NavDropdown.Item href="#action10">Calls</NavDropdown.Item>
                    <NavDropdown.Item href="#action11">Notes</NavDropdown.Item>
                  </NavDropdown>
                </Nav>
                <Form className="d-flex">
                  <Form.Control
                    type="search"
                    placeholder="Search(ctrl+k)"
                    className="Cls3"
                    aria-label="Search"
                  />
                  <Button variant="nocolor" placeholder='search' className="bi bi-search Cls4" type="search"></Button>
                </Form>
        </Col>
            <Col lg="4" style={{"margin-top":"17px"}} className='d-flex'>
              <p>14 days left in your Premier trial.</p>
               <a href="/">Upgrade</a>
            </Col>
             <BrowserRouter>
             <Col xs lg="4" className='d-flex justify-content-between' style={{"margin-top":"17px"}}>
              <span className='bi bi-bell'></span>
              <span className='bi bi-currency-dollar'></span>
              <span className='bi bi-plus-circle-fill'></span>
               <Link to="/Settings"><span className='bi bi-gear'></span></Link>
              <span className='bi bi-person-circle'></span>
            </Col>
            <Col className='container'>
               <Routes>
                  <Route path='/Settings' element={<Settings/>} />
               </Routes>
            </Col>
             </BrowserRouter>

        </Row>
       
    </Container>
  )
}

export default Headerpage
