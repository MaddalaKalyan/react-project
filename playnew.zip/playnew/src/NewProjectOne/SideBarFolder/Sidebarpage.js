import React from 'react';
import './Sidebarpage.css';
import { Col, Container, Row } from 'react-bootstrap'
import { BrowserRouter, Link, Route, Routes } from 'react-router-dom';
import Contacts from './Contacts';
import AllContacts from './Contactfolder/AllContacts';
import MailingLabels from './Contactfolder/MailingLabels';
import MyContacts from './Contactfolder/MyContacts';
import NewLastWeek from './Contactfolder/NewLastWeek';
import NewThisWeek from './Contactfolder/NewThisWeek';
import RecentlyCreatedContacts from './Contactfolder/RecentlyCreatedContacts';
import RecentlyModifiedContacts from './Contactfolder/RecentlyModifiedContacts';
import NotYetViewed from './Contactfolder/NotYetViewed';
import UnsubscribedContacts from './Contactfolder/UnsubscribedContacts';
import Companies from './Companies';
import AllCompanies from './Companies/AllCompanies';
import MyCompanies from './Companies/MyCompanies';
import NewLastweeks from './Companies/NewLastweeks';
import NewThisWeeks from './Companies/NewThisWeeks';
import RecentlyModifiedCompanies from './Companies/RecentlyModifiedCompanies';
import NotYetView from './Companies/NotYetView';
import RecentlyCreatedCompanys from './Companies/RecentlyCreatedCompanys';
import Products from './Products';
import Activities from './Activities';
import Tasks from './Activities/Tasks';
import AllTasks from './Tasks/AllTasks';
import ClosedTasks from './Tasks/ClosedTasks';
import MyOpenTasks from './Tasks/MyOpenTasks';
import Opentasks from './Tasks/Opentasks';
import OverdueTasks from './Tasks/OverdueTasks';
import TodayOverdueTasks from './Tasks/TodayOverdueTasks';
import TodaysTasks from './Tasks/TodaysTasks';
import TomorrowTasks from './Tasks/TomorrowTasks';
import Next7DaysOverdue from './Tasks/Next7DaysOverdue';
import Events from './Activities/Events';
import Calls from './Activities/Calls';
import Dashboards from './Dashboards';
//import Templates from './Templates';
import Overview from './Dashboard/Overview';
import DealsDashboard from './Dashboard/DealsDashboard';
import TaskDashboard from './Dashboard/TaskDashboard';
import EventsDashboard from './Dashboard/EventsDashboard';
import CallAnalytics from './Dashboard/CallAnalytics';
import EmailAnalytics from './Dashboard/EmailAnalytics';
import CallsbyUsers from './Dashboard/CallsbyUsers';
import DashboardCharts from './DashboardCharts';
import Deals from './Deals';




function Sidebarpage() {
  return (
    <Container fluid className='SiderBarContainer'>
        <BrowserRouter>
           <Row className='SidebarpageRow1' >
               <Col sm="2" lg="1" md="2"  className='list'>
                <ul>
                <Link to="/deals"><li className="bi bi-hourglass-bottom"><br/>Deals</li></Link>
                <Link to="/contacts"><li className="bi bi-person-lines-fill">Contacts</li></Link>
                <Link to="/companies"><li className="bi bi-building">Companies</li></Link>
                <Link to="/products"><li className="bi bi-box2">Products</li></Link>
                <Link to="/activities"><li className="bi bi-calendar-check">Activities</li></Link>
                <Link to="/Dashboards"><li className="bi bi-pie-chart-fill">Dashboards</li></Link>
                
            </ul>
            </Col>
          
            <Col sm="6" lg="" md="10"  className='container'>
                 <Routes>
                     <Route path="/deals" element={<Deals/>}>
                     <Route path='allcontacts' element={<AllContacts/>}></Route>
                     <Route path='mailingLabels' element={<MailingLabels/>}></Route>
                     <Route path='myContacts' element={<MyContacts/>}></Route>
                     <Route path='newLastWeek' element={<NewLastWeek/>}></Route>
                     <Route path='newThisWeek' element={<NewThisWeek/>}></Route>
                     <Route path='reacentlyCreatedContacts' element={<RecentlyCreatedContacts/>}></Route>
                     <Route path='recentlyModifiedContacts' element={<RecentlyModifiedContacts/>}></Route>
                     <Route path='notYetViewed' element={<NotYetViewed/>}></Route>
                     <Route path='unsubscribedContacts' element={<UnsubscribedContacts/>}></Route>
                     </Route>
                     <Route path='/contacts' element={<Contacts/>}>
                     <Route path='allcontacts' element={<AllContacts/>}></Route>
                     <Route path='mailingLabels' element={<MailingLabels/>}></Route>
                     <Route path='myContacts' element={<MyContacts/>}></Route>
                     <Route path='newLastWeek' element={<NewLastWeek/>}></Route>
                     <Route path='newThisWeek' element={<NewThisWeek/>}></Route>
                     <Route path='reacentlyCreatedContacts' element={<RecentlyCreatedContacts/>}></Route>
                     <Route path='recentlyModifiedContacts' element={<RecentlyModifiedContacts/>}></Route>
                     <Route path='notYetViewed' element={<NotYetViewed/>}></Route>
                     <Route path='unsubscribedContacts' element={<UnsubscribedContacts/>}></Route>
                   </Route>
                   <Route path='/companies' element={<Companies/>}>
                      <Route path='AllCompanies' element={<AllCompanies/>}></Route>
                      <Route path='MyCompanies' element={<MyCompanies/>}></Route>
                      <Route path='NewLastweeks' element={<NewLastweeks/>}></Route>
                      <Route path='NewThisWeeks' element={<NewThisWeeks/>}></Route>
                      <Route path='RecentlyCreatedCompanys' element={<RecentlyCreatedCompanys/>}></Route>
                      <Route path='RecentlyModifiedCompanies' element={<RecentlyModifiedCompanies/>}></Route>
                      <Route path='NotYetView' element={<NotYetView/>}></Route>
                   </Route>
                   <Route path='/Products' element={<Products/>}>
                     
                   </Route>
                   <Route path='/Activities' element={<Activities/>}>
                      <Route path='Tasks' element={<Tasks/>}>
                        <Route path='AllTasks' element={<AllTasks/>}></Route>
                        <Route path='ClosedTasks' element={<ClosedTasks/>}></Route>
                        <Route path='MyOpenTasks' element={<MyOpenTasks/>}></Route>
                        <Route path='Next7DaysOverdue' element={<Next7DaysOverdue/>}></Route>
                        <Route path='Opentasks' element={<Opentasks/>}></Route>
                        <Route path='OverdueTasks' element={<OverdueTasks/>}></Route>
                        <Route path='TodayOverdueTasks' element={<TodayOverdueTasks/>}></Route>
                        <Route path='TodaysTasks' element={<TodaysTasks/>}></Route>
                        <Route path='TomorrowTasks' element={<TomorrowTasks/>}></Route>
                      </Route>
                      <Route path='Events' element={<Events/>}></Route>
                      <Route path='Calls' element={<Calls/>}></Route>
                   </Route>
                    <Route path='/Dashboards' element={<Dashboards/>}>
                       <Route path='Overview' element={<Overview/>}></Route>
                       <Route path='DealsDashboard' element={<DealsDashboard/>}></Route>
                       <Route path='TaskDashboard' element={<TaskDashboard/>}></Route>
                       <Route path='EventsDashboard' element={<EventsDashboard/>}></Route>
                       <Route path='CallAnalytics' element={<CallAnalytics/>}></Route>
                       <Route path='EmailAnalytics' element={<EmailAnalytics/>}></Route>
                       <Route path='CallsbyUsers' element={<CallsbyUsers/>}></Route>
                       <Route path='DashboardCharts' element={<DashboardCharts/>}></Route>
                    </Route>
                 
                 </Routes>
            </Col>
        </Row>
        </BrowserRouter>
    </Container>
  )
}

export default Sidebarpage
