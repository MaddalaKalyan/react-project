import React from 'react'
import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd";
import {  Col, Container, Row,Button,Nav,NavDropdown,Dropdown  } from 'react-bootstrap';
import { Link, Outlet } from 'react-router-dom'

export default class Deals extends React.Component {
  constructor(props){
    super(props);
    this.state = {
        "state":[],
    };
  }
   getItems = (count, offset = 0) =>
  Array.from({ length: count }, (v, k) => k).map(k => ({
    id: `item-${k + offset}-${new Date().getTime()}`,
    content: `item ${k + offset}`
  }));

 reorder = (list, startIndex, endIndex) => {
  const result = Array.from(list);
  const [removed] = result.splice(startIndex, 1);
  result.splice(endIndex, 0, removed);

  return result;
};

/**
 * Moves an item from one list to another list.
 */
 move = (source, destination, droppableSource, droppableDestination) => {
  const sourceClone = Array.from(source);
  const destClone = Array.from(destination);
  const [removed] = sourceClone.splice(droppableSource.index, 1);
  destClone.splice(droppableDestination.index, 0, removed);
  const result = {};
  result[droppableSource.droppableId] = sourceClone;
  result[droppableDestination.droppableId] = destClone;
  return result;
};
 grid = 3;
 getItemStyle = (isDragging, draggableStyle) => ({
  // some basic styles to make the items look a bit nicer
  userSelect: "none",
  padding: this.grid * 2,
  margin: `0 0 ${this.grid}px 0`,

  // change background colour if dragging
  background: isDragging ? "lightgreen" : "grey",

  // styles we need to apply on draggables
  ...draggableStyle
});
 getListStyle = isDraggingOver => ({
  background: isDraggingOver ? "lightblue" : "lightgrey",
  padding: this.grid,
  width: 250
});
 onDragEnd(result) {
  const { source, destination } = result;

  // dropped outside the list
  if (!destination) {
    return;
  }
  const sInd = +source.droppableId;
  const dInd = +destination.droppableId;

  if (sInd === dInd) {
    const items = this.reorder(this.state.state[sInd], source.index, destination.index);
    const newState = [this.state.state];
    newState[sInd] = items;
    this.setState({"state":newState});
  } else {
    const result = this.move(this.state.state[sInd], this.state.state[dInd], source, destination);
    const newState = [this.state.state];
    newState[sInd] = result[sInd];
    newState[dInd] = result[dInd];

    this.setState({"state":newState.filter(group => group.length)});
  }
}


  render() {
    const contacts = this.state.state;
    return (
  <Container fluid style={{"margin":"0px","padding":"0px"}}>
      <Row className='contactRow d-flex justify-content-between'>
        <Col xs="3" lg="1" className='d-flex class1'>
        <Button variant='light' className='bi bi-filter class1-5' style={{"borderRadius":"100px 100px 100px 100px"}}></Button> 
        </Col>
        <Col xs="3" lg="3">
        <Dropdown className="d-inline mx-2 DropDown" >
        <Dropdown.Toggle id="dropdown-autoclose-true" className='btn btn-light DropDown1' style={{"borderRadius":"100px 100px 100px 100px","marginTop":"5px"}}>
            AllContacts
        </Dropdown.Toggle>
        <Dropdown.Menu>
          <Dropdown.Item ><Link to="allcontacts">AllContacts</Link></Dropdown.Item>
          <Dropdown.Item ><Link to="mailinglabels">Mailinglabels</Link></Dropdown.Item>
          <Dropdown.Item ><Link to="mycontacts">MyContacts</Link></Dropdown.Item>
          <Dropdown.Item ><Link to="newLastWeek">NewLastWeek</Link></Dropdown.Item>
          <Dropdown.Item ><Link to="newThisWeek">NewThisWeek</Link></Dropdown.Item>
          <Dropdown.Item ><Link to="reacentlyCreatedContacts">ReacentlyCreatedContacts</Link></Dropdown.Item>
          <Dropdown.Item ><Link to="recentlyModifiedContacts">RecentlyModifiedContacts</Link></Dropdown.Item>
          <Dropdown.Item ><Link to="notYetViewed">NotYetViewed</Link></Dropdown.Item>
          <Dropdown.Item ><Link to="unsubscribedContacts">UnsubscribedContacts</Link></Dropdown.Item>
        </Dropdown.Menu>
      </Dropdown>
        </Col>
        <Col xs="3" lg="4">
        
        </Col>
       <Col xs="3" lg="2" style={{"width":"25%"}}>
       <Row  className='d-flex justify-content-end ContactRow2 '>
           <Col xs="6" lg="8" className='d-flex justify-content-end ContactCol1'>
          
          <Button variant='success'  className='ContactBu1 bi bi-plus' >Company</Button>
             <Nav className="justify-content-end flex-grow-1 pe-3 ContactNav1" >
             <NavDropdown  className='ContactNavDropDown1'>
            <NavDropdown.Item href="#action3">Import Companies</NavDropdown.Item>
            <NavDropdown.Item href="#action4">Import Notes</NavDropdown.Item>
            </NavDropdown>
          </Nav>
            <Col xs="3" lg="4" className='d-flex class2 justify-content-end'>
           <Button variant='light' className='bi bi-three-dots-vertical' style={{"borderRadius":"100px 100px 100px 100px"}}></Button> 
       </Col>
      </Col>
   
           </Row>
       </Col>
            
          
           
       
     </Row>
     <Row>
      <Outlet/>
     </Row>
  
    <button
      type="button"
      onClick={() => {
        this.setState(prevState => ({
          "state": [...prevState.state ,[]]
        }));
      }}
    >
      Add new group
    </button>
    <button
      type="button"
      onClick={() => {

        this.setState(prevState => ({
          "state": [...prevState.state ,this.getItems(6)]
        }));
      }}
    >
      Add new item
    </button>
    <div style={{ display: "flex" }}>
      <DragDropContext onDragEnd={this.onDragEnd}>
        {contacts.map((el, ind) => (
          <Droppable key={ind} droppableId={`${ind}`}>
            {(provided, snapshot) => (
              <div
                ref={provided.innerRef}
                style={this.getListStyle(snapshot.isDraggingOver)}
                {...provided.droppableProps}
              >
                {el.map((item, index) => (
                  <Draggable
                    key={item.id}
                    draggableId={item.id}
                    index={index}
                  >
                    {(provided, snapshot) => (
                      <div
                        ref={provided.innerRef}
                        {...provided.draggableProps}
                        {...provided.dragHandleProps}
                        style={this.getItemStyle(
                          snapshot.isDragging,
                          provided.draggableProps.style
                        )}
                      >
                        <div
                          style={{
                            display: "flex",
                            justifyContent: "space-around"
                          }}
                        >
                          {item.content}
                          <button
                            type="button"
                            onClick={() => {
                              const newState = [this.state];
                              newState[ind].splice(index, 1);
                              this.setState(
                                newState.filter(group => group.length)
                              );
                            }}
                          >
                            delete
                          </button>
                        </div>
                      </div>
                    )}
                  </Draggable>
                ))}
                {provided.placeholder}
              </div>
            )}
          </Droppable>
        ))}
      </DragDropContext>
    </div>

    
    </Container>
    )
  }
}