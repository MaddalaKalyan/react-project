import React from 'react';
import { Bar } from 'react-chartjs-2';
import { Pie } from 'react-chartjs-2';
import { Doughnut } from 'react-chartjs-2';
import { Line } from 'react-chartjs-2';
import {Chart,LinearScale,CategoryScale,PointElement,LineElement,BarElement,Legend,ArcElement,Title,Tooltip, Filler } from 'chart.js';
import { Card, Col, Container, Row } from 'react-bootstrap';
Chart.register(
    LinearScale,PointElement,LineElement,CategoryScale,BarElement,Filler,Legend,Title,Tooltip );

Chart.register(
    ArcElement, Tooltip, Legend
    );
const labels = ["jan","feb", "march","april","may","june","july","aug","sep","oct","nov","dec"];
const labels1 = ["andhra pradesh","telangana", "orissa","tamilnadu","kerala"];
const labels2 = ["andhra pradesh","telangana", "orissa","tamilnadu","kerala"];
const labels3 = ["jan","feb", "march","april","may","june","july","aug","sep","oct","nov","dec"];

const options = {
    responsive: true,
    plugins: {
        legend: {
          position: 'top',
        },
        title: {
          display: true,
          text: 'Chart.js Bar Chart',
        },
      }, 
};
const options1 = {
    responsive: true,
    plugins: {
        legend: {
          position: 'top',
        },
          title1: {
            display: true,
            text: ' Pie Chart',
          },
      },
      
};
const options2 = {
    responsive: true,
    plugins: {
        legend: {
          position: 'top',
        },
          title2: {
            display: true,
            text: ' Pie Chart',
          },
      },
      
};
const options3 = {
    responsive: true,
    plugins: {
        legend: {
          position: 'right',
        },
        title3: {
          display: true,
          text: 'Chart.js Bar Chart',
        },
      }, 
};
const options4 = {
    responsive: true,
    plugins: {
        legend: {
          position: 'top',
        },
        title: {
          display: true,
          text: 'Chart.js Line Chart',
        },
      }, 
};
const options5 = {
    responsive: true,
    plugins: {
        legend: {
          position: 'top',
        },
        title: {
          display: true,
          text: 'Chart.js Area Chart',
        },
      }, 
};
const options6 = {
    responsive: true,
    plugins: {
        legend: {
          position: 'top',
        },
        title: {
          display: true,
          text: 'Chart.js Area Chart',
        },
      }, 
};
const data = {
    labels,
      datasets : [
        {
            label: 'Dataset 1',
            data:[10000,15000,20000,25000,35000,57000,49000,45000,50000,55700,60090,57890],
            backgroundColor:"blue"
        },
        {
            label: 'Dataset 2',
            data:[10500,30000,40000,50000,60000,70000,80000,90000,60000,45000,29000,30000],
            backgroundColor:"yellow"
        }, 
    ]
};
var data1 = {
    labels1,
    datasets :[
        {
            label: '# of Votes',
            data: [1,2,3,4,5,6],
            backgroundColor: [
              'rgba(255, 99, 132, 0.2)',
              'rgba(54, 162, 235, 0.2)',
              'rgba(255, 206, 86, 0.2)',
              'rgba(75, 192, 192, 0.2)',
              'rgba(153, 102, 255, 0.2)',
              'rgba(255, 159, 64, 0.2)',
            ],
            borderColor: [
              'rgba(255, 99, 132, 1)',
              'rgba(54, 162, 235, 1)',
              'rgba(255, 206, 86, 1)',
              'rgba(75, 192, 192, 1)',
              'rgba(153, 102, 255, 1)',
              'rgba(255, 159, 64, 1)',
            ],
            borderWidth: 1,
            hoverOffset: 20
          },
    ]
};
var data2 = {
    labels2,
    datasets :[
        {
            label: '# of Votes',
            data: [12, 19, 3, 5, 2, 3],
            backgroundColor: [
              'rgba(255, 99, 132, 0.2)',
              'rgba(54, 162, 235, 0.2)',
              'rgba(255, 206, 86, 0.2)',
              'rgba(75, 192, 192, 0.2)',
              'rgba(153, 102, 255, 0.2)',
              'rgba(255, 159, 64, 0.2)',
            ],
            borderColor: [
              'rgba(255, 99, 132, 1)',
              'rgba(54, 162, 235, 1)',
              'rgba(255, 206, 86, 1)',
              'rgba(75, 192, 192, 1)',
              'rgba(153, 102, 255, 1)',
              'rgba(255, 159, 64, 1)',
            ],
            borderWidth: 1,
            hoverOffset: 20
          },
    ]
};
const data3 = {
    labels,
      datasets : [
        {
            label: 'Dataset 1',
            data:[10000,15000,20000,25000,35000,57000,49000,45000,50000,55700,60090,57890],
            backgroundColor:"green"
        },
        {
            label: 'Dataset 2',
            data:[10500,30000,40000,50000,60000,70000,80000,90000,60000,45000,29000,30000],
            backgroundColor:"red"
        }, 
    ]
};
const data4 = {
    labels,
      datasets : [
        {
            label: 'Dataset 1',
            data:[10000,15000,20000,25000,35000,57000,49000,45000,50000,55700,60090,57890],
            borderColor: 'rgb(255, 99, 132)',
            backgroundColor: 'rgba(255, 99, 132, 0.5)',
        },
        {
            label: 'Dataset 2',
            data:[10500,30000,40000,50000,60000,70000,80000,90000,60000,45000,29000,30000],
            borderColor: 'rgb(53, 162, 235)',
            backgroundColor: 'rgba(53, 162, 235, 0.5)',
        },
        
    ]
};
const data5 = {
    labels,
      datasets : [
        {
            fill: true,
            label:'Dataset 1',
            data:[10000,15000,20000,25000,35000,57000,49000,45000,50000,55700,60090,57890],
            borderColor: 'rgb(255, 99, 132)',
            backgroundColor: 'rgba(255, 99, 132, 0.5)',
        },
        { 
            fill: true,
            label: 'Dataset 2',
            data:[10500,30000,40000,50000,60000,70000,80000,90000,60000,45000,29000,30000],
            borderColor: 'rgb(53, 162, 235)',
            backgroundColor: 'rgba(53, 162, 235, 0.5)',
        }, 
    ]
};



function Dashboard() {
  return (
    <Container>
        <Row>
            <Col xs="6" lg="4">
                <Card>
                     <Bar options={options} data={data} />
                </Card>
                <p className='text-center p-2'>Bar chart</p>
            </Col>
            <Col xs="6" lg="4">
                <Card>
                <Pie options={options1} data={data1} />
                </Card>
                <p className='text-center p-2'>Pie chart</p>
            </Col>
            <Col xs="6" lg="4">
                <Card>
                    <Doughnut options={options2} data={data2}/>
                </Card>
                <p className='text-center p-2'>Doughnut chart</p>
            </Col>
        </Row>
        <Row>
            <Col xs="6" sm="4">
               <Card>
                    <Bar options={options3} data={data3}/>
                </Card>
                <p className='text-center p-2'>Vertical chart</p>
            </Col>
            <Col xs="6" sm="4">
                <Card>
                    <Line options={options4} data={data4}/>
                </Card>
                <p className='text-center p-2'>Line chart</p>
            </Col>
            <Col xs="6" sm="4">
                <Card>
                  <Line options={options5} data={data5}/>
                </Card>
                <p className='text-center p-2'>Area chart</p>
            </Col>
        </Row>
        <Row>
            <Col>
                <Card></Card>
            </Col>
        </Row>
    </Container>
  )
}

export default Dashboard
