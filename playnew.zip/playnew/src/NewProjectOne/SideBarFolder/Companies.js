import React from 'react'
import './Companies.css'
import { Col, Container, Row,Button,Nav,NavDropdown,  Dropdown } from 'react-bootstrap'
import { Link, Outlet } from 'react-router-dom'

function Companies() {
  return (
    <Container fluid className='CompaniesContainer'>
    <Row className='CompaniesRow1 d-flex justify-content-between '>
       <Col sm="3" lg="1" className='d-flex class1'>
       <Button variant='light' className='bi bi-filter class1-5'></Button> 
       </Col>
       <Col sm="3" lg="3">
       <Dropdown className="d-inline mx-2 CompaniesDropDown1">
       <Dropdown.Toggle id="dropdown-autoclose-true" className='btn btn-light DropDown2' style={{"borderRadius":"100px 100px 100px 100px"}}>
          All Companies
       </Dropdown.Toggle>
       
       <Dropdown.Menu>
       <h5>PUBLIC VIEWS</h5>
       <br/>
         <Dropdown.Item ><Link to="AllCompanies">AllCompanies</Link></Dropdown.Item>
         <Dropdown.Item ><Link to="MyCompanies">MyCompanies</Link></Dropdown.Item>
         <Dropdown.Item ><Link to="NewLastWeeks">NewLastWeeks</Link></Dropdown.Item>
         <Dropdown.Item ><Link to="NewThisWeeks">NewThisWeeks</Link></Dropdown.Item>
         <Dropdown.Item ><Link to="RecentlyCreatedCompanys">RecentlyCreatedCompanys</Link></Dropdown.Item>
         <Dropdown.Item ><Link to="RecentlyModifiedCompanies">RecentlyModifiedCompanies</Link></Dropdown.Item>
         <Dropdown.Item ><Link to="NotYetView">NotYetView</Link></Dropdown.Item>
       </Dropdown.Menu>
     </Dropdown>
       </Col>
       <Col sm="2" lg="4">
       
       </Col>
       <Col sm="3" lg="2" style={{"width":"25%"}}>
       <Row  className='d-flex justify-content-end CompaniesRow2 '>
           <Col sm="6" lg="8" className='d-flex justify-content-end CompaniesCol1'>
          
          <Button variant='success'  className='CompaniesBu1 bi bi-plus '>Company</Button>
             <Nav className="justify-content-end flex-grow-1 pe-3 CompaniesNav1" >
             <NavDropdown  className='CompaniesNavDropDown1'>
            <NavDropdown.Item href="#action3">Import Companies</NavDropdown.Item>
            <NavDropdown.Item href="#action4">Import Notes</NavDropdown.Item>
            </NavDropdown>
          </Nav>
            <Col sm="3" lg="4" className='d-flex class2 justify-content-end'>
           <Button variant='light' className='bi bi-three-dots-vertical' style={{"borderRadius":"100px 100px 100px 100px"}}></Button> 
       </Col>
      </Col>
   
           </Row>
       </Col>
            
    </Row>
    <br/>
 
    

    <br/>
    <Row>
     <Outlet/>
    </Row>
   
  </Container>
  )
}

export default Companies
