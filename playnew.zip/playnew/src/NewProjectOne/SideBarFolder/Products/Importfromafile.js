import React from 'react';
import { Container, Row } from 'react-bootstrap';
import { Outlet } from 'react-router';
import StepProgressBar from "react-step-progress";



function Importfromafile() {
  const step1Content = <h1><input type="text"/></h1>;
  const step2Content = <h1>dgfdg</h1>;
  const step3Content = <h1>dgdfgfdgdfg</h1>;

  function step2Validator() {
    return true;
  }

  function step3Validator() {
    // return a boolean
  }

  return (
    <Container className='text-center'>
        <Row>
        <StepProgressBar
        startingStep={0}
        previousBtnName="Geri"
        steps={[
          {
            label: "Upload Your File",
            name: "Upload Your File",
            content: step1Content
          },
          {
            label: "Choose an Action",
            name: "Choose an Action",
            content: step2Content
          },
          {
            label: "Map Your Data",
            name: "Map Your Data",
            content: step3Content
            // validator: step2Validator
          },
          {
            label: "Additional Options",
            name: "Additional Options",
            content: step3Content
          }
        ]}
      />
        </Row>
      <Outlet/>
    </Container>
  )
}

export default Importfromafile
