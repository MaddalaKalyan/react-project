import React from 'react';
import { useState } from 'react';
import Modal from 'react-bootstrap/Modal';
import { Col, Container, Row,Button } from 'react-bootstrap';
import './Templates.css';
function Templates() {
  const [lgShow, setLgShow] = useState(false);
    
  return (
    <Container>
        <Row>
            <Col>
                <Button onClick={() => setLgShow(true)}>Large modal</Button>
                <Modal
                  size="lg"
                  show={lgShow}
                  onHide={() => setLgShow(false)}
                  aria-labelledby="example-modal-sizes-title-lg"
                >
        <Modal.Header closeButton>
          <Modal.Title id="example-modal-sizes-title-lg">
            Large Modal
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>...</Modal.Body>
      </Modal>
            </Col>
           
        </Row>
        <Row>
          <Col>

          </Col>
        </Row>
    </Container>
  )
}

export default Templates
