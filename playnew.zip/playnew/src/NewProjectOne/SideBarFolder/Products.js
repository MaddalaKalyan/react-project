import React from 'react'
import  { useState } from 'react';
import Offcanvas from 'react-bootstrap/Offcanvas';
import { Col, Container, Image, Row ,Form,Button} from 'react-bootstrap';
import biginhome from './biginhome.svg'
import { Link, Outlet } from 'react-router-dom';

function OffCanvasExample({ name, ...props }) {
  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  return (
    <>
      <Button variant="success" style={{"borderRadius":"100px 100px 100px 100px"}} onClick={handleShow} className="me-2">
       Add Product
      </Button>
      <Offcanvas show={show} onHide={handleClose} {...props}>
        <Offcanvas.Header closeButton>
          <Offcanvas.Title>Create Product</Offcanvas.Title>
        </Offcanvas.Header>
        <hr/>
        <Offcanvas.Body>
        <Form>
                        <Row className='d-flex'>
                          <Col><h6>Product Information</h6></Col>
                          <Col><p>Owner : </p></Col>
                        </Row>
                      <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                        <Row>
                          <Col xs="3" lg="4"><Form.Label>Product Name</Form.Label></Col>
                          <Col xs="3" lg="8"><Form.Control
                            type="text"
                            placeholder="Enter Product Name"
                            autoFocus
                            /></Col>
                        </Row>
                        </Form.Group>
                        <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                        <Row>
                          <Col xs="3" lg="4"><Form.Label>Product Code</Form.Label></Col>
                          <Col xs="3" lg="8"><Form.Control
                            type="text"
                            placeholder="Enter Code"
                            autoFocus
                            /></Col>
                        </Row>
                        </Form.Group>
                        <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                        <Row>
                          <Col xs="3" lg="4"><Form.Label>Product Category</Form.Label></Col>
                          <Col xs="3" lg="8"><Form.Select aria-label="Default select example">
                              <option>-None-</option>
                              <option value="1">Hardware</option>
                              <option value="2">Software</option>
                              <option value="3">CRM Applications</option>
                          </Form.Select></Col>
                        </Row>
                        </Form.Group> 
                        <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                        <Row>
                          <Col xs="3" lg="4"><Form.Label>Unit Price</Form.Label></Col>
                          <Col xs="3" lg="8"><Form.Control
                            type="text"
                            placeholder="$"
                            autoFocus
                            /></Col>
                        </Row>
                        </Form.Group>
                        <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                        <Row>
                          <Col xs="3" lg="4"><Form.Label>Description</Form.Label></Col>
                          <Col xs="3" lg="8"><Form.Control
                            type="text"
                            placeholder="A few words about this product"
                            autoFocus
                            /></Col>
                        </Row>
                        </Form.Group>
                        <Form.Group className="mb-3" id="formGridCheckbox">
                        <Form.Check type="checkbox" label="Product Active" />
                        </Form.Group>
                      </Form>
                      <br/>
                      <hr/>
                      <Row className='d-flex justify-content-between'>
                        <Col xs="3" lg="6" ><Link to="/FieldSettings" >Field Settings</Link></Col>
                        <Col xs="3" lg="6" className='d-flex'>
                              <Button variant="white" onClick={handleClose} style={{"borderRadius":"100px 100px 100px 100px"}}>
                                Cancel
                              </Button>
                            <Button variant="success" onClick={handleClose} style={{"borderRadius":"100px 100px 100px 100px"}}>
                              Save 
                            </Button>
                        </Col>
                      </Row>
        </Offcanvas.Body>
      </Offcanvas>
    </>
  );
}


function Products() {
  
  return (
    <Container>
        <Row className='text-center'>
            <Col xs="12" lg="12" >
               <Image src={biginhome} alt="image" style={{"width":"300px","margin-top":"28px"}} />
               <p>Products are things your team sells.</p>
                   {[ 'end' ].map((placement, idx) => (
                      <OffCanvasExample key={idx} placement={placement} name={placement} />
                     ))}
                  
                    <br/>
                  <h5>OR</h5>
                  <br/>
                  <Button variant='success' style={{"borderRadius":"100px 100px 100px 100px"}}><Link to="Importfromfile">Importfromfile</Link></Button>

                  </Col>
        </Row>
        <br/>
        <Row>
          <Outlet/>
        </Row>
    </Container>
  )
}

export default Products
