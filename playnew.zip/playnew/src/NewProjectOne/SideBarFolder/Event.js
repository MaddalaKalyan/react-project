import React from 'react'
import  { useState } from 'react';
import Offcanvas from 'react-bootstrap/Offcanvas';
import { Col, Container,  Row ,Form,Button,Nav,NavDropdown} from 'react-bootstrap';
import { Link} from 'react-router-dom';
import './Event.css'

function OffCanvasExample({ name, ...props }) {
    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
  
    return (
      <>
        <Button variant="success" style={{"borderRadius":"100px 00px 00px 100px"}} onClick={handleShow} className="me-2  EventButton">
         + Event
        </Button>
        <Nav className="justify-content-end flex-grow-1 TaskNav" >
                <NavDropdown  className='EventDropDown'>
                <NavDropdown.Item href="#action3">Import Companies</NavDropdown.Item>
                <NavDropdown.Item href="#action4">Import Notes</NavDropdown.Item>
                </NavDropdown>
                </Nav>
        <Offcanvas show={show} onHide={handleClose} {...props}>
          <Offcanvas.Header closeButton>
            <Offcanvas.Title>Create Event</Offcanvas.Title>
          </Offcanvas.Header>
          <hr/>
          <Offcanvas.Body>
          <Form>
                          <Row className='d-flex'>
                            <Col><h6>Event Information</h6></Col>
                            <Col><p>Host : </p></Col>
                          </Row>
                        <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                          <Row>
                            <Col xs="3" lg="2"><Form.Label>Title</Form.Label></Col>
                            <Col xs="3" lg="10">
                               <Row>
                                <Col lg="3"><Form.Control type="date" placeholder="New Event" autoFocus/></Col>
                                <Col lg="3"><Form.Control type="time" placeholder="New Event" autoFocus/></Col>
                                <Col lg="3"><Form.Control type="time" placeholder="New Event" autoFocus/></Col>
                                <Col lg="3"><Form.Control type="date" placeholder="New Event" autoFocus/></Col>
                               </Row>
                              </Col>
                          </Row>
                          </Form.Group>
                          <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                          <Row>
                            <Col xs="3" lg="4"><Form.Label>Date & time</Form.Label></Col>
                            <Col xs="3" lg="8"><Form.Control
                              type="text"
                              placeholder="Enter Code"
                              autoFocus
                              /></Col>
                          </Row>
                          </Form.Group>
                          <Form.Group className="mb-3" id="formGridCheckbox">
                          <Form.Check type="checkbox" label="Repeat" />
                          </Form.Group>

                          <Form.Group className="mb-3" id="formGridCheckbox">
                          <Form.Check type="checkbox" label="Remainder" />
                          </Form.Group>

                          <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                          <Row>
                            <Col xs="3" lg="4"><Form.Label>Location</Form.Label></Col>
                            <Col xs="3" lg="8"><Form.Control
                              type="text"
                              placeholder="Location"
                              autoFocus
                              /></Col>
                          </Row>
                          </Form.Group>
                          <Form.Group className="mb-3" id="formGridCheckbox">
                          <Form.Check type="checkbox" label="Online Meeting" ><span className='bi bi-exclamation-lg'></span></Form.Check>
                          </Form.Group>
                          <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                          <Row>
                            <Col xs="3" lg="4"><Form.Label>Related To</Form.Label></Col>
                            <Col xs="3" lg="8"><Form.Control
                              type="text"
                              placeholder="Search Contacts/Companies/Deals"
                              autoFocus
                              /></Col>
                          </Row>
                          </Form.Group>
                          <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                          <Row>
                            <Col xs="3" lg="3"><Form.Label>Participants</Form.Label></Col>
                            <Col xs="3" lg="9"><Form.Control
                              type="text"
                              placeholder="Search Contacts,Users or invite people by email"
                              autoFocus
                              /></Col>
                          </Row>
                          </Form.Group>
                          <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                          <Row>
                            <Col xs="3" lg="4"><Form.Label>Description</Form.Label></Col>
                            <Col xs="3" lg="8"><Form.Control
                              type="text"
                              placeholder="A few words about this event"
                              autoFocus
                              /></Col>
                          </Row>
                          </Form.Group>
                        </Form>
                        <br/>
                        <hr/>
                        <Row className='d-flex justify-content-between'>
                          <Col xs="3" lg="6" ><Link to="/FieldSettings" >Field Settings</Link></Col>
                          <Col xs="3" lg="6" className='d-flex'>
                                <Button variant="white" onClick={handleClose} style={{"borderRadius":"100px 100px 100px 100px"}}>
                                  Cancel
                                </Button>
                              <Button variant="success" onClick={handleClose} style={{"borderRadius":"100px 100px 100px 100px"}}>
                                Save 
                              </Button>
                          </Col>
                        </Row>
          </Offcanvas.Body>
        </Offcanvas>
      </>
    );
  }

  
function Event() {
  return (
    <Container>
    <Row>
        <Col>
        {[ 'end' ].map((placement, idx) => (
                  <OffCanvasExample key={idx} placement={placement} name={placement} />
                 ))}
        </Col>
    </Row>
</Container>
  )
}

export default Event
