import React from 'react'
import { Col, Container, Row } from 'react-bootstrap'
import { Link,Routes,Route } from 'react-router-dom'

function UsersandControls() {
  return (
    <Container>
        <Row>
            <Col><Link to="Users">Users</Link></Col>
            <Col>1</Col>
            <Col>1</Col>
            <Col>1</Col>
        </Row>
        <Col>
        <Routes>
                <Route path='/usersandControls' element={<UsersandControls/>}  />
            </Routes>
        </Col>
    </Container>
  )
}

export default UsersandControls
