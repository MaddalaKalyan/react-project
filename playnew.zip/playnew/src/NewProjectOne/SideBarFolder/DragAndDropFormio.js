import React from 'react'
import { Container,Row } from 'react-bootstrap'
import { FormBuilder } from "@formio/react";

export const DragAndDropFormio = () => {
  return (
    <Container>
        <Row>
        <FormBuilder
    form={{ display: "form" }}
    onChange={schema => console.log(JSON.stringify(schema))}
  />,
        </Row>
    </Container>
  )
}
