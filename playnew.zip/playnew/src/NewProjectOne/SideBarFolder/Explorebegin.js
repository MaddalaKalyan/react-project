import React from 'react';
import { Button, Card, Col, Container,Form, Row } from 'react-bootstrap';

function Explorebegin() {
  return (
    <Container>
    <br/>
        <Card className='w-50'>
            <Card.Title>
                <h4>Fill Some Basic Details</h4>
            </Card.Title>
            <hr/>
            <Card.Body>
                <Form>
                <Row>
                    <Col ><Form.Label>Profile Name</Form.Label></Col>
                    <Col ><Form.Control type="text" placeholder="Enter Name" /></Col>
                   </Row><br/>
                   <Row>
                    <Col ><Form.Label>Email</Form.Label></Col>
                    <Col ><Form.Control type="email" placeholder="Enter email" /></Col>
                   </Row><br/>
                   <Row>
                    <Col ><Form.Label>Mobile</Form.Label></Col>
                    <Col ><Form.Control type="number" placeholder="Enter Mobile Number" /></Col>
                   </Row><br/>
                   <Row>
                    <Col ><Form.Label>Time Zone</Form.Label></Col>
                    <Col ><Form.Control type="time" placeholder="Enter Time" /></Col>
                   </Row><br/>
                   <Row>
                    <Col ><Form.Label>Language</Form.Label></Col>
                    <Col ><Form.Select aria-label="Default select example">
                          <option> select menu</option>
                          <option value="1">English(United States)</option>
                          <option value="2">Chines</option>
                        </Form.Select>
                    </Col>
                   </Row>
                   <Row>
                     <Col style={{"float":"right"}}>
                     <Button type='submit' variant='success'>Submit</Button>
                     </Col>
                   </Row>
                </Form>
            </Card.Body>
        </Card>
    </Container>
  )
}

export default Explorebegin
