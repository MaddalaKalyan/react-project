import React from 'react'
import { Container,Row } from 'react-bootstrap';
import { useQuill } from "react-quilljs";
import "quill/dist/quill.snow.css"; 
import { Outlet } from 'react-router-dom';

const TemplateEmail = () => {
    const { quill, quillRef } = useQuill();

    console.log(quill); // undefined > Quill Object
    console.log(quillRef); // { current: undefined } > { current: Quill Editor Reference }
  
    
  return (
    <Container style={{ width: 500, height: 300 }}>
       <Row ref={quillRef}></Row>
       <Row>
        <Outlet/>
       </Row>
    </Container>
  )
}

export default TemplateEmail