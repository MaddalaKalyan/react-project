import {React,useState} from 'react'
import { Col, Container,Row,Dropdown, Button,Form,Modal} from 'react-bootstrap'
import { Outlet,Link } from 'react-router-dom'
import './Template.css'
import TemplateCard from './TemplateCard'







const Template = () => {
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  
  return (
   <Container>
    <Row className='TeRow1'>
      <Col xs="4" lg="6" className='TeCol1'>
      <Dropdown className='TeDD1'>
        <Dropdown.Toggle variant="light"  className='TeDD1'> All Templates</Dropdown.Toggle>
           <Dropdown.Menu   className='TeDDMenu1'>
           <Dropdown.Item className='DDII1'>VIEWS</Dropdown.Item>
           <Dropdown.Item className='DDII2'><Link to="TemplateAllTemplates">All Templates</Link></Dropdown.Item>
           <Dropdown.Item className='DDII2'><Link to="TemplateFavorites">Favorites</Link></Dropdown.Item>
           <Dropdown.Item className='DDII2'><Link to="TemplateCreatedByMi">Created By Me</Link></Dropdown.Item>
           <Dropdown.Item className='DDII2'><Link to="TemplateSharedWithMe">Shared With Me</Link></Dropdown.Item>
           <Dropdown.Item className='DDII1'>FOLDERS</Dropdown.Item>
           <Dropdown.Item className='DDII2'><Link to="TemplatePublicEmail ">Public Email Template</Link></Dropdown.Item>
           <Dropdown.Item ><Link><span className='bi bi-plus'>Create Floder</span></Link></Dropdown.Item>
        </Dropdown.Menu>
      </Dropdown>

      </Col>

      <Col xs="4" lg="6" className='TeCol2'>
      <Button variant="success" className='TeBu1 bi bi-plus' onClick={handleShow}>
       New Template
      </Button>

      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Create Email Template</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
              <Form.Label>Module</Form.Label>
              <Form.Select autoFocus>
                <option><Link to="TemplateContacts">Contacts</Link></option>
                <option>Deals</option>
                <option>Companies</option>
                <option>Task</option>
                <option>Events</option>
                <option>Calls</option>
              </Form.Select>

            </Form.Group>
           
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="light" onClick={handleClose}>
            Cancel
          </Button>
          
          <TemplateCard/>
    
     
        </Modal.Footer>
      </Modal>
      
    
      </Col>
    
    </Row>
    <Row><Outlet/></Row>
   
   </Container>
  )
}

export default Template