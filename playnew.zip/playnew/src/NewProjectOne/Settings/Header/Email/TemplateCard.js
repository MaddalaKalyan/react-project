import {React,useState} from 'react'
import {  Container, Row ,Col,Offcanvas,Button } from 'react-bootstrap'
import { Outlet } from 'react-router-dom';
import { useQuill } from "react-quilljs";
import "quill/dist/quill.snow.css"; 

function OffCanvasExample({ name, ...props }) {
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const { quill, quillRef } = useQuill();

    console.log(quill); // undefined > Quill Object
    console.log(quillRef); // { current: undefined } > { current: Quill Editor Reference }

  return (
    <>
      <Button variant="success" onClick={handleShow} className="me-2">
        {name}
      </Button>
      <Offcanvas show={show} onHide={handleClose} {...props}>
        <Offcanvas.Header closeButton>
          <Offcanvas.Title>Mail Template</Offcanvas.Title>
        </Offcanvas.Header>
        <Offcanvas.Body  style={{ width: 500, height: 300 }}>
        <Row ref={quillRef}></Row>
        </Offcanvas.Body>
      </Offcanvas>
    </>
  );
}

const TemplateCard = ({ name, ...props }) => {
  return (
   <Container>
     <Row>
      <Col>
      {[ 'end'].map((placement, idx) => (
        <OffCanvasExample key={idx} placement={placement} name={placement} />
      ))}
      </Col>
     </Row>
    <Row>
        <Outlet/>
    </Row>
   </Container>
  )
}

export default TemplateCard