import React from 'react';
import { Col, Container, Row ,Image, Button} from 'react-bootstrap';
import { Outlet,Link } from 'react-router-dom';
import Rocket from '../WorkFlows/img/Rocket.jpg';
const EmailInsights = () => {
  return (
    <Container>
    <Row className='text-center'>
        <Col md="12"xs="12" lg="12">
       <Image  src={Rocket} alt="image"  style={{"width":"500px" ,"height":"auto","margin-top":"28px"}}></Image> 

      
       <p>The Email Configuration feature is not a part of the 'Free' plan.
Please upgrade to our 'Express' plan to access premium features like this.</p>
</Col>
       <Row  className='text-center'>
        <Col>
       <Button variant="success"  style={{"border-radius":"100px 100px 100px 100px" ,"width":"200px" }}>< Link >Upgrade Now</Link></Button>
       </Col>
       </Row>
    </Row>
    <Row>
      
    </Row>
    <Row>
        <Outlet/>
    </Row>
  </Container>
  )
}

export default EmailInsights


