import React from 'react'
import  {Container,Row,Col,Card,} from 'react-bootstrap'
import { Outlet,Link } from 'react-router-dom'
import './Fields.css'
const Fields = () => {
  return (
    <Container className='FicC1'>
    <Row className='d-flex justify-content-between FicR1'>
       <Col  className='d-flex FicC1 ' xs="4" lg="6">
        <h6>Fields</h6>
       </Col>
       <Col xs="4" lg="6"  className='d-flex FicC2 '>
        
          <Link className='bi bi-question-circle FicCL'></Link>
          <Link className='bi bi-play-circle'></Link>
        
       </Col>
       </Row>
       <hr/>

      <Container className='FiContainer2 d-flex'>
      <Row className='FiRow2 d-flex'>
           <Col>
           <Card className='FiColCard1'>
          <Card.Header>Deals </Card.Header>
          <Card.Body>
            <Card.Title>Deal Information</Card.Title>
            <Card className='FiCard1'>
           <Row className='d-flex FiCardRow1'><Col className="FiCard4" style={{"margin-top":"10px","marginLeft":"10px"}}><p>Deal Name</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"17px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard2'>
           <Row className='d-flex FiCardRow2'><Col   className="FiCard4" style={{"margin-top":"10px","marginLeft":"10px"}}><p>CompanyName</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"35px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard1'>
           <Row className='d-flex FiCardRow1'><Col  className="FiCard4" style={{"margin-top":"10px","marginLeft":"10px" }}><p>Contact Name</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"17px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard2'>
           <Row className='d-flex FiCardRow2'><Col   className="FiCard4"style={{"margin-top":"10px","marginLeft":"10px"}}><p>SecondaryContact</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"35px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard1'>
           <Row className='d-flex FiCardRow1'><Col  className="FiCard4" style={{"margin-top":"10px","marginLeft":"10px" }}><p>Pipelines&Stages</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"17px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard2'>
           <Row className='d-flex FiCardRow2'><Col   className="FiCard4"style={{"margin-top":"10px","marginLeft":"10px"}}><p>Amount</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"35px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard1'>
           <Row className='d-flex FiCardRow1'><Col  className="FiCard4" style={{"margin-top":"10px","marginLeft":"10px" }}><p>Closing Date</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"17px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard2'>
           <Row className='d-flex FiCardRow2'><Col   className="FiCard4"style={{"margin-top":"10px","marginLeft":"10px"}}><p>Description</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"35px"}}></span></Col></Row>
            </Card>

          </Card.Body>
         
        
            <Card.Footer className='CardFooter'>
              <Row className='d-flex CardFooterCard1' >
                <Col xs="2" lg="6" className='CardFooterCol1'>
               
                <Card.Link href="#"> <span className='bi bi-plus '>CustomField
                </span></Card.Link>
          
                </Col>
                <Col  xs="2" lg="6" className='CardFooterCol2'>  <p> Use Custom Fields :</p> </Col>
              </Row>
              </Card.Footer>
           
          </Card>
           </Col>
           

















           


           <Col>
           <Card >
          <Card.Header>Deals </Card.Header>
          <Card.Body>
            <Card.Title>Deal Information</Card.Title>
            <Card className='FiCard1'>
           <Row className='d-flex FiCardRow1'><Col     className="FiCard4" style={{"margin-top":"10px","marginLeft":"10px"}}><p>Deal Name</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"17px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard2'>
           <Row className='d-flex FiCardRow2'><Col   className="FiCard4" style={{"margin-top":"10px","marginLeft":"10px"}}><p>CompanyName</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"35px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard1'>
           <Row className='d-flex FiCardRow1'><Col  className="FiCard4" style={{"margin-top":"10px","marginLeft":"10px" }}><p>Contact Name</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"17px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard2'>
           <Row className='d-flex FiCardRow2'><Col   className="FiCard4"style={{"margin-top":"10px","marginLeft":"10px"}}><p>SecondaryContact</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"35px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard1'>
           <Row className='d-flex FiCardRow1'><Col  className="FiCard4" style={{"margin-top":"10px","marginLeft":"10px" }}><p>Pipelines&Stages</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"17px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard2'>
           <Row className='d-flex FiCardRow2'><Col   className="FiCard4"style={{"margin-top":"10px","marginLeft":"10px"}}><p>Amount</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"35px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard1'>
           <Row className='d-flex FiCardRow1'><Col  className="FiCard4" style={{"margin-top":"10px","marginLeft":"10px" }}><p>Closing Date</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"17px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard2'>
           <Row className='d-flex FiCardRow2'><Col   className="FiCard4"style={{"margin-top":"10px","marginLeft":"10px"}}><p>Description</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"35px"}}></span></Col></Row>
            </Card>

          </Card.Body>
         
        
            <Card.Footer className='CardFooter'>
              <Row className='d-flex CardFooterCard1' >
                <Col xs="2" lg="6" className='CardFooterCol1'>
               
                <Card.Link href="#"> <span className='bi bi-plus '>CustomField
                </span></Card.Link>
          
                </Col>
                <Col  xs="2" lg="6" className='CardFooterCol2'>  <p> Use Custom Fields :</p> </Col>
              </Row>
              </Card.Footer>
           
          </Card>
           </Col>


           <Col>
           <Card >
          <Card.Header>Deals </Card.Header>
          <Card.Body>
            <Card.Title>Deal Information</Card.Title>
            <Card className='FiCard1'>
           <Row className='d-flex FiCardRow1'><Col     className="FiCard4" style={{"margin-top":"10px","marginLeft":"10px"}}><p>Deal Name</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"17px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard2'>
           <Row className='d-flex FiCardRow2'><Col   className="FiCard4" style={{"margin-top":"10px","marginLeft":"10px"}}><p>CompanyName</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"35px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard1'>
           <Row className='d-flex FiCardRow1'><Col  className="FiCard4" style={{"margin-top":"10px","marginLeft":"10px" }}><p>Contact Name</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"17px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard2'>
           <Row className='d-flex FiCardRow2'><Col   className="FiCard4"style={{"margin-top":"10px","marginLeft":"10px"}}><p>SecondaryContact</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"35px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard1'>
           <Row className='d-flex FiCardRow1'><Col  className="FiCard4" style={{"margin-top":"10px","marginLeft":"10px" }}><p>Pipelines&Stages</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"17px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard2'>
           <Row className='d-flex FiCardRow2'><Col   className="FiCard4"style={{"margin-top":"10px","marginLeft":"10px"}}><p>Amount</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"35px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard1'>
           <Row className='d-flex FiCardRow1'><Col  className="FiCard4" style={{"margin-top":"10px","marginLeft":"10px" }}><p>Closing Date</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"17px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard2'>
           <Row className='d-flex FiCardRow2'><Col   className="FiCard4"style={{"margin-top":"10px","marginLeft":"10px"}}><p>Description</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"35px"}}></span></Col></Row>
            </Card>

          </Card.Body>
         
        
            <Card.Footer className='CardFooter'>
              <Row className='d-flex CardFooterCard1' >
                <Col xs="2" lg="6" className='CardFooterCol1'>
               
                <Card.Link href="#"> <span className='bi bi-plus '>CustomField
                </span></Card.Link>
          
                </Col>
                <Col  xs="2" lg="6" className='CardFooterCol2'>  <p> Use Custom Fields :</p> </Col>
              </Row>
              </Card.Footer>
           
          </Card>
           </Col>




           <Col>
           <Card >
          <Card.Header>Deals </Card.Header>
          <Card.Body>
            <Card.Title>Deal Information</Card.Title>
            <Card className='FiCard1'>
           <Row className='d-flex FiCardRow1'><Col     className="FiCard4" style={{"margin-top":"10px","marginLeft":"10px"}}><p>Deal Name</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"17px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard2'>
           <Row className='d-flex FiCardRow2'><Col   className="FiCard4" style={{"margin-top":"10px","marginLeft":"10px"}}><p>CompanyName</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"35px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard1'>
           <Row className='d-flex FiCardRow1'><Col  className="FiCard4" style={{"margin-top":"10px","marginLeft":"10px" }}><p>Contact Name</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"17px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard2'>
           <Row className='d-flex FiCardRow2'><Col   className="FiCard4"style={{"margin-top":"10px","marginLeft":"10px"}}><p>SecondaryContact</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"35px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard1'>
           <Row className='d-flex FiCardRow1'><Col  className="FiCard4" style={{"margin-top":"10px","marginLeft":"10px" }}><p>Pipelines&Stages</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"17px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard2'>
           <Row className='d-flex FiCardRow2'><Col   className="FiCard4"style={{"margin-top":"10px","marginLeft":"10px"}}><p>Amount</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"35px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard1'>
           <Row className='d-flex FiCardRow1'><Col  className="FiCard4" style={{"margin-top":"10px","marginLeft":"10px" }}><p>Closing Date</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"17px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard2'>
           <Row className='d-flex FiCardRow2'><Col   className="FiCard4"style={{"margin-top":"10px","marginLeft":"10px"}}><p>Description</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"35px"}}></span></Col></Row>
            </Card>

          </Card.Body>
         
        
            <Card.Footer className='CardFooter'>
              <Row className='d-flex CardFooterCard1' >
                <Col xs="2" lg="6" className='CardFooterCol1'>
               
                <Card.Link href="#"> <span className='bi bi-plus '>CustomField
                </span></Card.Link>
          
                </Col>
                <Col  xs="2" lg="6" className='CardFooterCol2'>  <p> Use Custom Fields :</p> </Col>
              </Row>
              </Card.Footer>
           
          </Card>
           </Col>


           <Col>
           <Card >
          <Card.Header>Deals </Card.Header>
          <Card.Body>
            <Card.Title>Deal Information</Card.Title>
            <Card className='FiCard1'>
           <Row className='d-flex FiCardRow1'><Col     className="FiCard4" style={{"margin-top":"10px","marginLeft":"10px"}}><p>Deal Name</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"17px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard2'>
           <Row className='d-flex FiCardRow2'><Col   className="FiCard4" style={{"margin-top":"10px","marginLeft":"10px"}}><p>CompanyName</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"35px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard1'>
           <Row className='d-flex FiCardRow1'><Col  className="FiCard4" style={{"margin-top":"10px","marginLeft":"10px" }}><p>Contact Name</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"17px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard2'>
           <Row className='d-flex FiCardRow2'><Col   className="FiCard4"style={{"margin-top":"10px","marginLeft":"10px"}}><p>SecondaryContact</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"35px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard1'>
           <Row className='d-flex FiCardRow1'><Col  className="FiCard4" style={{"margin-top":"10px","marginLeft":"10px" }}><p>Pipelines&Stages</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"17px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard2'>
           <Row className='d-flex FiCardRow2'><Col   className="FiCard4"style={{"margin-top":"10px","marginLeft":"10px"}}><p>Amount</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"35px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard1'>
           <Row className='d-flex FiCardRow1'><Col  className="FiCard4" style={{"margin-top":"10px","marginLeft":"10px" }}><p>Closing Date</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"17px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard2'>
           <Row className='d-flex FiCardRow2'><Col   className="FiCard4"style={{"margin-top":"10px","marginLeft":"10px"}}><p>Description</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"35px"}}></span></Col></Row>
            </Card>

          </Card.Body>
         
        
            <Card.Footer className='CardFooter'>
              <Row className='d-flex CardFooterCard1' >
                <Col xs="2" lg="6" className='CardFooterCol1'>
               
                <Card.Link href="#"> <span className='bi bi-plus '>CustomField
                </span></Card.Link>
          
                </Col>
                <Col  xs="2" lg="6" className='CardFooterCol2'>  <p> Use Custom Fields :</p> </Col>
              </Row>
              </Card.Footer>
           
          </Card>
           </Col>



           <Col>
           <Card >
          <Card.Header>Deals </Card.Header>
          <Card.Body>
            <Card.Title>Deal Information</Card.Title>
            <Card className='FiCard1'>
           <Row className='d-flex FiCardRow1'><Col     className="FiCard4" style={{"margin-top":"10px","marginLeft":"10px"}}><p>Deal Name</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"17px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard2'>
           <Row className='d-flex FiCardRow2'><Col   className="FiCard4" style={{"margin-top":"10px","marginLeft":"10px"}}><p>CompanyName</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"35px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard1'>
           <Row className='d-flex FiCardRow1'><Col  className="FiCard4" style={{"margin-top":"10px","marginLeft":"10px" }}><p>Contact Name</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"17px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard2'>
           <Row className='d-flex FiCardRow2'><Col   className="FiCard4"style={{"margin-top":"10px","marginLeft":"10px"}}><p>SecondaryContact</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"35px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard1'>
           <Row className='d-flex FiCardRow1'><Col  className="FiCard4" style={{"margin-top":"10px","marginLeft":"10px" }}><p>Pipelines&Stages</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"17px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard2'>
           <Row className='d-flex FiCardRow2'><Col   className="FiCard4"style={{"margin-top":"10px","marginLeft":"10px"}}><p>Amount</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"35px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard1'>
           <Row className='d-flex FiCardRow1'><Col  className="FiCard4" style={{"margin-top":"10px","marginLeft":"10px" }}><p>Closing Date</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"17px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard2'>
           <Row className='d-flex FiCardRow2'><Col   className="FiCard4"style={{"margin-top":"10px","marginLeft":"10px"}}><p>Description</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"35px"}}></span></Col></Row>
            </Card>

          </Card.Body>
         
        
            <Card.Footer className='CardFooter'>
              <Row className='d-flex CardFooterCard1' >
                <Col xs="2" lg="6" className='CardFooterCol1'>
               
                <Card.Link href="#"> <span className='bi bi-plus '>CustomField
                </span></Card.Link>
          
                </Col>
                <Col  xs="2" lg="6" className='CardFooterCol2'>  <p> Use Custom Fields :</p> </Col>
              </Row>
              </Card.Footer>
           
          </Card>
           </Col>












           <Col>
           <Card >
          <Card.Header>Deals </Card.Header>
          <Card.Body>
            <Card.Title>Deal Information</Card.Title>
            <Card className='FiCard1'>
           <Row className='d-flex FiCardRow1'><Col     className="FiCard4" style={{"margin-top":"10px","marginLeft":"10px"}}><p>Deal Name</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"17px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard2'>
           <Row className='d-flex FiCardRow2'><Col   className="FiCard4" style={{"margin-top":"10px","marginLeft":"10px"}}><p>CompanyName</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"35px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard1'>
           <Row className='d-flex FiCardRow1'><Col  className="FiCard4" style={{"margin-top":"10px","marginLeft":"10px" }}><p>Contact Name</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"17px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard2'>
           <Row className='d-flex FiCardRow2'><Col   className="FiCard4"style={{"margin-top":"10px","marginLeft":"10px"}}><p>SecondaryContact</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"35px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard1'>
           <Row className='d-flex FiCardRow1'><Col  className="FiCard4" style={{"margin-top":"10px","marginLeft":"10px" }}><p>Pipelines&Stages</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"17px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard2'>
           <Row className='d-flex FiCardRow2'><Col   className="FiCard4"style={{"margin-top":"10px","marginLeft":"10px"}}><p>Amount</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"35px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard1'>
           <Row className='d-flex FiCardRow1'><Col  className="FiCard4" style={{"margin-top":"10px","marginLeft":"10px" }}><p>Closing Date</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"17px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard2'>
           <Row className='d-flex FiCardRow2'><Col   className="FiCard4"style={{"margin-top":"10px","marginLeft":"10px"}}><p>Description</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"35px"}}></span></Col></Row>
            </Card>

          </Card.Body>
         
        
            <Card.Footer className='CardFooter'>
              <Row className='d-flex CardFooterCard1' >
                <Col xs="2" lg="6" className='CardFooterCol1'>
               
                <Card.Link href="#"> <span className='bi bi-plus '>CustomField
                </span></Card.Link>
          
                </Col>
                <Col  xs="2" lg="6" className='CardFooterCol2'>  <p> Use Custom Fields :</p> </Col>
              </Row>
              </Card.Footer>
           
          </Card>
           </Col>
           
          </Row>
      </Container>





        
    






         <Row>
            
         <Col>   <Outlet/> </Col>
         </Row>

   </Container>
  )
}

export default Fields
