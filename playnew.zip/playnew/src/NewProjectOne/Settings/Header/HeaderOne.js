
import React from 'react';
import { Container,Row,Col,Image,Button,Nav,Form,NavDropdown,Navbar, FormGroup} from 'react-bootstrap';

//import NavbarCollapse from 'react-bootstrap/esm/NavbarCollapse';
import { BrowserRouter, Link, Route,  Routes } from 'react-router-dom';
import TableOne from '../../TableOne';
import Logo1 from '../IMG/Logo1.svg'
import Account from './Account';
import CircleIcon from './CircleIcon';
import AuditLog from './DataAdmin/AuditLog';
import DataAdmin from './DataAdmin/DataAdmin';
import DataBackup from './DataAdmin/DataBackup';
import ExportData from './DataAdmin/ExportData';
import Import from './DataAdmin/Import';
import RecycleBin from './DataAdmin/RecycleBin';
import Storage from './DataAdmin/Storage';
import Dollor from './Dollor';
import Deliverability from './Email/Deliverability';
import EMail from './Email/EMail';
import Email1 from './Email/Email1';
import EmailInsights from './Email/EmailInsights';
import EMailsharing from './Email/EMailsharing';
import OrganizationEmail from './Email/OrganizationEmail';
import Template from './Email/Template';
import TemplateAllTemplates from './Email/TemplateAllTemplates';

import TemplateCreatedByMi from './Email/TemplateCreatedByMi';
import TemplateEmail from './Email/TemplateEmail';

import TemplateFavorites from './Email/TemplateFavorites';
import TemplatePublicEmail from './Email/TemplatePublicEmail';
import TemplateSharedWithMe from './Email/TemplateSharedWithMe';
import Fields from './Fields/Fields';
import './Header.css'
import AllTopings from './Integrations/AllTopings';
import Installed from './Integrations/Installed';
import Integrations from './Integrations/Integrations';
import IntegrationsSub from './Integrations/IntegrationsSub';
import Toppings from './Integrations/Toppings';
import Updates from './Integrations/Updates';
import Notifcation from './Notifcation';
import Currencies from './Organization/Currencies';
import Organization from './Organization/Organization';
import OrganizationDetails from './Organization/OrganizationDetails';
import PipeLineAndStages from './PipelinesandStages/PipeLineAndStages';
import PipeLines from './PipelinesandStages/PipeLines';
import RestrictDealClosure from './PipelinesandStages/RestrictDealClosure';
import StageTransitionRules from './PipelinesandStages/StageTransitionRules';
import TransitionRules from './PipelinesandStages/TransitionRules';
import Setting from './Setting';
import Compliance from './UsersAndControls/Compliance';
import GDPRCompliance from './UsersAndControls/GDPRCompliance';
import HIPAACompliance from './UsersAndControls/HIPAACompliance';
import Profiles from './UsersAndControls/Profiles';
import Roles from './UsersAndControls/Roles';
import UserAndControls from './UsersAndControls/UserAndControls';
import Users from './UsersAndControls/Users';
import Webforms from './WebForms/Webforms';
import WorkEx from './WorkFlows/WorkEx';
import Workflows from './WorkFlows/Workflows';
import FarmFunction from '../../FarmFunction';
import Farm from '../../Farm';
//import TriggerPage from '../../TriggerPage';
//import Condition from '../../Condition';
import EventTrigger from '../../EventTrigger';
import EventTrigger2 from '../../EventTrigger2.js';
import FarmThree from '../../FarmThreejs';
import AddedRow from '../../AddedRow';
import APIONe from './APIFolder/APIONe';
import AllContacts from '../SideBarFolder/Contactfolder/AllContacts';
import MailingLabels from '../SideBarFolder/Contactfolder/MailingLabels';
import MyContacts from '../SideBarFolder/Contactfolder/MyContacts';
import NewLastWeek from '../SideBarFolder/Contactfolder/NewLastWeek';
import NewThisWeek from '../SideBarFolder/Contactfolder/NewThisWeek';
import RecentlyCreatedContacts from '../SideBarFolder/Contactfolder/RecentlyCreatedContacts';
import RecentlyModifiedContacts from '../SideBarFolder/Contactfolder/RecentlyModifiedContacts';
import NotYetViewed from '../SideBarFolder/Contactfolder/NotYetViewed';
import UnsubscribedContacts from '../SideBarFolder/Contactfolder/UnsubscribedContacts';
import Companies from '../SideBarFolder/Companies';
import AllCompanies from '../SideBarFolder/Companies/AllCompanies';
import MyCompanies from '../SideBarFolder/Companies/MyCompanies';
import NewLastweeks from '../SideBarFolder/Companies/NewLastweeks';
import NewThisWeeks from '../SideBarFolder/Companies/NewThisWeeks';
import RecentlyModifiedCompanies from '../SideBarFolder/Companies/RecentlyModifiedCompanies';
import NotYetView from '../SideBarFolder/Companies/NotYetView';
import RecentlyCreatedCompanys from '../SideBarFolder/Companies/RecentlyCreatedCompanys';
import Products from '../SideBarFolder/Products';
import Activities from '../SideBarFolder/Activities';
import Tasks from '../SideBarFolder/Activities/Tasks';
import AllTasks from '../SideBarFolder/Tasks/AllTasks';
import ClosedTasks from '../SideBarFolder/Tasks/ClosedTasks';
import MyOpenTasks from '../SideBarFolder/Tasks/MyOpenTasks';
import Opentasks from '../SideBarFolder/Tasks/Opentasks';
import OverdueTasks from '../SideBarFolder/Tasks/OverdueTasks';
import TodayOverdueTasks from '../SideBarFolder/Tasks/TodayOverdueTasks';
import TodaysTasks from '../SideBarFolder/Tasks/TodaysTasks';
import TomorrowTasks from '../SideBarFolder/Tasks/TomorrowTasks';
import Next7DaysOverdue from '../SideBarFolder/Tasks/Next7DaysOverdue';
import Events from '../SideBarFolder/Activities/Events';
import Calls from '../SideBarFolder/Activities/Calls';
import Dashboards from '../SideBarFolder/Dashboards';
//import Templates from './Templates';
import Overview from '../SideBarFolder/Dashboard/Overview';
import DealsDashboard from '../SideBarFolder/Dashboard/DealsDashboard';
import TaskDashboard from '../SideBarFolder/Dashboard/TaskDashboard';
import EventsDashboard from '../SideBarFolder/Dashboard/EventsDashboard';
import CallAnalytics from '../SideBarFolder/Dashboard/CallAnalytics';
import EmailAnalytics from '../SideBarFolder/Dashboard/EmailAnalytics';
import CallsbyUsers from '../SideBarFolder/Dashboard/CallsbyUsers';
import DashboardCharts from '../SideBarFolder/DashboardCharts';
import Deals from '../SideBarFolder/Deals'
import Contacts from '../SideBarFolder/Contacts';



import Footer4C3 from '../Footer/Footer4C3';
import APIPage from './APIPage';
import Decision from './Decision';

import TablesPage from './TablesPage';
import CreateTable from './APIFolder/CreateTable';



const HeaderOne = () => {
  return (
   <Container fluid className='HeaderForm'>
      <BrowserRouter>
         <Row className='Cls'>
          <Col sm="2" md="2" lg="1" className='d-flex cls1' >
              <Image src={Logo1} alt="" style={{'width':'35px',"margin-top":"-35px" }}/>
           <h5 style={{"letterSpacing":"-1px"}}>Bigin</h5>
        </Col>
        <Col sm="4" md="2" lg="2" className='d-flex Cls1'>
        <Nav className="justify-content-end flex-grow-1 pe-2">
        <NavDropdown title="All" className='Cls2'>
        
                    <NavDropdown.Item href="#action3">Action</NavDropdown.Item>
                    <NavDropdown.Item href="#action4">
                      Another action
                    </NavDropdown.Item>
                    <NavDropdown.Divider />
                    <NavDropdown.Item href="#action5">
                      Something else here
                    </NavDropdown.Item> 
                  </NavDropdown>
                </Nav>
                <Form className="d-flex">
                  <Form.Control
                    type="search"
                    placeholder="Search"
                    className="Cls3"
                    aria-label="Search"
                  />
                  <Button variant="nocolor" placeholder='search' className="bi bi-search Cls4" type="search"></Button>
                
                </Form>
        </Col>
        <Col sm="2" md={{ span: 6, offset: 2}} lg={{ span: 2
          , offset: 6}} className='d-flex  HOCol2' >
        <Navbar expand="lg">
        <Navbar.Toggle aria-controls="navbarScroll" />
        <Navbar.Collapse id="navbarScroll">
          <Nav
            className="me-auto my-2 my-lg-0" style={{ maxHeight: '100px' }}  navbarScroll>
            <Nav.Link to="/Notifcation"><Notifcation/></Nav.Link>
            <Nav.Link to="/Dollor"><Dollor/></Nav.Link>
            <Nav.Link to="/CircleIcon"><CircleIcon/></Nav.Link>
            <Link to="/Setting"  className='bi bi-gear Icon 'id='Plus'></Link>
            <Nav.Link to='./Account'><Account/> </Nav.Link>
           
          </Nav>
        </Navbar.Collapse>
    </Navbar>
        </Col>
        <Col>
        <Routes>
           <Route path='/Setting' element={<Setting/>}>
                         <Route path='UserAndControls' element={<UserAndControls/>}>
                            <Route path='Profiles' element={<Profiles/>}></Route>
                            <Route path='Users' element={<Users/>}></Route>
                            <Route path='Roles' element={<Roles/>}></Route>
                            <Route path='Compliance' element={<Compliance/>}>
                            <Route path='GDPRCompliance' element={<GDPRCompliance/>}></Route>
                            <Route path='HIPAACompliance' element={<HIPAACompliance/>}></Route>
                         </Route>
                       </Route>
             <Route path='Organization' element={<Organization/>}>
                <Route path='Currencies' element={<Currencies/>}></Route>
                 <Route path='OrganizationDetails' element={<OrganizationDetails/>}></Route>
             </Route> 
              <Route path='Fields' element={<Fields/>}></Route>
                <Route path='PipeLineAndStages' element={<PipeLineAndStages/>}>
                <Route path='PipeLines' element={<PipeLines/>}></Route>
                <Route path='StageTransitionRules' element={<StageTransitionRules/>}>
                          <Route path='TransitionRules' element={<TransitionRules/>}></Route>
                          <Route path='RestrictDealClosure' element={<RestrictDealClosure/>}></Route>
                 </Route>
                 </Route>
                  <Route path="Integrations" element={<Integrations/>}></Route>
                   <Route path='Webforms' element={<Webforms/>}></Route>
                      <Route path='Workflows' element={<Workflows/>}>
                        <Route path='WorkEx' element={<WorkEx/>}>
                        
                        </Route>
                        <Route path='TableOne' element={<TableOne/>}>
                          <Route path='AddedRow' element={<AddedRow/>}></Route>
                          <Route path='EventTrigger2' element={<EventTrigger2/>}></Route>
                           <Route path='FarmFunction' element={<FarmFunction/>}></Route>          
                          <Route path='Farm' element={<Farm/>}></Route>
                          <Route path='FarmThree' element={<FarmThree/>}></Route>
                          
                        
                        </Route>
                       
                      </Route>
                      <Route path='DataAdmin' element={<DataAdmin/>}>
                        <Route path='Import' element={<Import/>}></Route>
                        <Route path='ExportData' element={<ExportData/>}></Route>
                        <Route path='DataBackUp' element={<DataBackup/>}></Route>
                        <Route path='RecycleBin' element={<RecycleBin/>}></Route>
                        <Route path='AuditLog' element={<AuditLog/>}></Route>
                        <Route path='Storage' element={<Storage/>}></Route>
                      </Route>
                      <Route path='Integrations' element={<Integrations/>}>
                        <Route path='IntegrationsSub' element={<IntegrationsSub/>}></Route>
                        <Route path='Toppings' element={<Toppings/>}>
                         <Route path='AllToppings' element={<AllTopings/>}></Route>
                         <Route path='Installed' element={<Installed/>}></Route>
                         <Route path='Updates' element={<Updates/>}></Route>
                        </Route>
                      </Route>
                      <Route path='EMail' element={<EMail/>}>
                        <Route path='Email1'element={<Email1/>}></Route>
                        <Route path='Template' element={<Template/>}>
                          <Route path="TemplateEmail" element={<TemplateEmail/>}></Route>
                          <Route path='TemplateAllTemplates' element={<TemplateAllTemplates/>}></Route>
                          <Route path='TemplateFavorites' element={<TemplateFavorites/>}></Route>
                          <Route path='TemplateCreatedByMi' element={<TemplateCreatedByMi/>}></Route>
                          <Route path='TemplateSharedWithMe' element={<TemplateSharedWithMe/>}></Route>
                          <Route path='TemplatePublicEmail ' element={<TemplatePublicEmail/>}></Route>
                          
                         
                        </Route>
                        <Route path='EmailSharing' element={<EMailsharing/>}></Route>
                        <Route path='EmailInsights' element={<EmailInsights/>}></Route>
                        <Route path='OrganizationEmail' element={<OrganizationEmail/>}></Route>
                        <Route path="Deliverability" element={<Deliverability/>}></Route>

                      </Route>
              <Route path='Decision' element={<Decision/>}></Route>          
             <Route path='APIPage' element={<APIPage/>}></Route>
             <Route path='APIONe' element={<APIONe/>}> </Route>
             <Route path='TablesPage' element={<TablesPage/>}>
              <Route path='CreateTable' element={<CreateTable/>}></Route>
             </Route>
                   </Route>

                 
             </Routes>
      </Col>
    </Row>
    {/*-----SiderBarPage-----------------*/}   
     <Row className='SidebarpageRow1' >
               <Col sm="2" lg="1" md="2"  className='list'>
                <ul>
              
        <Link to="/deals"><li  className="bi bi-hourglass-bottom"><br/>Deals</li></Link>
                <Link to="/contacts"><li className="bi bi-person-lines-fill">Contacts</li></Link>
                <Link to="/companies"><li className="bi bi-building">Companies</li></Link>
                <Link to="/products"><li className="bi bi-box2">Products</li></Link>
                <Link to="/activities"><li className="bi bi-calendar-check">Activities</li></Link>
                <Link to="/Dashboards"><li className="bi bi-pie-chart-fill">Dashboards</li></Link>
                
            </ul>
            </Col>
          
            <Col sm="6" lg="11" md="10"  className='container'>
                 <Routes>
                     <Route path="/deals" element={<Deals/>}>
                     <Route path='allcontacts' element={<AllContacts/>}></Route>
                     <Route path='mailingLabels' element={<MailingLabels/>}></Route>
                     <Route path='myContacts' element={<MyContacts/>}></Route>
                     <Route path='newLastWeek' element={<NewLastWeek/>}></Route>
                     <Route path='newThisWeek' element={<NewThisWeek/>}></Route>
                     <Route path='reacentlyCreatedContacts' element={<RecentlyCreatedContacts/>}></Route>
                     <Route path='recentlyModifiedContacts' element={<RecentlyModifiedContacts/>}></Route>
                     <Route path='notYetViewed' element={<NotYetViewed/>}></Route>
                     <Route path='unsubscribedContacts' element={<UnsubscribedContacts/>}></Route>
                     </Route>
                     <Route path='/contacts' element={<Contacts/>}>
                     <Route path='allcontacts' element={<AllContacts/>}></Route>
                     <Route path='mailingLabels' element={<MailingLabels/>}></Route>
                     <Route path='myContacts' element={<MyContacts/>}></Route>
                     <Route path='newLastWeek' element={<NewLastWeek/>}></Route>
                     <Route path='newThisWeek' element={<NewThisWeek/>}></Route>
                     <Route path='reacentlyCreatedContacts' element={<RecentlyCreatedContacts/>}></Route>
                     <Route path='recentlyModifiedContacts' element={<RecentlyModifiedContacts/>}></Route>
                     <Route path='notYetViewed' element={<NotYetViewed/>}></Route>
                     <Route path='unsubscribedContacts' element={<UnsubscribedContacts/>}></Route>
                   </Route>
                   <Route path='/companies' element={<Companies/>}>
                      <Route path='AllCompanies' element={<AllCompanies/>}></Route>
                      <Route path='MyCompanies' element={<MyCompanies/>}></Route>
                      <Route path='NewLastweeks' element={<NewLastweeks/>}></Route>
                      <Route path='NewThisWeeks' element={<NewThisWeeks/>}></Route>
                      <Route path='RecentlyCreatedCompanys' element={<RecentlyCreatedCompanys/>}></Route>
                      <Route path='RecentlyModifiedCompanies' element={<RecentlyModifiedCompanies/>}></Route>
                      <Route path='NotYetView' element={<NotYetView/>}></Route>
                   </Route>
                   <Route path='/Products' element={<Products/>}>
                     
                   </Route>
                   <Route path='/Activities' element={<Activities/>}>
                      <Route path='Tasks' element={<Tasks/>}>
                        <Route path='AllTasks' element={<AllTasks/>}></Route>
                        <Route path='ClosedTasks' element={<ClosedTasks/>}></Route>
                        <Route path='MyOpenTasks' element={<MyOpenTasks/>}></Route>
                        <Route path='Next7DaysOverdue' element={<Next7DaysOverdue/>}></Route>
                        <Route path='Opentasks' element={<Opentasks/>}></Route>
                        <Route path='OverdueTasks' element={<OverdueTasks/>}></Route>
                        <Route path='TodayOverdueTasks' element={<TodayOverdueTasks/>}></Route>
                        <Route path='TodaysTasks' element={<TodaysTasks/>}></Route>
                        <Route path='TomorrowTasks' element={<TomorrowTasks/>}></Route>
                      </Route>
                      <Route path='Events' element={<Events/>}></Route>
                      <Route path='Calls' element={<Calls/>}></Route>
                   </Route>
                    <Route path='/Dashboards' element={<Dashboards/>}>
                       <Route path='Overview' element={<Overview/>}></Route>
                       <Route path='DealsDashboard' element={<DealsDashboard/>}></Route>
                       <Route path='TaskDashboard' element={<TaskDashboard/>}></Route>
                       <Route path='EventsDashboard' element={<EventsDashboard/>}></Route>
                       <Route path='CallAnalytics' element={<CallAnalytics/>}></Route>
                       <Route path='EmailAnalytics' element={<EmailAnalytics/>}></Route>
                       <Route path='CallsbyUsers' element={<CallsbyUsers/>}></Route>
                       <Route path='DashboardCharts' element={<DashboardCharts/>}></Route>
                    </Route>
                 
                 </Routes>
            </Col>
        </Row>
        <Row>
       
          <Routes>
            <Route path='/Footer4C3' element={<Footer4C3/>}></Route>
          </Routes>
        </Row>
    </BrowserRouter>
   </Container>
  )
}

export default HeaderOne
