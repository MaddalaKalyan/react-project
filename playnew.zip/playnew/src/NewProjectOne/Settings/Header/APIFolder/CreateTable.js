import {React ,useState} from 'react';
import { Container, Row ,Button,Offcanvas,Form,Col, Card,Tab,Tabs, Nav, Table} from 'react-bootstrap';
import { Tbody, Thead, Tr,Td,Th } from 'react-super-responsive-table';
import AddRowinOffCanVas from './AddRowinOffCanvas';











const CreateTable = () => {
    function OffCanvasExample({ name, ...props }) {
        const [show, setShow] = useState(false);
      
        const handleClose = () => setShow(false);
        const handleShow = () => setShow(true);




        const [rows, setRows] = useState([{}]);
        const columnsArray = [''] ; // pass columns here dynamically
        const columnsArray1 = [''];
      
        
        const handleAddRow = () => {
          const item = {};
          setRows([...rows, item]);
        };
      
        const postResults = () => {
          console.log(rows); // there you go, do as you please
        };
        const handleRemoveSpecificRow = (idx) => {
          const tempRows = [...rows]; // to avoid  direct state mutation
          tempRows.splice(idx, 1);
          setRows(tempRows);
        };
      
        const updateState = (e) => {
          let prope = e.target.attributes.column.value; // the custom column attribute
          let index = e.target.attributes.index.value; // index of state array -rows
          let fieldValue = e.target.value; // value
      
          const tempRows = [...rows]; // avoid direct state mutation
          const tempObj = rows[index+1]; // copy state object at index to a temporary object
          tempObj[prope] = fieldValue; // modify temporary object
      
          // return object to rows` clone
          tempRows[index] = tempObj;
          setRows(tempRows); // update state
        };
      
        return (
          <>
            <Button variant="primary"  onClick={handleShow}>
          CREATETABLE<span className='bi bi-plus-circle '></span>
            </Button>  
            <Offcanvas show={show} onHide={handleClose} {...props} style={{"width":"700px"}}>
              <Offcanvas.Header closeButton>
                <Offcanvas.Title>
             TABLE DESCRIPTION
                </Offcanvas.Title>
              </Offcanvas.Header>
                <Offcanvas.Body>
               <Container>
                <Row>
                    <Col className='d-flex justify-content-end'>
                    <Button>Bulk Import</Button>
                    <Nav.Link><AddRowinOffCanVas/></Nav.Link>
                    </Col>
                </Row>
                <br/>
               <Row>
                    <Col>
                    
                <Table>
                    <Thead>
                    <tr>
                  <th>S.no </th>
                 
                    <th>
                      
                      ColoumnOne
                    </th>
              
                    <th>
                       
                      ColoumnTwo
                    </th>
                  
                    <th >
                      
                      ColoumnThree
                    </th>
               
                    <th>
                      
                      ColoumnFour
                    </th>
                
                  <th>  <Button variant="success" className="bi bi-plus-circle" onClick={handleAddRow} ></Button>
                  </th>
                </tr>
                        
                    </Thead>
                    <Tbody>
                    {rows.map((item, idx) => (
                 <tr key={idx}>
                   <td>{idx + 1}</td>
                    {columnsArray.map((column, index) => (
                     <td key={index}>
                     
                    
                      </td>
                       
                      
                    ))}
                    
                     {columnsArray.map((column, index) => (
                   <td key={index}>
                       
                   
                     </td>
                     ))}
                       {columnsArray.map((column, index) => (
                   <td key={index}>
                     
                    </td>
                     ))}
                      {columnsArray.map((column, index) => (
                   <td key={index}>
                     
                    </td>
                     ))}
                    
                    <td>
                      <Button
                      variant="danger" className="bi bi-trash3"
                        onClick={() => handleRemoveSpecificRow(idx)}
                      ></Button>
                       <Button
                      variant="warning" className="bi bi-pen"
                       
                      ></Button>
                    
                    </td>
                    
                 
                  </tr>
                ))}
                    </Tbody>
                </Table></Col>
        
    
        {/* <Row> 
        <Tabs  defaultActiveKey="profile"
                                id="justify-tab-example"
                                selectedTabClassName="bg-white" justify>
                     <Tab eventKey="Send123"     
                             className="cursor-pointer py-4 px-8 bg-red-background border border-red-intermediate flex flex-grow"
                             title="Send"><Send123/></Tab>
                            <Tab eventKey="Receive" title="Receive"><Receive/></Tab>
                          </Tabs>
                  </Row>*/}
        
    </Row> 
</Container>

             

              </Offcanvas.Body>
            </Offcanvas>
          </>
        );
      }
      
  return (
    <Container>
        {['end'].map((placement, idx) => (
        <OffCanvasExample key={idx} placement={placement} name={placement} />
      ))}
   
    </Container>
  )
}

export default CreateTable