import {React ,useState,us} from 'react';
import { Container, Row ,Button,Offcanvas,Form,Col, Card,Tab,Tabs,InputGroup} from 'react-bootstrap';
import { Snackbar } from './snackbar';
import { useSnackbar } from './useSnackbar';






import Snackbar from '@mui/material/Snackbar';
import Fade from '@mui/material/Fade';
import Slide, { SlideProps } from '@mui/material/Slide';
import Grow, { GrowProps } from '@mui/material/Grow';
import { TransitionProps } from '@mui/material/transitions';





const AddRowinOffCanVas = () => {
    
    
    function OffCanvasExample({ name, ...props }) {
        const [show, setShow] = useState(false);
      
        const handleClose = () => setShow(false);
        const handleShow = () => setShow(true);
     



         const [state, setState] = React.useState<{
    open: boolean;
    Transition: React.ComponentType<
      TransitionProps & {
        children: React.ReactElement<any, any>;
      }
    >;
  }>({
    open: false,
    Transition: Fade,
  });

  const handleClick =
    (
      Transition: React.ComponentType<
        TransitionProps & {
          children: React.ReactElement<any, any>;
        }
      >,
    ) =>
    () => {
      setState({
        open: true,
        Transition,
      });
    };

  const handleClose = () => {
    setState({
      ...state,
      open: false,
    });
  };

        return (
          <>
            <Button variant="info" className=' '  onClick={handleShow}>
                Add Row
            </Button>  
            <Offcanvas show={show} onHide={handleClose} {...props} style={{"width":"600px"}}>
              <Offcanvas.Header closeButton>
                <Offcanvas.Title>
                 Table Components
                </Offcanvas.Title>
              </Offcanvas.Header>
              <Offcanvas.Body>
               <Container>
                    <Form noValidate>
                        <Row>
                            <Col className='d-flex justify-content-end' lg="4" md="4">
                            <Form.Label>TableName:</Form.Label> 
                            </Col>
                            <Col className='d-flex justify-content-start' lg="6" md="6">
                            <Form.Control     type="text"  id="inputPassword5"  aria-describedby="passwordHelpBlock"/></Col>
                        </Row>
                        <br/>
                        <Row>
                            <Col className='d-flex justify-content-end' lg="4" md="4">
                            <Form.Label >Display Name</Form.Label> 
                            </Col>
                            <Col className='d-flex justify-content-start' lg="6" md="6">
                            <Form.Control     type="text"  id="inputPassword5"  aria-describedby="passwordHelpBlock"/></Col>
                        </Row>
                        <br/>
                        <Row>
                            <Col className='d-flex justify-content-end' lg="4" md="4">
                            <Form.Label>Field Name:</Form.Label> 
                            </Col>
                            <Col className='d-flex justify-content-start' lg="6" md="6">
                            <Form.Control     type="text"  id="inputPassword5"  aria-describedby="passwordHelpBlock"/></Col>
                        </Row>
                        <br/>
                        <Row>
                            <Col className='d-flex justify-content-end' lg="4" md="4">
                            <Form.Label>Input Type:</Form.Label> 
                            </Col>
                            <Col className='d-flex justify-content-start' lg="6" md="6">
                            <Form.Select aria-label="Default select example">
                                <option>Open this select menu</option>
                                <option value="1">One</option>
                                <option value="2">Two</option>
                                <option value="3">Three</option>
                            </Form.Select>
                            </Col>
                        </Row>
                        <br/>
                        <Row>
                            <Col className='d-flex justify-content-end' lg="4" md="4">
                            <Form.Label>Constaint:</Form.Label> 
                            </Col>
                            <Col className='d-flex justify-content-start' lg="6" md="6">
                            <Form.Select aria-label="Default select example">
                                <option>Open this select menu</option>
                                <option value="1">One</option>
                                <option value="2">Two</option>
                                <option value="3">Three</option>
                            </Form.Select>
                            </Col>
                        </Row>
                        <br/>
                        <Row>
                            <Col className='d-flex justify-content-end' lg="4" md="4">
                            <Form.Label>Is Default:</Form.Label> 
                            </Col>
                            <Col className='d-flex justify-content-start' lg="6" md="6">
                               <InputGroup className="mb-3">
                              <InputGroup.Checkbox aria-label="Checkbox for following text input" />  </InputGroup>
                              
                            </Col>
                        </Row>
                        <br/>
                        <Row>
                            <Col className='d-flex justify-content-end' lg="4" md="4">
                            <Form.Label>Is Editable:</Form.Label> 
                            </Col>
                            <Col className='d-flex justify-content-start' lg="6" md="6">
                               <InputGroup className="mb-3">
                              <InputGroup.Checkbox aria-label="Checkbox for following text input" />  </InputGroup>
                              
                            </Col>
                        </Row>
                        <br/>
                        <Row>
                            <Col className='d-flex justify-content-end' lg="4" md="4">
                            <Form.Label>Is Unique:</Form.Label> 
                            </Col>
                            <Col className='d-flex justify-content-start' lg="6" md="6">
                               <InputGroup className="mb-3">
                              <InputGroup.Checkbox aria-label="Checkbox for following text input" />  </InputGroup>
                              
                            </Col>
                        </Row>
                        <br/>
                        <Row>
                            <Col className='d-flex justify-content-end' lg="4" md="4">
                            <Form.Label>AutoIncrement:</Form.Label> 
                            </Col>
                            <Col className='d-flex justify-content-start' lg="6" md="6">
                               <InputGroup className="mb-3">
                              <InputGroup.Checkbox aria-label="Checkbox for following text input" />  </InputGroup>
                              
                            </Col>
                        </Row>
                        <br/>
                        <Row>
                            <Col className='d-flex justify-content-end' lg="4" md="4">
                            <Form.Label>Is Unsigned:</Form.Label> 
                            </Col>
                            <Col className='d-flex justify-content-start' lg="6" md="6">
                               <InputGroup className="mb-3">
                              <InputGroup.Checkbox aria-label="Checkbox for following text input" />  </InputGroup>
                              
                            </Col>
                        </Row>
                        <br/>
                        <Row>
                            <Col className='d-flex justify-content-end' lg="4" md="4">
                            <Form.Label>Is Default:</Form.Label> 
                            </Col>
                            <Col className='d-flex justify-content-start' lg="6" md="6">
                               <InputGroup className="mb-3">
                              <InputGroup.Checkbox aria-label="Checkbox for following text input" />  </InputGroup>
                              
                            </Col>
                        </Row>
                        <br/>
                        <Row>
                            <Col className='d-flex justify-content-end' lg="4" md="4">
                            <Form.Label>Is Default:</Form.Label> 
                            </Col>
                            <Col className='d-flex justify-content-start' lg="6" md="6">
                               <InputGroup className="mb-3">
                              <InputGroup.Checkbox aria-label="Checkbox for following text input" />  </InputGroup>
                              
                            </Col>
                        </Row>
                        <br/>
                        <Row>
                            <Col className='d-flex justify-content-end' lg="4" md="4">
                            <Form.Label>Is Default:</Form.Label> 
                            </Col>
                            <Col className='d-flex justify-content-start' lg="6" md="6">
                               <InputGroup className="mb-3">
                              <InputGroup.Checkbox aria-label="Checkbox for following text input" />  </InputGroup>
                              
                            </Col>
                        </Row>
                        <br/>
                        <Row>
                            <Col className='d-flex justify-content-end' lg="2"> <Button variant='success' onClick={handleClick(GrowTransition)}>
                            <Snackbar
                                        open={state.open}
                                        onClose={handleClose}
                                        TransitionComponent={state.Transition}
                                        message="I love snacks"
                                        key={state.Transition.name}
                                    />Save</Button></Col>
                        </Row>
                    </Form>
               </Container>

             

              </Offcanvas.Body>
            </Offcanvas>
          </>
        );
      }
      
  return (
    <Container>
        {['end'].map((placement, idx) => (
        <OffCanvasExample key={idx} placement={placement} name={placement} />
      ))}
   
    </Container>
  )
}

export default AddRowinOffCanVas