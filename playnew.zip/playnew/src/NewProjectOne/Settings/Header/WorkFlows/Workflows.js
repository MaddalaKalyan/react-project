import {React,useState} from 'react'
import { Container,Row,Col,Table,Button ,Modal, Form} from 'react-bootstrap'
import {Thead,Th,Tr } from 'react-super-responsive-table'
import './Workflows.css'
import { Outlet,Link } from 'react-router-dom'

const Workflows = () => {

    const [show, setShow] = useState(false);
  
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
  return (
    <Container fluid className='wfContaine' style={{"overflow":"scroll","height":"750px" ,"width":"100%"}}>
    <Row className='wfrow1'>
      <Col xs="4" lg="8"className="wfcol1" ><h6>Work flows</h6>
      <p>With workflows, you can trigger automatic actions when records match 
        specified criteria. Workflows can trigger email alerts, create tasks, update fields, and tag or untag matching records..</p>
      </Col>
      <Col  xs="2"lg="2" className='wfCol2'>
          <Button variant='success' type='submit' onClick={handleShow} className='wfbu3' ><span className='bi bi-plus'>NewWorkflows</span></Button>
      <Modal show={show} onHide={handleClose} animation={false}>
        <Modal.Header closeButton>
          <Modal.Title>Create New Workflow</Modal.Title>
        </Modal.Header>
        <Modal.Body>
         <Form>
         <Form.Group>
          <Row className='d-flex'>
            <Col className='d-flex   xs={4} md={4}'><Form.Label>Modules</Form.Label></Col>
            <Col className='d-flex justify-content-start  xs={8} md={8}'>
            <Form.Select aria-label="Default select example">
                  <option></option>
                  <option value="1">Contacts</option>
                  <option value="2">Deals</option>
                  <option value="2">Companies</option>
                  <option value="3">Tasks</option>
                  <option value="4">Events</option>
            </Form.Select>
            </Col>
          </Row>
          <Row className='d-flex' style={{"marginTop":'20px'}}>
            
            <Col className=' xs={4} md={4}'>Work Name</Col>
            <Col className=' xs={8} md={8}'><Form.Control
          placeholder=" Enter Work flow Name"
          aria-label="Enter Work flow Name"
          aria-describedby="basic-addon1"
        /></Col>
          </Row>
          <Row className='d-flex' style={{"marginTop":'20px'}}>
            
            <Col className=' xs={4} md={4}'>Description</Col>
            <Col className=' xs={8} md={8}'><Form.Control
          
          aria-describedby="basic-addon1"
        /></Col>
          </Row>

         </Form.Group>
         </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="light" onClick={handleClose} style={{"border-radius":'100px 100px 100px 100px'}}>
            Cancel
          </Button>
          <Button variant="success" onClick={handleClose} style={{"border-radius":'100px 100px 100px 100px'}}>
            <Link to="WorkEx">Next</Link>
          </Button>
        </Modal.Footer>
      </Modal>
      </Col>
      <Col xs="2" lg="1" className='wfcol3 d-flex justify-content-end'><span className='bi bi-question wfIcon2'></span></Col>

    </Row>
      
        <Row className='wfrow'>
        <Col  xs="6" lg="12" className='wfcol4'>
        <Table striped bordered hover>
         <Thead>
          <Tr >
            <Th>Workflow Name</Th>
            <Th>All Modules <span className='bi bi-filter'style={{'margin-left':"20px"}}></span></Th>
            <Th>Actions</Th>
            <Th>Execute On</Th>
            <Th>Last Modified</Th>
            <Th>All Status <span className='bi bi-filter' style={{'margin-left':"20px"}}></span> </Th>
          </Tr>
         </Thead>
        </Table>
        </Col>
      </Row>
      <Row className='wfrow2'>
          <Col>Big Deal Rule</Col>
          <Col><Link to="TableOne">Deals</Link></Col>
          <Col>1</Col>
          <Col>Create or Edit</Col>
          <Col> <Form>
      <Form.Check 
       className='wficon1'
        type="switch"
        id="custom-switch"
        label="Check this switch" />
        </Form></Col>
        
      </Row>
      <Row className='body'>
       <Container className='loader'>
        <div className='circle One'></div>
        <div className='circle Two'></div>
        <div className='circle Three' ></div>
        
      </Container>  
      </Row>
  
       
      <Outlet/>
 
 </Container>
  )
}

export default Workflows