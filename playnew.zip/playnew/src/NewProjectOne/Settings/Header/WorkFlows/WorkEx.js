import {React,useState }from 'react'
import { Button, Card, Container, Row,Col,Modal,Image } from 'react-bootstrap'
import { Outlet } from 'react-router-dom'
import './WorkFlowEx.css';
import Rocket from './img/Rocket.jpg';

const WorkEx = () => {
    const [lgShow, setLgShow] = useState(false);
  return (
  <Container fluid className="WorkFlow">
    <Row className='WorkFlowRowOne'>
      <Col md={{ span: 6, offset: 2}} className=''>
      <Card>
        <Card.Header>
          <Row> <Col><span className='WebFlowSpan'>1. Trigger</span> </Col></Row>
          <Row><Col md={{span:8 ,offset:1} }>
            <Row> <Col> On a Record Action </Col>
          <Col className='WorkFlowCols'>
          <Button onClick={() => setLgShow(true)} variant="light">On a Date /Time</Button>    
          <Modal
                size="lg"
                show={lgShow}
                onHide={() => setLgShow(false)}
                aria-labelledby="example-modal-sizes-title-lg"
                className='ModalMain'>
                    <Modal.Header closeButton>
                    </Modal.Header>
                    <Modal.Body> <Image src={Rocket} className="IMG"></Image>
                    <Modal.Title>
                    <span>Upgrade to primer</span>
                        <p>The Date/Time Triggers feature is not a part of the 'Free' plan.
                           Please upgrade to our 'Premier' plan to access premium features like this.</p>
                    </Modal.Title>
                           </Modal.Body>
                                <Modal.Footer>
                              <Button variant='success'>Upgrade Now</Button>
                                 </Modal.Footer>
      </Modal>
      </Col>
      <Col>  <h6>primer</h6> </Col>
        </Row></Col>

          </Row>
          </Card.Header>
          <Card.Body>
            <Row><Col>Trigger this workflow when a deal is <Button variant='light'>Edited</Button></Col></Row>
            <Row>
                <Col>
                <input type={'radio'} name="isvisible" required="required" value="true" />Created
               </Col>
            </Row>  
            <Row>
                <Col>
                <input type={'radio'} name="isdefault" value="true" required="required"  />Created or Edited
                    
               </Col>
            </Row>  
            <Row>
                <Col>
                <input type={'radio'} name="isvisible" required="required" value="true" />
                Edited
               </Col>
            </Row>  
          </Card.Body>
          <Card.Footer>
            <Row><Col className="d-flex justify-content-end">
                <Button variant="success" style={{"border-radius":"100px 100px 100px 100px"}}>Next</Button></Col></Row>
          </Card.Footer>
       </Card>

      </Col>
    </Row>
    <Row>
      <Col md={{ span: 8, offset: 1 }} className=''>
      <Card>
      <Card.Body>
          <Row> <Col><h6>2.Conditions</h6> </Col></Row>
          <Row><Col md={{span:8 ,offset:1} }>
             <h6>Which Contacts would you like to apply the workflow to?</h6>   </Col>  </Row>
          <Row>
            <Col>
             <input type={'radio'} name="isdefault" value="true" required="required"  />
              Contacts matching certain conditions
              </Col>
              <Col>
                <input type={'radio'} name="isvisible" required="required" value="true" />
              AllContacts
               </Col>
            </Row>  
           
          </Card.Body>
          <Card.Footer>
            <Row><Col className="d-flex justify-content-end">
                <Button variant="success" style={{"border-radius":"100px 100px 100px 100px"}}>Done
                </Button></Col></Row>
          </Card.Footer>
       </Card>

      </Col>
    </Row>
    <Row>
      <Col md={{ span: 8, offset: 1 }} className=''>
      <Card>
        <Card.Header>
          <Row> <Col><h6>3.Actions</h6> </Col></Row>
          <Row><Col md={{span:8 ,offset:1} }>
            <Row>

           
            <Col> On a Record Action </Col>
          <Col> On a Date /Time   
        <h6>primer</h6> </Col>
        </Row></Col>

          </Row>
          </Card.Header>
          <Card.Body>
            <Row><Col>Trigger this workflow when a deal is <Button variant='light'>Edited</Button></Col></Row>
            <Row>
                <Col>
                <input type={'radio'} name="isvisible" required="required" value="true" />Created
               </Col>
            </Row>  
            <Row>
                <Col>
                <input type={'radio'} name="isdefault" value="true" required="required"  />Created or Edited
                    
               </Col>
            </Row>  
            <Row>
                <Col>
                <input type={'radio'} name="isvisible" required="required" value="true" />
                Edited
               </Col>
            </Row>  
          </Card.Body>
          <Card.Footer>
            <Row><Col className="d-flex justify-content-end">
                <Button variant="success" style={{"border-radius":"100px 100px 100px 100px"}}>Next</Button></Col></Row>
          </Card.Footer>
       </Card>

      </Col>
    </Row>
    <Row>
        <Outlet/>
    </Row>
  </Container>
  )
}

export default WorkEx