import React from 'react'
import { Container,Modal,Button,Image, Row,Col} from 'react-bootstrap';
import rocket from './rocket.jpg';
import "./Dollor.css";






function MyVerticallyCenteredModal(props) {
    return (
      <Modal
        {...props}
        size="lg"
        aria-labelledby="contained-modal-title-vcenter"
        centered
      >
        <Modal.Header closeButton>
         
        </Modal.Header>
        <Modal.Body>
            <Row   className='text-center'>
                <Col>
                <Image src={rocket} alt="image" style={{"width":"300px","margin-top":"28px",'textAlign':'center'}}></Image>
                <h5 style={{"textAlign":"center"}}>Upgrade to Express</h5>
                <p  style={{"textAlign":"center"}}>The Signals feature is not a part of the 'Free' plan.<br/>
                  Please upgrade to our 'Express' plan to access premium features like this</p>
                   <br/>
                   <Button variant='success' onClick={props.onHide} style={{"borderRadius":"100px 100px 100px 100px"}}>Updates Now</Button>
                </Col>
               
                </Row>
        </Modal.Body>
      
      </Modal>
    );
  }

const Dollor = () => {
    const [modalShow, setModalShow] = React.useState(false);

  return (
    <Container>
   <>
      <Button variant="#eff3f7" onClick={() => setModalShow(true)} className="bi bi-coin Dollor" style={{"margin-top":"-10px"}}>
      
      </Button>

      <MyVerticallyCenteredModal
        show={modalShow}
        onHide={() => setModalShow(false)}
      />
    </>
    </Container>
  )
}

export default Dollor
