import React from 'react'
import { Button, Card, Container, Row } from 'react-bootstrap'
import { Link, Outlet } from 'react-router-dom'

const WorkFlow1 = () => {
  return (
    <Container>
        <Row>
            <Col><span  className='bi bi-arroe-left'>

            </span>
            </Col>
            <Col><Form.Control
          placeholder="Kalyan"
          aria-label="Custmer Name"
          aria-describedby="basic-addon1"
          disabled
          readOnly
        /></Col>
        <Col>
        <Button  variant="success" style={{"border-radius":'100px 100px 100px 100px'}}>
            @Deals</Button></Col>

            
        </Row>
        <Row>
            <Col><span className='bi bi-pencil'></span></Col>

        </Row>
        <Row>
            <Col className="md={{ span: 8, offset: 1}} lg={{ span: 8, offset: 1}} sm={{ span: 10, offset: 1}}">
               <Card>
                <Card.Header>
              <Row>  <Col>1 .Trigger</Col></Row>
              <Row><Col>
              <Link>On a Record Action</Link>
              <Button variant="primary" onClick={handleShow}>
        Launch demo modal
      </Button>

      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Modal heading</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          
        </Modal.Body>
        <Modal.Footer>
          <Button variant="success" onClick={handleClose}>
            Updates
          </Button>
        
        </Modal.Footer>
      </Modal></Col></Row>
                </Card.Header>

                </Card></Col>
        </Row>
        <Row>
            <Outlet/>
        </Row>
        </Container>
  )
}

export default WorkFlow1