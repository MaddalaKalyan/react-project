import React from 'react'
import { Button, Col, Container, Row } from 'react-bootstrap'
import { Outlet } from 'react-router-dom'
import './Installed.css'
const Installed = () => {
  return (
    <Container className='InContainer'>
        <Row className='Inrow'>
            <Col className='InCol'>
            <h4>Explore Toppings</h4>
           <p>You havent installed any toppings yet. 
           Toppings are features and <br/>integrations that extend Bigins capabilities to make your work easier.</p>
         <h5>Ready to give them a try?</h5>
         <Button variant="success" placeholder='search' className='InBb'  type="search">Explore Now</Button>
           </Col>
        </Row>
        <Outlet/>
    </Container>
  )
}

export default Installed