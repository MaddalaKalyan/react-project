import React from 'react'
import { Container,Col,Row } from 'react-bootstrap'
import { Outlet,Link } from 'react-router-dom'
import './Integrations.css';

const Integrations = () => {
  return (
    <Container className='INContainer'>
      <Row className='INRow'>
         <Col  className='d-flex justify-content-start INCol'sm="6" lg="6">
           <Link to="IntegrationsSub">Integrations</Link>
           <Link to="Toppings">Toppings</Link>
          
         </Col>
     
      </Row>
      <Row>
      <Outlet/>
      </Row>
    </Container>
  )
}

export default Integrations
