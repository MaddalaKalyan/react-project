import React from 'react'
import { Col, Container,Row,Card,Button } from 'react-bootstrap'
import { Outlet } from 'react-router-dom';
import './IntegrationsSub.css';

const IntegrationsSub = () => {
  return (
  <Container className='InContainer'>
    <Row className='InRow'>
        <Col >
        <Card className="text-center InSCard">
         <Card.Body>
          <Card.Title><span className='bi bi-plugin InIcons'></span></Card.Title>
            <Card.Text> Build powerful integrations using our comprehensive set of APIs </Card.Text>
            <Button variant="nocolor " className='InButton'>Go somewhere</Button>
      </Card.Body>
    
    </Card></Col>
        <Col><Card className="text-center InSCard">
     
      <Card.Body>
        <Card.Title><span className='bi bi-google InIcons'></span></Card.Title>
        <Card.Text>
          With supporting text below as a natural lead-in to additional content.
        </Card.Text>
        <Button variant="nocolor"  className='InButton'>Go somewhere</Button>
      </Card.Body>
    
    </Card></Col>
        <Col><Card className="text-center InSCard">
     
      <Card.Body>
        <Card.Title><span className='bi bi-windows InIcons'></span></Card.Title>
        <Card.Text>
          With supporting text below as a natural lead-in to additional content.
        </Card.Text>
        <Button variant="nocolor" className='InButton'>Go somewhere</Button>
      </Card.Body>
    
    </Card></Col>
    </Row>
    <Row  className='InRow'>
        <Col><Card className="text-center InSCard">
     
      <Card.Body>
        <Card.Title><span className='bi bi-flower3 InIcons'></span></Card.Title>
        <Card.Text>
          With supporting text below as a natural lead-in to additional content.
        </Card.Text>
        <Button variant="nocolor" className='InButton'>Go somewhere</Button>
      </Card.Body>
    
    </Card></Col>
        <Col>
        <Card className="text-center InSCard">
     
      <Card.Body>
        <Card.Title><span className='bi bi-globe InIcons'></span></Card.Title>
        <Card.Text>
          With supporting text below as a natural lead-in to additional content.
        </Card.Text>
        <Button variant="nocolor" className='InButton'>Go somewhere</Button>
      </Card.Body>
    
    </Card></Col>
        <Col><Card className="text-center InSCard">
     
      <Card.Body>
        <Card.Title><span className='bi bi-app-indicator InIcons'></span></Card.Title>
        <Card.Text>
          With supporting text below as a natural lead-in to additional content.
        </Card.Text>
        <Button variant="nocolor" className='InButton'>Go somewhere</Button>
      </Card.Body>
    
    </Card></Col>
    </Row>
    <Row  className='InRow'>
        <Col><Card className="text-center InSCard">
     
      <Card.Body>
        <Card.Title><span className='bi bi-asterisk InIcons'></span></Card.Title>
        <Card.Text>
          With supporting text below as a natural lead-in to additional content.
        </Card.Text>
        <Button variant="nocolor" className='InButton'>Go somewhere</Button>
      </Card.Body>
    
    </Card></Col>
        <Col><Card className="text-center InSCard">
     
      <Card.Body>
        <Card.Title><span className='bi bi-plugin InIcons'></span></Card.Title>
        <Card.Text>
          With supporting text below as a natural lead-in to additional content.
        </Card.Text>
        <Button variant="nocolor" className='InButton'>Go somewhere</Button>
      </Card.Body>
    
    </Card></Col>
        <Col><Card className="text-center InSCard">
     
      <Card.Body>
        <Card.Title><span className='bi bi-plugin InIcons'></span></Card.Title>
        <Card.Text>
          With supporting text below as a natural lead-in to additional content.
        </Card.Text>
        <Button variant="nocolor" className='InButton'>Go somewhere</Button>
      </Card.Body>
    
    </Card></Col>
    </Row>
    <Row  className='InRow'>
        <Col><Card className="text-center InSCard">
     
      <Card.Body>
        <Card.Title><span className='bi bi-plugin InIcons'></span></Card.Title>
        <Card.Text>
          With supporting text below as a natural lead-in to additional content.
        </Card.Text>
        <Button variant="nocolor" className='InButton'>Go somewhere</Button>
      </Card.Body>
    
    </Card></Col>
        <Col><Card className="text-center InSCard">
     
      <Card.Body>
        <Card.Title><span className='bi bi-plugin InIcons'></span></Card.Title>
        <Card.Text>
          With supporting text below as a natural lead-in to additional content.
        </Card.Text>
        <Button variant="nocolor" className='InButton'>Go somewhere</Button>
      </Card.Body>
    
    </Card></Col>
        <Col>
        <Card>
        <Card className="text-center InSCard">
     
      <Card.Body>
        <Card.Title><span className='bi bi-plugin InIcons'></span></Card.Title>
        <Card.Text>
          With supporting text below as a natural lead-in to additional content.
        </Card.Text>
        <Button variant="nocolor" className='InButton'>Go somewhere</Button>
      </Card.Body>
    
    </Card>
    </Card>
    </Col>
    </Row>
    
 <Row>   <Outlet/></Row>
  </Container>
  )
}

export default IntegrationsSub