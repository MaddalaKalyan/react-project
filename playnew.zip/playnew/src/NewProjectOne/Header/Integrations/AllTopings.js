import React from 'react'
import { Col, Container, Row,Dropdown,Button,Form,Card } from 'react-bootstrap'
import { Outlet } from 'react-router-dom'
import './AllTopings.css';
const AllTopings = () => {
  return (
    <Container className='AlltContainer'>
        <Row className='d-flex AlltRow1'>
            <Col sm="8" lg="8" className='AlltCol d-flex justify-content-start'>
                <Col className='AlltIcon'><span   className='bi bi-house-door '></span></Col>
                <Col className='AlltCol1'> 
                 <Dropdown className='AlltDd1'>
                  <Dropdown.Toggle variant="light" id="dropdown-basic">
                    All Catigories
                   </Dropdown.Toggle>
                      <Dropdown.Menu className='AlltDD'>
                      <Dropdown.Item href="#/action-1">It and Addministration</Dropdown.Item>
                       <Dropdown.Item href="#/action-2">Sales</Dropdown.Item>
                      <Dropdown.Item href="#/action-3">Marketing</Dropdown.Item>
                   <Dropdown.Item href="#/action-4">Customer Service</Dropdown.Item>
                   <Dropdown.Item href="#/action-5">Finance</Dropdown.Item>
                   <Dropdown.Item href="#/action-6">Collabration</Dropdown.Item>
                   <Dropdown.Item href="#/action-7">analytics</Dropdown.Item>
                   <Dropdown.Item href="#/action-8">Business</Dropdown.Item>
                 </Dropdown.Menu>
              </Dropdown>
              </Col>
                <Col className='d-flex'> 
                <Dropdown className='AlltDd1'>
                  <Dropdown.Toggle variant="light" id="dropdown-basic">
                    Edit All
                   </Dropdown.Toggle>
                      <Dropdown.Menu>
                      <Dropdown.Item href="#/action-1">Free</Dropdown.Item>
                     <Dropdown.Item href="#/action-2">Express</Dropdown.Item>
                   <Dropdown.Item href="#/action-3">Premium</Dropdown.Item>
                   <Dropdown.Item href="#/action-4">Begin Zoho one </Dropdown.Item>
                 </Dropdown.Menu>
              </Dropdown>
              <Dropdown className='AlltDd1'>
                  <Dropdown.Toggle variant="light" id="dropdown-basic">
                  Price  All
                   </Dropdown.Toggle>
                      <Dropdown.Menu>
                      <Dropdown.Item href="#/action-1">Paid</Dropdown.Item>
                     <Dropdown.Item href="#/action-2">Free</Dropdown.Item>
                  
                 </Dropdown.Menu>
              </Dropdown>
              <Dropdown className='AlltDd1'>
                  <Dropdown.Toggle variant="light" id="dropdown-basic">
                  Rateing All
                   </Dropdown.Toggle>
                      <Dropdown.Menu>
                      <Dropdown.Item href="#/action-1" >
                        <span className='bi bi-star-fill'></span>
                      <span className='bi bi-star-fill'></span>
                      <span className='bi bi-star-fill'></span>
                      <span className='bi bi-star-fill'></span>
                      <span className='bi bi-star-fill'></span>
                       & Up</Dropdown.Item>


                      <Dropdown.Item href="#/action-2">
                      <span className='bi bi-star-fill'></span>
                      <span className='bi bi-star-fill'></span>
                      <span className='bi bi-star-fill'></span>
                      <span className='bi bi-star-fill'></span>
                      <span className='bi bi-star'></span>
                        & Up</Dropdown.Item>
                       <Dropdown.Item href="#/action-3">
                      <span className='bi bi-star-fill'></span>
                      <span className='bi bi-star-fill'></span>
                      <span className='bi bi-star-fill'></span>
                      <span className='bi bi-star'></span>
                      <span className='bi bi-star'></span> & Up</Dropdown.Item>
                      <Dropdown.Item href="#/action-1">
                      <span className='bi bi-star-fill'></span>
                      <span className='bi bi-star-fill'></span>
                      <span className='bi bi-star'></span>
                      <span className='bi bi-star'></span>
                      <span className='bi bi-star'></span> & Up</Dropdown.Item>
                      <Dropdown.Item href="#/action-1">
                      <span className='bi bi-star-fill'></span>
                      <span className='bi bi-star-'></span>
                      <span className='bi bi-star'></span>
                      <span className='bi bi-star'></span>
                      <span className='bi bi-star'></span> &Up</Dropdown.Item>
                 </Dropdown.Menu>
              </Dropdown>
              </Col>
                <Col>
                <Dropdown className='AlltDd1'>
                  <Dropdown.Toggle variant="light" id="dropdown-basic">
                    Development Type All
                   </Dropdown.Toggle>
                      <Dropdown.Menu>
                      <Dropdown.Item href="#/action-1">Zoho platForm</Dropdown.Item>
                     <Dropdown.Item href="#/action-2">Bult Integrations</Dropdown.Item>
                   <Dropdown.Item href="#/action-3">API-Built Integrations</Dropdown.Item>
                 </Dropdown.Menu>
              </Dropdown>
                </Col>
                
            </Col>

            <Col sm="4" lg={{span: 3, offset: 1}} className='AlltIcon2'>
              
            <Form className="d-flex ">
          
                  <Form.Control
                    type="search"
                    placeholder="Search"
                 
                    aria-label="Search"
                  />
                  <Button variant="nocolor" placeholder='search' className="bi bi-search AlltBtn" type="search"></Button>
                </Form>
                </Col>
        </Row>
        <Row className='AllTopRow2 '>   
        <h6>Featured apps</h6>
          <Col className='AllTopCol1'> <Card className='Card'>
            <Card.Header> <Row className='d-flex'>
              <Col lg="4">
              <span className='bi bi-plus-circle Icon1' ></span></Col>
              <Col lg="8" className='CardText'>
              <h5>Constant Contact For...</h5>
              <p>Sync Contact Between Contact Contact and Begin</p>
              </Col>
               </Row></Card.Header>
            <Card.Body>
    
            <Card.Text>
              <h6>Constant Contact for Begin</h6>
              <p>product      <b>Bigin</b></p>
              <p>Category     <b>Marketing</b></p>
              <p>Rating<span className='bi bi-star-fill'></span>
                      <span className='bi bi-star-fill'></span>
                      <span className='bi bi-star-fill'></span>
                      <span className='bi bi-star-fill'></span>
                      <span className='bi bi-star'></span> (1)</p>
            </Card.Text>
            <Button variant="light" className='CardButton1'>Watch Video</Button>
            <Button variant="warning" className='CardButton2'>Install</Button>
          </Card.Body>
         </Card>
    </Col>
    <Col className='AllTopCol1'> <Card className='Card'>
            <Card.Header> <Row className='d-flex'>
              <Col lg="4">
              <span className='bi bi-plus-circle Icon1' ></span></Col>
              <Col lg="8" className='CardText'>
              <h5>Constant Contact For...</h5>
              <p>Sync Contact Between Contact Contact and Begin</p>
              </Col>
               </Row></Card.Header>
            <Card.Body>
    
            <Card.Text>
              <h6>Constant Contact for Begin</h6>
              <p>product      <b>Bigin</b></p>
              <p>Category     <b>Marketing</b></p>
              <p>Rating<span className='bi bi-star-fill'></span>
                      <span className='bi bi-star-fill'></span>
                      <span className='bi bi-star-fill'></span>
                      <span className='bi bi-star-fill'></span>
                      <span className='bi bi-star'></span> (1)</p>
            </Card.Text>
            <Button variant="light" className='CardButton1'>Watch Video</Button>
            <Button variant="warning" className='CardButton2'>Install</Button>
          </Card.Body>
         </Card>
    </Col>
    <Col className='AllTopCol1'> <Card className='Card'>
            <Card.Header> <Row className='d-flex'>
              <Col lg="4">
              <span className='bi bi-plus-circle Icon1' ></span></Col>
              <Col lg="8" className='CardText'>
              <h5>Constant Contact For...</h5>
              <p>Sync Contact Between Contact Contact and Begin</p>
              </Col>
               </Row></Card.Header>
            <Card.Body>
    
            <Card.Text>
              <h6>Constant Contact for Begin</h6>
              <p>product      <b>Bigin</b></p>
              <p>Category     <b>Marketing</b></p>
              <p>Rating<span className='bi bi-star-fill'></span>
                      <span className='bi bi-star-fill'></span>
                      <span className='bi bi-star-fill'></span>
                      <span className='bi bi-star-fill'></span>
                      <span className='bi bi-star'></span> (1)</p>
            </Card.Text>
            <Button variant="light" className='CardButton1'>Watch Video</Button>
            <Button variant="warning" className='CardButton2'>Install</Button>
          </Card.Body>
         </Card>
    </Col>
    <Col className='AllTopCol1'> <Card className='Card'>
            <Card.Header> <Row className='d-flex'>
              <Col lg="4">
              <span className='bi bi-plus-circle Icon1' ></span></Col>
              <Col lg="8" className='CardText'>
              <h5>Constant Contact For...</h5>
              <p>Sync Contact Between Contact Contact and Begin</p>
              </Col>
               </Row></Card.Header>
            <Card.Body>
    
            <Card.Text>
              <h6>Constant Contact for Begin</h6>
              <p>product      <b>Bigin</b></p>
              <p>Category     <b>Marketing</b></p>
              <p>Rating<span className='bi bi-star-fill'></span>
                      <span className='bi bi-star-fill'></span>
                      <span className='bi bi-star-fill'></span>
                      <span className='bi bi-star-fill'></span>
                      <span className='bi bi-star'></span> (1)</p>
            </Card.Text>
            <Button variant="light" className='CardButton1'>Watch Video</Button>
            <Button variant="warning" className='CardButton2'>Install</Button>
          </Card.Body>
         </Card>
    </Col>
        </Row>
        <Row>   
       <Col className='AllTopCol2'><h4>Marketing</h4>
       <p>Make your marketing more inventive and interactive</p></Col>
        </Row>
        <Row className='d-flex'>
          <Col className='d-flex AllTopCol5'>
          <Card className='d-flex AllTopCard1'  style={{ 'backgroundColor':"#fff"}}>
          <Card.Body><span className='bi bi-speedometer Icona'></span> </Card.Body>
          </Card>
           <Card> 
            <Card.Body>
              <p>Constant Contact for Begin</p>
              <p><span className='bi bi-star-fill'  style={{ 'color':"#f5a623"}}></span>
                      <span className='bi bi-star-fill' style={{ 'color':"#f5a623"}}></span>
                      <span className='bi bi-star-fill' style={{ 'color':"#f5a623"}}></span>
                      <span className='bi bi-star-fill' style={{ 'color':"#f5a623"}}></span>
                      <span className='bi bi-star' style={{ 'color':"#f5a623"}}></span> (1)</p>   
            </Card.Body>
            </Card>
          </Col>


          <Col className='d-flex'>
          <Card className='d-flex'  style={{ 'backgroundColor':"#fff"}}>
          <Card.Body><span className='bi bi-question-circle  Iconb' ></span> </Card.Body>
          </Card>
           <Card> 
            <Card.Body>
              <p>Constant Contact for Begin</p>
              <p><span className='bi bi-star-fill'  style={{ 'color':"#f5a623"}}></span>
                      <span className='bi bi-star-fill' style={{ 'color':"#f5a623"}}></span>
                      <span className='bi bi-star-fill' style={{ 'color':"#f5a623"}}></span>
                      <span className='bi bi-star-fill' style={{ 'color':"#f5a623"}}></span>
                      <span className='bi bi-star' style={{ 'color':"#f5a623"}}></span> (1)</p>   
            </Card.Body>
            </Card>
          </Col>

          <Col className='d-flex'>
          <Card className='d-flex'  style={{ 'backgroundColor':"#fff"}}>
          <Card.Body><span className='bi bi-emoji-sunglasses Iconc '></span> </Card.Body>
          </Card>
           <Card> 
            <Card.Body>
              <p>Constant Contact for Begin</p>
              <p><span className='bi bi-star-fill'  style={{ 'color':"#f5a623"}}></span>
                      <span className='bi bi-star-fill' style={{ 'color':"#f5a623"}}></span>
                      <span className='bi bi-star-fill' style={{ 'color':"#f5a623"}}></span>
                      <span className='bi bi-star-fill' style={{ 'color':"#f5a623"}}></span>
                      <span className='bi bi-star' style={{ 'color':"#f5a623"}}></span> (1)</p>   
            </Card.Body>
            </Card>
          </Col>

          <Col className='d-flex'>
          <Card className='d-flex'  style={{ 'backgroundColor':"#fff"}}>
          <Card.Body><span className='bi bi-bookmark-check Icond '></span> </Card.Body>
          </Card>
           <Card> 
            <Card.Body>
              <p>Constant Contact for Begin</p>
              <p><span className='bi bi-star-fill'  style={{ 'color':"#f5a623"}}></span>
                      <span className='bi bi-star-fill' style={{ 'color':"#f5a623"}}></span>
                      <span className='bi bi-star-fill' style={{ 'color':"#f5a623"}}></span>
                      <span className='bi bi-star-fill' style={{ 'color':"#f5a623"}}></span>
                      <span className='bi bi-star' style={{ 'color':"#f5a623"}}></span> (1)</p>   
            </Card.Body>
            </Card>
          </Col>
          
          

        </Row>
        <Row>
     <Col></Col>
           
        </Row>
        <Row> <Outlet/></Row>
       
    </Container>
  )
}

export default AllTopings