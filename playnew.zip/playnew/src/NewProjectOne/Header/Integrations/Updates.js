import React from 'react'
import { Col, Container, Row } from 'react-bootstrap'
import { Outlet } from 'react-router-dom'

const Updates = () => {
  return (
   <Container>
    <Row>
        <Col style={{"textAlign":"center" , "marginTop":"100px"}}>
      <p> All toppings are up to date.</p></Col>
    </Row>
    <Outlet/>
   </Container>
  )
}

export default Updates