import React from 'react'
import { Container, Row,Col } from 'react-bootstrap'
import { Outlet,Link } from 'react-router-dom'
import './Toppings.css'

const Toppings = () => {
  return (
    <Container className='TopContainer'>
        <Row className='TopRow justify-content-start'>
           <Col sm="6" lg="4"  className="TopCol" >
           <Link to="AllToppings" >AllToppings</Link>
            <Link to="Installed">Installed </Link>
            <Link to="Updates"> Updates</Link>
         
           </Col>
        </Row>
        <Row>
        <Outlet/>
        </Row>
    </Container>
  )
}

export default Toppings