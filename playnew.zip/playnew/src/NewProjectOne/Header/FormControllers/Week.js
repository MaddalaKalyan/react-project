import React from 'react';
import { useState } from 'react';
import { Container, Form,Row,Col } from 'react-bootstrap';

const Week = () => {
    const [formData , setFormData]= useState({
        Week:''
      });
      const handleAddFormChange =(e) =>{
          e.preventDefault();
          const fieldName = e.target.getAttribute('name');
          const fieldvalue = e.target.value;
          const newFormData = {...formData};
          newFormData[ fieldName]  = fieldvalue;
          setFormData(newFormData);
     };
  return (
    //Week Started 
   <Container>
    <Row>
    <Row className="justify-content-xs-lg-center">
          <Col xs lg="2">
          <Form.Label>Week</Form.Label></Col>
          <Col xs lg="6">
          <Form.Control  type='week' name='week'  onChange={handleAddFormChange} defaultValue='#124' title='choose color' />
          </Col>
         </Row>
    </Row>
   </Container>
    //Week Ended
  )
}

export default Week
