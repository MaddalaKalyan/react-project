import React from 'react';
import { useState } from 'react';
import { Form,Container,Row,Col } from 'react-bootstrap';

const Range = () => {
    const [formData , setFormData]= useState({
        Range:''
      });
      const handleAddFormChange =(e) =>{
          e.preventDefault();
          const fieldName = e.target.getAttribute('name');
          const fieldvalue = e.target.value;
          const newFormData = {...formData};
          newFormData[ fieldName]  = fieldvalue;
          setFormData(newFormData);
     };
  return (
    //Range Started
      <Container>
     <Row className="justify-content-xs-lg-center ">
       
          <Form.Group className='mb-1 d-flex'>
          <Col xs lg="2"> <Form.Label>Range</Form.Label></Col>
            <Col xs lg="6"><Form.Range  name="Range"  
                  required="required" 
                  onChange={handleAddFormChange}/>
            </Col>
          </Form.Group>
        </Row>
      </Container>
    //Range Ended
  )
}

export default Range
