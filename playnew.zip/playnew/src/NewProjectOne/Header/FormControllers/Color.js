import React from 'react';
import { useState } from 'react';
import { Container,Row,Col,Form} from 'react-bootstrap';

const Color = () => {
    const [formData,setFormData]= useState({
        Color:''
      });
      const handleAddFormChange =(e) =>{
          e.preventDefault();
          const fieldName = e.target.getAttribute('name');
          const fieldvalue = e.target.value;
          const newFormData = {...formData};
          newFormData[ fieldName]  = fieldvalue;
          setFormData(newFormData);
     };
  return (
    //Color Started
    <Container>
         <Row className="justify-content-xs-lg-center">
          <Col xs lg="2">
          <Form.Label>Color</Form.Label></Col>
          <Col xs lg="6">
          <Form.Control  type='color' name='color'  onChange={handleAddFormChange} defaultValue='#124' title='choose color' />
          </Col>
         </Row>
    </Container>
    //Color ended
  )
}

export default Color;
