import React from 'react';
import { useState } from 'react';
import { Container,Row,Col,Form} from 'react-bootstrap';


const Radio = () => {
    const [formData , setFormData]= useState({
       Radio:''
      });
      const handleAddFormChange =(e) =>{
        e.preventDefault();
        const fieldName = e.target.getAttribute('name');
        const fieldvalue = e.target.value;
        const newFormData = {...formData};
        newFormData[ fieldName]  = fieldvalue;
        setFormData(newFormData);
      }
  return (
    //Radio Button Started
    <Container>
    <Row className="justify-content-xs-lg-center">
                        <Form >
                        <Form.Group className='mb-1 d-flex'>
                        <Col xs lg="2"><Form.Label>Is EDitable</Form.Label></Col>
                        <Col xs lg="6"  className='d-flex'>
                      
                    <Form.Check 
                      type="radio"
                      label="Yes"
                      name="Radio"
                      id="formHorizontalRadios1"
                      onChange={handleAddFormChange}
                    />
                    <Form.Check
                      type="radio"
                      label="No"
                      name="Radio"
                      onChange={handleAddFormChange}
                      id="formHorizontalRadios2"
                    />
                    </Col>
                </Form.Group>
                        </Form>
  
  </Row>
  
  </Container>

  //Radio Buttons Ended
  )

}

export default Radio








