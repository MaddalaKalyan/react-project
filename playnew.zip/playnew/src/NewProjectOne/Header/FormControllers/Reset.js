import React from 'react';
import { useState } from 'react';
import { Container,Row,Col,Form} from 'react-bootstrap';

const Reset = () => {
    const [formData , setFormData]= useState({
       Reset:''
      });
      const handleAddFormChange =(e) =>{
        e.preventDefault();
        const fieldName = e.target.getAttribute('name');
        const fieldvalue = e.target.value;
        const newFormData = {...formData};
        newFormData[ fieldName]  = fieldvalue;
        setFormData(newFormData);

  
      }
  return (
    //Reset Started
    
        <Container>
         <Row className="justify-content-xs-lg-center">
          <Form>
            <Form.Group  className='mb-1 d-flex'>
            <Col xs lg="2"><Form.Label>Reset:</Form.Label></Col>
             <Col xs lg="6"><Form.Control type='reset'     name="Reset"  
                  required="required" 
                  onChange={handleAddFormChange} />
             </Col>
             
           </Form.Group>
                </Form> 
          </Row>
        </Container>

    //Reset Ended
  )
}

export default Reset
