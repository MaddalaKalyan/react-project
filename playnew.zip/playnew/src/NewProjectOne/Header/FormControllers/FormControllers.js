import React, { useState } from 'react';
import './FormControllers.css';
//import data from '../EmptyJSONFILE/Data.json';

import Text from './Text';
import Telephone from './Telephone';
import Number from './Number';
import File from './File';
import Date from './Date';
import Color from './Color';
import Week from './Week';
import Search from './Search';
import Range from './Range';
import Month from './Month';
import DateTimeLocal from './DateTimeLocal';
import Url from './Url';
import Time from './Time';
import Radio from './Radio';
import Reset from './Reset';
import CheckBox from './CheckBox';
import Mail from './Mail';
import List from './List';


const FormControllers = () => {
  
  const [addData , setAddData]= useState(
 {
      Text:'',
      Radio:'',
      Telephone:'',
      Number:'',
      File:'',
      Mail:'',
      Date:'',
      Color:'',
      Week:'',
      Search:'',
      Time:'',
      Month:'',
      DateTimeLocal:'',
      Reset:'',
       Url:'',
       List:'',
      Range:'',
      CheckBox:''

  });
  const handleAddFormChange =(e) =>{
      e.preventDefault();
      
      
       const fieldName = e.target.getAttribute('name');
       const fieldvalue = e.target.value;
       const newAddData = {...addData};
       newAddData[ fieldName]  = fieldvalue;
       setAddData(newAddData);
 

     
     };
 
       const handleAddFormSubmit =(e)=>{                                                   
        e.preventDefault();
        const newAddedData ={
           Text:addData.Text,
          Telephone:addData.Telephone,
          Number:addData.Number,
          File:addData.File,
          Mail:addData.Mail,
          Date:addData.Date,
          Color:addData.Color,
          Week:addData.Week,
          Search:addData.Search,
          Range:addData.Range,
          Month:addData.Month,
          DateTimeLocal:addData.DateTimeLocal,
          Url:addData.Url,
          Time:addData.Time,
          Radio:addData.Radio,
          List:addData.List,   
          CheckBox:addData.CheckBox,
          Reset:addData.Reset
        };
   
        const newAddedDatas =[ ...addData , newAddedData];

          setAddData(newAddedDatas);
         JSON.stringify(addData)
       };

  return (
    <div className='container-fluid noValidates FcOne' >
        <h1 className='text-center'>FormControlsMaster</h1>
        <hr/>
      <form  noValidate   onSubmit={handleAddFormSubmit}>
        <div  onChange={handleAddFormChange}>
        <Text/>
        <Telephone/>
        <Number/>
        <File/>
        <Mail/>
        <Date/>
        <Color/>
        <Week/>
        <Search/>
        <Range/>
        <Month/>
        <DateTimeLocal/>
        <Url/>
        <Time/>
        <Radio/>
        <List/>
        <CheckBox/>
        <Reset/>
        </div>
        <div className='row justify-content-end' >
            <div className='col-4 ' style={{"margin":"20px 30px 10px 10px"}}> 
            
                     <button className="btn btn-success">Submit</button>
             
            </div>
            
        </div>
      </form>
    </div>
  )
}
 

export default FormControllers
