import React from 'react';
import { useState } from 'react';
import { Container,Row,Col,Form } from 'react-bootstrap';

const List = () => {
    const [formData , setFormData]= useState({
        List:''
      });
      const handleAddFormChange =(e) =>{
        e.preventDefault();
        const fieldName = e.target.getAttribute('name');
        const fieldvalue = e.target.value;
        const newFormData = {...formData};
        newFormData[ fieldName]  = fieldvalue;
        setFormData(newFormData);
      }
  return (
    // List Type(Select-Box) Start Here
                <Container>
               <Row className="justify-content-xs-lg-center">
               <Form.Group className='mb-1 d-flex'>
                  <Col xs lg="2"><Form.Label>List</Form.Label>  </Col>
                  <Col xs lg="6">
                  <Form.Select name="List"  onChange={handleAddFormChange}>
                      <option>Open this select menu</option>
                      <option value="1">One</option>
                      <option value="2">Two</option>
                      <option value="3">Three</option>
                    </Form.Select>

                  </Col>
                  </Form.Group>
                  </Row>
                </Container>
    //List Ended
  )
}

export default List
