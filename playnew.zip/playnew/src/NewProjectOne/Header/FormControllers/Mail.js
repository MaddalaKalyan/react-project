import React from 'react';
import { useState } from 'react';
import { Container,Row,Col,Form} from 'react-bootstrap';
const Mail = () => {
    const [formData,setFormData]= useState({
      Mail:''
    });
    const handleAddFormChange =(e) =>{
        e.preventDefault();
        const fieldName = e.target.getAttribute('name');
        const fieldvalue = e.target.value;
        const newFormData = {...formData};
        newFormData[ fieldName]  = fieldvalue;
        setFormData(newFormData);
   };
  return (
    //Mail startes
    <Container>
    <Row className="justify-content-xs-lg-center">
     <Form>
        <Form.Group className='mb-1 d-flex'>

          <Col xs lg="2"><Form.Label>Mail id</Form.Label>  </Col>
          <Col xs lg="6"><Form.Control type='mail' placeholder='enter your mail id' name="Mail" onChange={handleAddFormChange}></Form.Control> </Col>
        </Form.Group>
      </Form>
    
    </Row>
  </Container>
    // Mail ends
  )
}

export default Mail
