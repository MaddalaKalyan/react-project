import React from 'react';
import { useState } from 'react';
import { Container,Row,Col,Form} from 'react-bootstrap';


const Url = () => {
    const [formData , setFormData]= useState({
        url:''
      });
      const handleAddFormChange =(e) =>{
        e.preventDefault();
        const fieldName = e.target.getAttribute('name');
        const fieldvalue = e.target.value;
        const newFormData = {...formData};
        newFormData[ fieldName]  = fieldvalue;
        setFormData(newFormData);
      }
  
       
  return (
           //Url Started
      <Container>
         <Row className="justify-content-xs-lg-center">
        <Form>
            <Form.Group className='mb-1 d-flex'>
               <Col xs lg="2"><Form.Label>Url</Form.Label></Col>
               <Col xs lg="6"><Form.Control type='url' name="url" onChange={handleAddFormChange}></Form.Control> </Col>
            </Form.Group>
      </Form>
        </Row>
      </Container>
    //Url Ended
  )
}

export default Url
