
import { React ,useState}from 'react';
import { Container,Row,Col,Form} from 'react-bootstrap';
 
const CheckBox = () => {
    const [addFormData , setAddFormData]= useState({
        CheckBox:''
      });
    const handleAddCheckChange =(e) =>{
        const fieldName = e.target.getAttribute('name');
        let fieldvalue;
        console.log(e.target.checked);
        if(e.target.checked) {fieldvalue = "True";}
        else{fieldvalue = "False";}
        const newFormData = {...addFormData};
        newFormData[fieldName] = fieldvalue; 
        setAddFormData(newFormData);
        
       };
       
  return (
    <Container>
      <Row className="justify-content-xs-lg-center ">
        <Form.Group className='mb-1 d-flex'>
        <Col xs lg="2"> <Form.Label>CheckBox</Form.Label></Col>
        <Col xs lg="6"><Form.Check type="checkbox"  value="true" onClick={handleAddCheckChange} label="Check me out" /></Col>
      </Form.Group>
        
      </Row>
    </Container>
  
  )
}

export default CheckBox
