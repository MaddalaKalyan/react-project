import React from 'react'
import { Col, Container ,Row,Card} from 'react-bootstrap'
import { Link, Outlet } from 'react-router-dom'
import './StageTransitionRules.css'

const StageTransitionRules = () => {
  return (
   <Container> 
    <Row className='d-flex STRRow1'>
          <Col  xs="6" lg="6" className='STRCol1'>
             <Card className='d-flex STRCard1'>
                <Row className='SRTRow2'>
                     <Col xs="6" lg="6" className='STRCol2'><Card className='STRCard2'><Link to="TransitionRules"> Transition Rules</Link>  </Card></Col>
                 <Col xs="6" lg="6" className='STRCol3'><Card className='STRCard3'> <Link to="RestrictDealClosure">Restrict Deal Closure</Link></Card></Col>
                 </Row>
            </Card>
            </Col>
    </Row>
    <Outlet/>
   </Container>
  )
}

export default StageTransitionRules