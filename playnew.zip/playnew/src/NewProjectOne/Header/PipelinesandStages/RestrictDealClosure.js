import React from 'react'
import { Container,Row,Col,  } from 'react-bootstrap'
import {  Table,Thead,Th,Tr } from 'react-super-responsive-table'
import { Link, Outlet } from 'react-router-dom'

const RestrictDealClosure = () => {
  return (
  <Container>
    <Row>
        <Col xs="6" lg="12">
            <h5>RestrictDealClosure</h5>
            <p>This feature lets you specify the stages in a pipeline from which deal cannot be closed directly.</p>
        </Col>
    </Row>
    <Row>
        <Table>
            <Thead>
                <Tr>
                   <Th><Col xs="4"lg="4">PipeLines</Col></Th>
                   <Th><Col xs="4"lg="6">Stages</Col></Th>
                </Tr>
            </Thead>
        </Table>
    </Row>
    <Row>
        <Col xs="4"lg="4">Sales</Col>
        <Col xs="4"lg="6"><span className='bi bi-plus'><Link>Stages</Link></span></Col>
    </Row>
    <Row>
        <Outlet/>
    </Row>
  </Container>
  )
}

export default RestrictDealClosure