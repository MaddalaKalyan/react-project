import React from 'react'
import { Container, Row,Col } from 'react-bootstrap'
import { Outlet,Link } from 'react-router-dom'
import "./PipelinesandStages.css"

const PipeLineAndStages = () => {
  return (
    <Container>
  <Row className='d-flex justify-content-between PASR1'>
       <Col  className='d-flex PASC1 ' sm="4" lg="6">
        <Link to="PipeLines">Pipelines</Link>
       <Link to="StageTransitionRules">Stage Transition Rules</Link>
 
       </Col>
       <Col sm="4" lg="6"  className='d-flex PASC2 '>
        
          <span className='bi bi-question-circle PASCL'></span>
         
        
       </Col>
       <hr/>
         </Row>












        <Row>
           
            <Outlet/>
        </Row>
    </Container>
  )
}

export default PipeLineAndStages