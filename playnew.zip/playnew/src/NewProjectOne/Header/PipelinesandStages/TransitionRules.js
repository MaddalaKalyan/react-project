import React from 'react'
import { Outlet } from 'react-router-dom'
import { Container,Row,Col,Dropdown, Card, Button } from 'react-bootstrap'
import { Table, Thead, Tr,Th } from 'react-super-responsive-table'
import './TransitionRules.css'

const TransitionRules = () => {
  return (
   <Container>
    <Row className='TrRow1'>
        <Col xs="6" lg="12">
            <h5> Transition Rules</h5>
            <p>Transition Rules let you specify fields that need to be filled by users when they move a deal from one stage to another.</p>
        </Col>
    </Row>
    <Row className='TrRow2'>
        <Col xs="4" lg="6">
            <Row className='TrRow3'>
                <Col xs="4" lg="3">pipeline</Col>
                <Col xs="4" lg="4">
                                <Dropdown className='TrDD1'>
                                        <Dropdown.Toggle    className='TrDD2' variant="lite" id="dropdown-basic"> Sales Pipeline</Dropdown.Toggle>
                                        <Dropdown.Menu className='TrDD2'>
                                                <Dropdown.Item href="#/action-1">Sales Pipeline</Dropdown.Item>
                                        </Dropdown.Menu>
                            </Dropdown>
               </Col>
            </Row>
        </Col>
        <Col xs="4" lg="6">
            <Row  className='d-flex'>
               <Col xs="4" lg="4">
              <p>Sort By</p>
              </Col>
              <Col xs="2" lg="4" ><Row d-flex>
                       
                            <Col xs="1" lg="4" className='TrCol1'> <Card className='TrColCard1'><Button type="submit" class variant='lite'>
                        <span className='bi bi-sort-up  d-flex justify-content-center'></span></Button> </Card></Col>
                        <Col xs="1" lg="8"  className='TrCol1'> <Card  className='TrColCard2'>  <span className='bi bi-plus'>Create Time</span></Card></Col>
                   
                        </Row>
            </Col>  
            
            <Col  xs="2"lg="4" className='TRls2'>
            <Button variant='success' type='submit' className='TRbu3' ><span className='bi bi-plus '>New Rule</span></Button>
            </Col>
            </Row>
        </Col>
    </Row>
    <Row>
        <Table>
            <Thead>
                <Tr>
                    <Th>Form Stage</Th>
                    <Th>To Stage</Th>
                    <Th><Row><Col>Forms To Be Filled </Col></Row></Th>
                    <Th><span className='bi bi-filter d-flex justify-content-end'></span></Th>
                </Tr>
            </Thead>
        </Table>
    </Row>
    <Outlet/>
   </Container>
  )
}

export default TransitionRules