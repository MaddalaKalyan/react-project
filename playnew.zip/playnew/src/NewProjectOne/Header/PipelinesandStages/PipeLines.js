import React from 'react'
import { Container,Row,Col,Card, } from 'react-bootstrap'
import './PipeLines.css'

import { Outlet,Link } from 'react-router-dom'

const PipeLines = () => {
  return (
   <Container className='PLContainer'>
    <Row>
           <Col >
            <Card className='PLCard1'>
              <Card.Header>
                <Row>
                  <Col className='PLCCol1'>Sales Pipeline
                  <span className='bi bi-star-fill icon'></span>
                  </Col>
                  <Col className='d-flex justify-content-end '><span className='bi bi-pencil-fill icon2'></span>
                  <span className='bi bi-three-dots-vertical icon2'></span>
                  </Col>

                </Row>
                <Row>
                  <p>6 Stages</p>
                </Row>
              </Card.Header>
              <Card.Body className='PLCBody'>
                <Card.Title>Open Stages</Card.Title>
                <Card className='PLCCard'>
                  
                     <Row>
                        <Col> <span className='bi bi-grip-vertical'></span></Col>
                         <Col>Qualification</Col>
                              <Col>
                                  <Row> 
                                    <Col className='d-flex justify-content-end'>
                                      <span className='bi bi-pencil-fill icon2'></span>
                                      <span className='bi bi-three-dots-vertical icon2'></span>
                            </Col>
                         </Row>
                      </Col>
                        
                  </Row>
                  </Card>
                  <Card className='PLCCard'>
                  
                  <Row>
                     <Col> <span className='bi bi-grip-vertical'></span></Col>
                      <Col>NeedAnalysis</Col>
                           <Col>
                               <Row> 
                                 <Col className='d-flex justify-content-end'>
                                   <span className='bi bi-pencil-fill icon2'></span>
                                   <span className='bi bi-three-dots-vertical icon2'></span>
                         </Col>
                      </Row>
                   </Col>
                     
               </Row>
               </Card>
               <Card className='PLCCard'>
                  
                  <Row>
                     <Col> <span className='bi bi-grip-vertical'></span></Col>
                      <Col>Proposal/PriceAnalysis</Col>
                           <Col>
                               <Row> 
                                 <Col className='d-flex justify-content-end'>
                                   <span className='bi bi-pencil-fill icon2'></span>
                                   <span className='bi bi-three-dots-vertical icon2'></span>
                         </Col>
                      </Row>
                   </Col>
                     
               </Row>
               </Card>
               <Card className='PLCCard'>
                  
                  <Row>
                     <Col> <span className='bi bi-grip-vertical'></span></Col>
                      <Col>Negotation/Review</Col>
                           <Col>
                               <Row> 
                                 <Col className='d-flex justify-content-end'>
                                   <span className='bi bi-pencil-fill icon2'></span>
                                   <span className='bi bi-three-dots-vertical icon2'></span>
                         </Col>
                      </Row>
                   </Col>
                     
               </Row>
               </Card>
               <Row><Link><span className='bi bi-plus'></span> Stages</Link></Row>
               <br/>
               <Card.Title><p>Closed Won</p></Card.Title>
               <Card className='PLCCard'>
               
                  <Row >
                     <Col> <span className='bi bi-grip-vertical'></span></Col>
                      <Col>Closed Won</Col>
                           <Col>
                               <Row> 
                                 <Col className='d-flex justify-content-end'>
                                   <span className='bi bi-hand-thumbs-up icon3'></span>
                                
                         </Col>
                      </Row>
                   </Col>
                     
               </Row>
              
               </Card>
               <Card className='PLCCard'>
                  
                  <Row>
                     <Col> <span className='bi bi-grip-vertical'></span></Col>
                      <Col>Closed lost</Col>
                           <Col>
                               <Row> 
                                 <Col 
                                 className='d-flex justify-content-end'>
                                   <span className='bi bi-hand-thumbs-down icon4'></span>
                            
                         </Col>
                      </Row>
                   </Col>
                     
               </Row>
             
               </Card>
               <Row><Link><span className='bi bi-plus'></span> Stages</Link></Row>
              </Card.Body>
           
            </Card>

           </Col>
           <Col >
            <Card className='PLCard2'>
              <h6 className='PLCh6'><Link><span className='bi bi-plus'> New Pipeline</span></Link></h6>
            </Card>
           </Col>
           
    </Row>
    <Row>
        <Outlet/>
    </Row>
   </Container>
  )
}

export default PipeLines