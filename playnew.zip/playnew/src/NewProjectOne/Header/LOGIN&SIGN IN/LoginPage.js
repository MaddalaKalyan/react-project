import React, { useState } from 'react'
// import { Card, Col, Container, Form, Row } from 'react-bootstrap'
import './LoginPage.css'
import PhoneInput from 'react-phone-input-2'
import 'react-phone-input-2/lib/style.css'
import { Link } from 'react-router-dom'

function LoginPage() {

  const [ form, setForm] = useState ({phone: "" ,})
  return (
    <div className="Auth-form-container">
    <form className="Auth-form">
      <div className="Auth-form-content">
        <h3 className="Auth-form-title">Play Game Sign Up</h3>
        <div className="form-group mt-3">
          <input
            type="text"
            className="form-control mt-1"
            placeholder="Full Name"
          />
        </div>
        <div className="form-group mt-3">
           <input
            type="email"
            className="form-control mt-1"
            placeholder="Enter email"
          />
        </div>
        <div className="form-group mt-3">
           <input
            type="password"
            className="form-control mt-1"
            placeholder="Enter password"
          />
        </div>
        <div className="form-group mt-3">
        <PhoneInput
          className="form-control"
          country={'in'}
          value={form.phone}
          onChange={phone => setForm({ phone })}
        />
        </div>
        <div className="form-group mt-3">
        <input 
         type="checkbox" />
            <label>I agre to this<Link to="">Terms and Condition</Link></label>
      
        </div>
        <div className="d-grid gap-2 mt-3">
          <button type="submit" className="btn btn-danger">
       SIGN UP FOR FREE
          </button>
        </div>
        <p className="forgot-password text-right mt-2">
          Forgot <a href="#">password?</a>
        </p>
      </div>
    </form>
  </div>
  )
}

export default LoginPage