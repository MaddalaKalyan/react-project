import React from 'react'
import { Image } from 'react-bootstrap';
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faYoutube,
  faFacebook,
  faTwitter,
  faInstagram
} from "@fortawesome/free-brands-svg-icons";

import TechTantra from './TechTantra.png';


import { Link } from 'react-router-dom'
const SignUp = () => {
  return (
    <div className="Auth-form-container">
    <form className="Auth-form">
      <div className="Auth-form-content">
        <Image src={TechTantra} alt="" style={{"width":"150px","height":"100px"}}/>
        {/* <h3 className="Auth-form-title">Play Game Sign Up</h3>
        <div className="form-group mt-3">
          <input
            type="text"
            className="form-control mt-1"
            placeholder="Full Name"
        </div> */} 
        <div className="form-group mt-3">
           <input
            type="email"
            className="form-control mt-1"
            placeholder="Enter email"
          />
        </div>
        {/* <div className="form-group mt-3">
           <input
            type="password"
            className="form-control mt-1"
            placeholder="Enter password"
          />
        </div>
        <div className="form-group mt-3">
      <PhoneInput
          className="form-control"
          country={'in'}
          value={form.phone}
          onChange={phone => setForm({ phone })}
        /> 
        </div>
        <div className="form-group mt-3">
        <input 
         type="checkbox" />
            <label>I agre to this<Link to="">Terms and Condition</Link></label>
      
        </div> */}
        <div className="d-grid gap-2 mt-3">
          <button type="submit" className="btn btn-primary">
       SIGN UP FOR FREE
          </button>
        </div>
        <div className="d-grid gap-2 mt-3" style={{"textAlign":"center"}}>
        <p className="forgot-password text-right mt-2">
          <a href="#" style={{"textDecoration":"none"}}> Forgot password </a>
        </p>
        <h4 style={{ "width": "100%" ,
   "textAlign": "center", 
  "borderBottom":" .5px solid #ced4da", 
   "lineHeight":" 0.1em",
   "margin":" 10px 0 20px" }}> <span style={{"background":"#fff", 
   "padding":"0 10px"}}>Or</span></h4>
        </div>
        <div className="d-flex justify-content-center    gap-2 mt-3 ">
        <a href="https://www.youtube.com/c/jamesqquick"
        className="youtube social"  style={{"color":"red"}}>
        <FontAwesomeIcon icon={faYoutube} size="2x" />
      </a>
      <a href="https://www.facebook.com/learnbuildteach/"
        className="facebook social">
        <FontAwesomeIcon icon={faFacebook} size="2x" />
      </a>
      <a href="https://www.twitter.com/jamesqquick" className="twitter social">
        <FontAwesomeIcon icon={faTwitter} size="2x" />
      </a>
      <a href="https://www.instagram.com/learnbuildteach"
        className="instagram social">
        <FontAwesomeIcon icon={faInstagram} size="2x"  style={{"color":"#feda75"}}  />
      </a>
        </div>
        
      </div>
    </form>
  </div>
  )
}

export default SignUp