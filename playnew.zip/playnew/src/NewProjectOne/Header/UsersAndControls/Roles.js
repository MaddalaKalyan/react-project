import React from 'react'
import { Container,Row,Col,Button } from 'react-bootstrap'
import {  Table,Thead,Th,Tr, Tbody,Td } from 'react-super-responsive-table'
import './Roles.css'
import { Outlet } from 'react-router-dom'

const Roles = () => {
  return (
    <Container className='RoC1'>
    <Row className='RoR1'>
      <h5>Roles</h5>
       <Col xs="6" lg="10" className='d-flex RoCol'>
       <Col xs="4"lg="10" className='RoCol1'>
          <p>Roles help you define a hierarchy of access levels to records in your organization.
             Users can only see the records of other users below them in the role hierarchy.</p></Col>
      
           <Col  xs="2"lg="1" className='RoCol2'>
            <Button variant='success' type='submit'className="RoBu1" ><span className='bi bi-plus '>New User</span></Button>
            </Col>
       </Col>
        
     
    </Row>
      <hr/>
    <Row >
        <Col className='RoCol3'>
          <Table striped bordered>
           <Thead>
            <Tr>
              <Th>Roofile Name</Th>
              <Th>No. of Users</Th>
              <Th>Peer Data Visibility</Th>
             
            </Tr>

           </Thead>
           <Tbody>
            <Td><span className='bi bi-dash-square Roicon1 d-flex justify-content-start'></span></Td>
            <Td>1</Td>
            <Td>Yes</Td>
           </Tbody>
          </Table>
          </Col>
        </Row>
    <Outlet/>
   </Container>
  )
}

export default Roles
