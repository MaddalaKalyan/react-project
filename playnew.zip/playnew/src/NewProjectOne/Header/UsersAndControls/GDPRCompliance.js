import React from 'react'
import { Container,Row,Col } from 'react-bootstrap'
import { Outlet } from 'react-router-dom'
import './GDPRCompliance.css'

const GDPRCompliance = () => {
  return (
<Container>
    <Row className='GDPRRow1'> 
        <Col xs="4" lg="8" className='d-flex '>
        <h5> GDPR Compliance</h5>
      <h5><span className='bi bi-toggle-off ' style={{"margin-left":'50px'}}></span></h5>
        </Col>
        <Col xs="4" lg="8">
      <p> Turning on GDPR compliance lets you manage the personal data of your
       organisation's contacts in compliance with GDPR.</p></Col>
      
    </Row>
    <Row>
    <Outlet/>
        </Row>
</Container>
  )
}

export default GDPRCompliance