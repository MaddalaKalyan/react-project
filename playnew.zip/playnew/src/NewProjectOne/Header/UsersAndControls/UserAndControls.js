import React from 'react'
import { Container,Row,Col } from 'react-bootstrap'
import { Link, Outlet } from 'react-router-dom'
import './UserAndControls.css'

const UserAndControls = () => {
  return (
   <Container>
    <Row className='d-flex justify-content-start UacR1'>
      
       <Col  className='d-flex justify-content-start UacC1 'sm="6" lg="6">
           <Link to="Users">Users</Link>
           <Link to="Profiles">Profiles</Link>
           <Link to="Roles">Roles</Link>
      
       <Link to="Compliance">Compliance</Link>
       </Col>

        <Col sm="4" md="4" lg={{span:2 , offset:4}}  className='d-flex justify-content-end UacC2 '>
          <span className='bi bi-question-circle UacCL' style={{"color":"red"}}></span>
          <span className='bi bi-play-circle UacCL1'></span>
        </Col> 
      
         </Row>
         <Row>
            
         <Col> <Outlet/> </Col>
         </Row>

   </Container>
  )
}

export default UserAndControls