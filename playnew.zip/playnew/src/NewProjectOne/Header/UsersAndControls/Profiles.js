import React from 'react'
import { Container,Row,Col,Button } from 'react-bootstrap'
import {  Table,Thead,Th,Tr } from 'react-super-responsive-table'
import './Profiles.css'
import { Outlet } from 'react-router-dom'

const Profiles = () => {
  return (
   <Container className='PrC1'>
    <Row className='PrR1'>
      <h5>Profiles</h5>
       <Col sm="6" lg="10" className='d-flex PrCol'>
       <Col sm="4"lg="10" className='PrCol1'>
          <p>Profiles help you define a set of permissions for each user as well as the actions they can
           perform in Bigin. When you invite users, you assign a profile to each of them.</p></Col>
      
           <Col  sm="2"lg="2" className='PrCol2'>
            <Button variant='success' type='submit'className="PrBu1" ><span className='bi bi-plus '>New User</span></Button>
            </Col>
       </Col>
        
     
    </Row>
      <hr/>
    <Row >
        <Col className='PrCol3'>
          <Table striped bordered>
           <Thead>
            <Tr>
              <Th>Profile Name</Th>
              <Th>Profile Description</Th>
              <Th>Modified By</Th>
             
            </Tr>
           </Thead>
          </Table>
          </Col>
        </Row>
    <Outlet/>
   </Container>
  )
}

export default Profiles