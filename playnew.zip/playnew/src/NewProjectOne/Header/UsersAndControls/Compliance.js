import React from 'react'
import { Container,Row,Col } from 'react-bootstrap'
import { Link } from 'react-router-dom'
import { Outlet } from 'react-router-dom'
import './Compliance.css'

const Compliance = () => {
  return (
    <Container className='CoContainer'>
      <Row><Col xs="4" lg="3" className='d-flex justify-content-start CoCol1' >
       <Link to="GDPRCompliance"> GDPR Compliance</Link> </Col>
        <Col xs="4" lg="3" className='d-flex CoCol2' ><Link to="HIPAACompliance">HIPAA Compliance</Link>  
      </Col></Row>
      <Row>
       
      <Outlet/>
      </Row>
    </Container>
  )
}

export default Compliance
