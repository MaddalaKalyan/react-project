import React from 'react'
import { Container,Row,Col,Dropdown,Form,Button, Table } from 'react-bootstrap'
import { Thead,Th,Tr } from 'react-super-responsive-table'
import './Users.css'

const Users = () => {
  return (
  <Container>
    <Row className='d-flex URow1'>
            <Col sm="6" lg="6" >
            <Dropdown className='Udd1'>
                        <Dropdown.Toggle variant="light" id="dropdown-basic">
                        Active Users
                        </Dropdown.Toggle>

                        <Dropdown.Menu>
                            <Dropdown.Item href="#/action-1">Active Users</Dropdown.Item>
                            <Dropdown.Item href="#/action-2">Another action</Dropdown.Item>
                            <Dropdown.Item href="#/action-3">Something else</Dropdown.Item>
                        </Dropdown.Menu>
            </Dropdown>
            </Col>
            <Col sm="6" lg="6" className="d-flex">
                     <Col sm="6" lg="6" className='UCCols1 d-flex justify-content-end'>
                         <Form className="d-flex justify-content-end">
                                        <Form.Control
                                            type="search"
                                            placeholder="Search"
                                          className='UFcls1'
                                            aria-label="Search"
                                          />
                              <Button variant="nocolor" placeholder='search' className="bi bi-search UBcls1" type="search"></Button>
                         </Form>
          
              </Col>  
              <Col  sm="6" lg="6" className='UBcls2 d-flex justify-content-end'>
            <Button variant='success' type='submit' className='UBcls3' ><span className='bi bi-plus'>New User</span></Button>
            </Col>
          
            </Col>
        </Row>
        
        <br/>
        <Row>
          <Col className='UcCls1'>
          <Table striped bordered hover>
           <Thead>
            <Tr>
              <Th>FullName</Th>
              <Th>Email</Th>
              <Th>Role</Th>
              <Th>Profile</Th>
            </Tr>
           </Thead>
          </Table>
          </Col>
        </Row>
  </Container>
  )
}

export default Users
