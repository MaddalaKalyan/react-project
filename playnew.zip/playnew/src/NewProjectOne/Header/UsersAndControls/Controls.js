import React from 'react'


function Controls() {
  return (
    <div>
    
        <p>dad</p>
      <hr/>
   
    </div>
  )
}

export default Controls
