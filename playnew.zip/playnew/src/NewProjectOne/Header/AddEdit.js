import {React ,useState} from 'react';
import { Container, Row ,Button,Offcanvas,Form,Col, Card,Tab,Tabs} from 'react-bootstrap';
import Send123 from './APIFolder/Send123'
import Receive from './Receive';











const AddEdit = () => {
    function OffCanvasExample({ name, ...props }) {
        const [show, setShow] = useState(false);
      
        const handleClose = () => setShow(false);
        const handleShow = () => setShow(true);
      
        return (
          <>
            <Button variant="primary" className='bi bi-pen '  onClick={handleShow}>
          
            </Button>  
            <Offcanvas show={show} onHide={handleClose} {...props} style={{"width":"700px"}}>
              <Offcanvas.Header closeButton>
                <Offcanvas.Title>
                    API Description 
                </Offcanvas.Title>
              </Offcanvas.Header>
              <Offcanvas.Body>
            


              <Container>
    <Row>
    <Form>
           <Row className='d-flex'>
                <Col lg="4"><Form.Label>Company Name</Form.Label></Col>
                 <Col lg="6"><Form.Control type="text" placeholder="Enter Your Company Name" /></Col>
           </Row>
           <br/>
           <Row className='d-flex'>
                <Col lg="4"><Form.Label>API Name</Form.Label></Col>
                 <Col lg="6"><Form.Control type="text" placeholder="Enter Your API Name" /></Col>
           </Row>
           <br/>
           <Row className='d-flex'>
                <Col lg="4"><Form.Label>API Description</Form.Label></Col>
                 <Col lg="6"><Form.Control as="textarea" rows={3} placeholder="Enter Your API Description" /></Col>
           </Row>
           <br/>
           <Row className='d-flex'>
                <Col lg="4"><Form.Label>API URL </Form.Label></Col>
                 <Col lg="6"><Form.Control type="text" placeholder="Enter Your API URL " /></Col>
           </Row>
           <br/>
           <Row className='d-flex'>
                <Col lg="4"><Form.Label>API key/Token </Form.Label></Col>
                 <Col lg="6"><Form.Control type="text" placeholder="Enter Your API key/Token " /></Col>
           </Row>
        </Form>
        <Row>
        <Col lg="2" className="d-flex justify-content-start" style={{"width":"150px"}}>
                <Form.Select aria-label="Default select example" >
                <option>Open this select menu</option>
                <option value="GET">GET</option>
                <option value="POST">POST</option>
                <option value="PUT">PUT</option>
                <option value="PATCH">PATCH</option>
                <option value="DELETE">DELETE</option>
                <option value="LINK">LINK</option>
                <option value="LINK">UNLINK</option>
                <option value="HEAD">HEAD</option>
                <option value="PURGE">PURGE</option>
                <option value="LOCK">LOCK</option>
                <option value="UNLOCK">UNLOCK</option>
               </Form.Select> 
       </Col>
    </Row>
        <Row> 
        <Tabs  defaultActiveKey="profile"
                                id="justify-tab-example"
                                selectedTabClassName="bg-white" justify>
                 <Tab eventKey="Send123"     
                             className="cursor-pointer py-4 px-8 bg-red-background border border-red-intermediate flex flex-grow"
                             title="Send"><Send123/></Tab>
                            <Tab eventKey="Receive" title="Receive"><Receive/></Tab>
                          </Tabs>
                  </Row>
          <Button variant='success'>Save</Button>
    </Row>
</Container>

             

              </Offcanvas.Body>
            </Offcanvas>
          </>
        );
      }
      
  return (
    <Container>
        {['end'].map((placement, idx) => (
        <OffCanvasExample key={idx} placement={placement} name={placement} />
      ))}
   
    </Container>
  )
}

export default AddEdit