import React from "react";
import ReactDOM from "react-dom";

import {  FormBuilder, Components } from '@formio/react';
import "./Styles.css";
import components from './Custom';
import { Container, Row } from "react-bootstrap";


const DragAndDropFormController=()=>{
Components.setComponents(components);

function App() {
  return (
   <Container>
    <Row>
    <div className="App">
       <FormBuilder
        form={{ display: "form" }}
        onChange={schema => console.log(schema)}
        options={{
          builder: {
            basic: {
              components: {
                toggleCustomComp: true
              }
            },
            advanced: false
          }
        }}
      /> 
    </div>
    </Row>
   </Container>
  );
}

const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);}
export default DragAndDropFormController