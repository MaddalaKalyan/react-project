import toggleCustomComp from './Toggle';

export default {
  toggleCustomComp
};
