import React,{useState} from 'react'
import { Container,Row,Col,Form, Table ,Button} from 'react-bootstrap'
import { Thead,Th,Tr,Td, Tbody } from 'react-super-responsive-table'

const Receive = () => {
    const [rows, setRows] = useState([{}]);
    const columnsArray = [''] ; // pass columns here dynamically
    const columnsArray1 = [''];
  
    
    const handleAddRow = () => {
      const item = {};
      setRows([...rows, item]);
    };
  
    const postResults = () => {
      console.log(rows); // There you go, do as you please
    };
    const handleRemoveSpecificRow = (idx) => {
      const tempRows = [...rows]; // to avoid  direct state mutation
      tempRows.splice(idx, 1);
      setRows(tempRows);
    };
  
    const updateState = (e) => {
      let prope = e.target.attributes.column.value; // The custom column attribute
      let index = e.target.attributes.index.value; // index of state array -rows
      let fieldValue = e.target.value; // value
  
      const tempRows = [...rows]; // avoid direct state mutation
      const tempObj = rows[index+1]; // copy state object at index to a temporary object
      tempObj[prope] = fieldValue; // modify temporary object
  
      // return object to rows` clone
      tempRows[index] = tempObj;
      setRows(tempRows); // update state
    };
  return (
   <Container>
    <Row>
        <Col lg="2" className="d-flex justify-content-start" style={{"width":"150px"}}>
                <Form.Select aria-label="Default select example" >
                <option>Open this select menu</option>
                <option value="GET">GET</option>
                <option value="POST">POST</option>
                <option value="PUT">PUT</option>
                <option value="PATCH">PATCH</option>
                <option value="DELETE">DELETE</option>
                <option value="LINK">LINK</option>
                <option value="LINK">UNLINK</option>
                <option value="HEAD">HEAD</option>
                <option value="PURGE">PURGE</option>
                <option value="LOCK">LOCK</option>
                <option value="UNLOCK">UNLOCK</option>
               </Form.Select> 
       </Col>
    </Row>
    <Row>
 
 <div className="col-md-12 column">
         <table className="table table-bordered table-hover" id="tab_logic">
           <thead>
             <tr>
               <th className="text-center">S.no </th>
               {columnsArray.map((column, index) => (
                 <th className="text-center" key={index}>
                   {column}
             Key
                 </th>
               ))}
               {columnsArray.map((column, index) => (
                 <th className="text-center" key={index+1}>
                   {column} 
                   Value
                 </th>
               ))}
                 
               <th />
             </tr>
           </thead>
           <tbody>
            
             {rows.map((item, idx) => (
               <tr key={idx}>
                 <td>{idx + 1}</td>
                 {columnsArray.map((column, index) => (
                   <td key={index}>
                  
                 
                   </td>
                    
                   
                 ))}
                 
                  {columnsArray.map((column, index) => (
                 <td key={index}>
                    
                
                  </td>
                  ))}
                  
                 
                  <td>
                   <Button
                   variant="danger" className="bi bi-trash3"
                     onClick={() => handleRemoveSpecificRow(idx)}
                   ></Button>
                   <Button variant="success" className="bi bi-plus-circle" onClick={handleAddRow} ></Button>
                 </td>
                 
              
               </tr>
             ))}
             </tbody>
         </table>
        
       </div>
     
     
   
 </Row>
   </Container>
  )
}

export default Receive