 import React from 'react'
import { Container, Row,Col ,Card} from 'react-bootstrap'
import { Link, Outlet } from 'react-router-dom'
import './Setting.css';

function Setting() {
  return (
    <Container fluid className="SetC1">
        <Row className='SetR1' >
            <Col sm="2" lg="3" className='SetCol1'>
               <Card className='SetCard1'>
                 <h4>Settings</h4>
                    <ul> 

                          <li><Link to="UserAndControls">User And Controls</Link></li> 
                          <li><Link to="Organization">Organization</Link></li> 
                          <li> <Link to="Fields">Fields</Link></li> 
                          <li><Link to="PipeLineAndStages">Pipelines and Stages</Link></li>
                          <li><Link to="Webforms">Web Forms</Link></li>
                          <li><Link to="Workflows">Work flows</Link></li>
                          <li><Link to="DataAdmin">Data Administration</Link></li>
                          <li><Link to="Integrations">Integrations</Link></li>
                          <li><Link to="APIONe">API</Link></li>
                          <li><Link to="APIPage">API Page</Link></li>
                          <li><Link to="Decision">Decision Page</Link></li>
                          <li><Link to="TablesPage">Tables</Link></li>
                          <li><Link to="FormControllers">FormControllers</Link></li>
                          <li><Link to="TableFormControllers">TableFormControllers</Link></li>
                          {/* <li><Link to="DragAndDropFormController">DragAndDropFormController</Link></li>  */}
                          <li><Link to="LoginPage">LoginPage</Link></li>
                          <li><Link to="SignUp">SignUp</Link></li>
                          <h5>Channels</h5>
                          <li><Link to='EMail'>EMail</Link></li>
                          <li><Link to='Social'>Social</Link></li>
                          <li><Link to='Phone'>Phone</Link></li>
                          <li><Link to='Signals'>Signals</Link></li>
                        

                  </ul>
                
               </Card>
               
            </Col>
            <Col sm="6" lg="9" className='SetCard2'><Outlet/></Col>
     </Row>
    
    

    </Container>
  )
}

export default Setting
