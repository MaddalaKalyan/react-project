import React from 'react'
import { Container,Row,Col } from 'react-bootstrap'

import { Outlet,Link } from 'react-router-dom'
import './Organization.css'

const Organization = () => {
  return (
    <Container className='OrgContainer'>
      <Row className='d-flex OrgRow'>
        <Col sm="6" lg="6" className="d-flex">
           <Col sm="3" lg="3" className='OrgCol1'><Link to="OrganizationDetails">OrganizationDetails</Link></Col>
           <Col sm="3" lg="3"  className='OrgCol1'><Link to="Currencies"> Currencies</Link></Col>
        </Col>
        <Col sm="6" lg="6" className="d-flex justify-content-end">
           <Col sm="3" lg={{ span: 2, offset: 10 }} className='OrgCol2' >
              <span className='bi bi-question-circle OrgCol3 '></span>
           </Col>
        </Col>
      </Row>
        
     <Row><Outlet/></Row>
       
    </Container>
  )
}

export default Organization
