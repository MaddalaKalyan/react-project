import React from 'react'
import { Container, Row,Col,Card } from 'react-bootstrap'
import { Outlet,Link } from 'react-router-dom'
import "./OrganizationDetails.css"

const OrganizationDetails = () => {
  return (
   <Container className='ODContainer'>
  <Card className='ODCard1'>
  <Row className='d-flex ODRow'>
        <Col sm="2" lg="1" className='d-flex ODCol1'>K</Col>
        <Col sm="2" lg="8">
            <Col sm="2" lg="7">Kalyan</Col>
            <Col sm="2" lg="7"><span className='bi bi-person-plus'></span></Col>
        </Col>
        <Col sm="2" lg="1" className='d-flex ODCol1'><span className='bi bi-pencil'></span>
       </Col> 

       
        
    </Row>

  </Card>
 
    <Card className='ODCard2'>
    <Row>
        <Col lg="8" className='ODCardCol1'>
        <h6>Basic Information</h6>
        </Col>
        </Row>
        <Row className='ODRow1' >
          <Col>
          <ul>
            <li>Phone  :</li>
            <li>Mobile  :</li>
            <li>Fax :</li>
            <li>Description :</li>
          </ul>
          </Col>
        </Row>
        <Row className='ODRow1'>
        <Col>
          <ul>
            <li>Address :</li>
          </ul>
          </Col>
        </Row>
      
        <Row className='ODRow1'>
        <Col>
        <h6>Local Information</h6> 
          <ul>
            <li>Currency :</li>
            <li>Time Zone :</li>
          </ul>
          </Col>
        </Row>
        <hr/>
        <Row className='ODColRow1'>
          <Link> Delete this Account</Link></Row>
    </Card>
 
 
    <Row>
    <hr/><Outlet/>

    </Row>
 
    
   </Container>
  )
}

export default OrganizationDetails