import React from 'react'
import { Container,Col,Row,Button, Card} from 'react-bootstrap'
import {Table, Thead,Th,Tr, } from 'react-super-responsive-table'
import './Currencies.css'
import { Link, Outlet } from 'react-router-dom'

const Currencies = () => {
  return (
   <Container>
       <Row className='d-flex '> 
       <hr/>
        <Col xs="6" lg="10" className='CuCol1'>
          <h6>Currencies</h6>
             <p>   You can add up to 10 active currencies.
              You can't change the home currency once multiple currencies are added.</p>
               <Card className='CuCard1'>
                <Row className="d-flex">
                  <Col lg="1" className='CuCol4'>
                   <h6>Note:</h6>
                </Col>
                <Col lg="8">
                <p>You can change your home currency from <Link>Organization Settings</Link></p>
                </Col>
                </Row>
                 </Card>
        </Col>
         <Col lg="2">   
          <Col xs="5" lg="2" className='CuCol2'>
          <Button variant='success' type='submit'className="CuBu1" ><span className='bi bi-plus '>New Currency</span></Button>
          </Col></Col>
       
        </Row>
       
        <Row className='CuRow1'>
          <Col  className='CuCol4'>
          <Table striped bordered>
           <Thead>
            <Tr>
              <Th> Currency Name</Th>
              <Th>Symbol</Th>
              <Th>Exchange Rate</Th>
              <Th>Last Modified By</Th>
              <Th>Status</Th>
             </Tr>
           </Thead>
           
          </Table>
          </Col>
        </Row>
      
        
        <Row>
          <Outlet/>
        </Row>
    </Container>
  )
}

export default Currencies