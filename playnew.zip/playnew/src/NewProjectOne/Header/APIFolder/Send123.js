import React,{useState} from 'react'
import { Container, Table,Row,Col ,Button,Form} from 'react-bootstrap'
import { Tbody, Thead,Th,Tr,Td } from 'react-super-responsive-table'
function TableRows({ rows, tableRowRemove, onValUpdate }) {
    return rows.map((rowsData, index) => {
      const { name, email, profile } = rowsData;
      return (
        <Tr key={index}>
          <Td>
            <input
              type="text"
              value={name}
              onChange={(event) => onValUpdate(index, event)}
              name="Key"
              className="form-control"
            />
          </Td>
          <Td>
            <input
              type="text"
              value={email}
              onChange={(event) => onValUpdate(index, event)}
              name="Value"
              className="form-control"
            />
          </Td>
       
          <Td>
            <button
              className="btn btn-dark"
              onClick={() => tableRowRemove(index)}
            >
              Delete Row
            </button>
          </Td>
        </Tr>
      );
    });
  }
const Send123 = () => {
    const [rows, setRows] = useState([{}]);
    const columnsArray = [''] ; // pass columns here dynamically
    const columnsArray1 = [''];
  
    const handleAddRow = () => {
      const item = {};
      setRows([...rows, item]);
    };
  
    const postResults = () => {
      console.log(rows); // There you go, do as you please
    };
    const handleRemoveSpecificRow = (idx) => {
      const tempRows = [...rows]; // to avoid  direct state mutation
      tempRows.splice(idx, 1);
      setRows(tempRows);
    };
  
    const updateState = (e) => {
      let prope = e.target.attributes.column.value; // The custom column attribute
      let index = e.target.attributes.index.value; // index of state array -rows
      let fieldValue = e.target.value; // value
  
      const tempRows = [...rows]; // avoid direct state mutation
      const tempObj = rows[index+1]; // copy state object at index to a temporary object
      tempObj[prope] = fieldValue; // modify temporary object
  
      // return object to rows` clone
      tempRows[index] = tempObj;
      setRows(tempRows); // update state
    };
  return (
    <Container>
        <Row>
            <Col>
            <table className="table table-bordered table-hover" id="tab_logic">
              <thead>
                <tr>
                  <th className="text-center">S.NO</th>
                  {/* {columnsArray.map((column, index) => (
                    <th className="text-center" key={index}>S.NO</th>
                  ))} */}
                  {columnsArray.map((column, index) => (
                    <th className="text-center" key={index+1}>KEY</th>
                  ))}
                    {columnsArray.map((column, index) => (
                    <th className="text-center" key={index+2}>VALUE</th>
                  ))}
                  {columnsArray.map((column, index) => (
                    <th className="text-center" key={index+2}>DESCRIPTION</th>
                  ))}
                  <th colSpan="1"><button className="btn btn-outline-success bi bi-plus-circle" onClick={handleAddRow}></button>
                    </th>
                </tr>
              </thead>
              <tbody>
               
                {rows.map((item, idx) => (
                  <tr key={idx}>
                    <td>{idx + 1}</td>
                    {/* {columnsArray.map((column, index) => (
                      <td key={index}>
                      <Form.Control type="Text" placeholder="" />
                      </td>
                    ))} */}
                    
                     {columnsArray.map((column, index) => (
                    <td key={index}>
                    <Form.Control type="Text" placeholder="key" />
                     </td>
                     ))}
                       {columnsArray.map((column, index) => (
                    <td key={index}>
                    <Form.Control type="Text" placeholder="value" />
                    </td>
                     ))}
                    {columnsArray.map((column, index) => (
                    <td key={index}>
                    <Form.Control type="Text" placeholder="description" />
                    </td>
                     ))}
                     <td>
                      <Button
                      variant="danger" className="bi bi-trash3" onClick={() => handleRemoveSpecificRow(idx)}></Button>
                    </td>
                    {/* <td><Button className='btn btn-outline-info bi bi-pen-fill'></Button></td> */}
                  </tr>
                ))}
                </tbody>
            </table>
            </Col>
        </Row>
    </Container>
  )
}

export default Send123