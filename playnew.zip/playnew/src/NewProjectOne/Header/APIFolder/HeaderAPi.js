import React from 'react'
import { useLocalStore } from "mobx-react-lite";
import { Container, Row, Tabs,Tab,Col,Button,ButtonGroup} from 'react-bootstrap'
import { Table,Tbody, Td, Tr,Thead } from 'react-super-responsive-table';
import Hidden from './Hidden';
import { CheckboxDropdown } from './CheckboxDropDown';

const HeaderAPi = () => {
  const state = useLocalStore(() => ({
    items: [
      { id: "em", label: "Value", checked: true },
      { id: "f", label: "Description", checked: true },
  
     
    ]
  }));
  
  return (
   <Container>
    <Row className='d-flex'>
    
     <tr>Header
    {/*<Tabs 
            id="justify-tab-example"
            className="mb-3">
       <Tab eventKey="Hidden" title="Hidden"><Hidden/></Tab>
  </Tabs>*/}</tr>
      
    </Row>
    <Row>
      <Table>
        <Thead>
          <tr>
            <th>#</th>
            <th>KEY</th>
            <th>VAlUE</th>
            <th>DESCRIPTION</th>
            <th>
             <CheckboxDropdown items={state.items} />
            </th>
            <th>
              <Button variant='light'>BulkEdit</Button>
            </th>

          </tr>
        </Thead>
        <Tbody>
         <tr>
         <td>#</td>
            <td>KEY</td>
            <td>VAlUE</td>
            <td>DESCRIPTION</td>
            <td></td>
            <td></td>

         </tr>
         

        </Tbody>
      </Table>
    </Row>
   </Container>
  )
}

export default HeaderAPi