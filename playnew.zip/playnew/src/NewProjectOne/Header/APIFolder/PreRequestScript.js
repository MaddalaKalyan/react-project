import React from 'react'

const PreRequestScript = () => {
  return (
    <div>PreRequestScript</div>
  )
}

export default PreRequestScript