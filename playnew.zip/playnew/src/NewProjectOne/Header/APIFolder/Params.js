import React from 'react'
import { useLocalStore } from "mobx-react-lite";

import { Button, Container,Dropdown,Row ,Table,} from 'react-bootstrap'
import { Tbody, Td, Tr,Thead } from 'react-super-responsive-table'
import { CheckboxDropdown } from './CheckboxDropDown';

const Params = () => {
  const state = useLocalStore(() => ({
    items: [
      { id: "em", label: "Value", checked: true },
      { id: "f", label: "Description", checked: true },
  
     
    ]
  }));
  return (
  <Container>
    <Row>
      <p>Query Params</p>
    
    </Row>
    <Row>
      <Table>
        <Thead>
          <tr>
            <th>#</th>
            <th>KEY</th>
            <th>VAlUE</th>
            <th>DESCRIPTION</th>
            <th>
             <CheckboxDropdown items={state.items} />
            </th>
            <th>
              <Button variant='light'>BulkEdit</Button>
            </th>

          </tr>
        </Thead>
        <Tbody>
         <tr>
         <td>#</td>
            <td>KEY</td>
            <td>VAlUE</td>
            <td>DESCRIPTION</td>
            <td></td>
            <td></td>0

         </tr>
         

        </Tbody>
      </Table>
    </Row>
  </Container>
  )
}

export default Params