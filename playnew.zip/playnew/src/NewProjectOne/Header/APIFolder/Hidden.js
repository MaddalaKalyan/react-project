import React from 'react'
import { Container, Form, Table ,Row,Col} from 'react-bootstrap'
import { Th, Thead, Tr } from 'react-super-responsive-table'

const Hidden = () => {
  return (
    <Container>
        <Row>
            <Col>
            <Table>
                <Thead>
                    <Tr>
                        <Th><Form.Group>
                            <Form.Check type="checkbox"></Form.Check></Form.Group>
                        </Th>
                        <Th>Key</Th>
                        <Th>Value</Th>
                        <Th>Description</Th>
                    </Tr>
                </Thead>
            </Table>
            </Col>
        </Row>
    </Container>
  )
}

export default Hidden