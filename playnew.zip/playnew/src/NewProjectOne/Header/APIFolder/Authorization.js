import React from 'react'
import { Container, Row,Col, Form,Nav } from 'react-bootstrap'
import { Outlet,Link } from 'react-router-dom';
import Params from './Params';

const Authorization = () => {
  return (
   <Container>
    <Row>
      <Col lg="3">
        <Row>
          <Col lg="2">Type</Col>
          <Col lg="8">
          <Form.Select aria-label="Default select example">
      <option>Open this select menu</option>
      <option value="homw"><Nav.Link to="/Params"><Params/></Nav.Link></option>
      <Link><option value="2">Two</option></Link>
      <option value="3">Three</option>
    </Form.Select>
          </Col>
        </Row>
      </Col>
      <Col lg="9">
        <Outlet/>
      </Col>
    </Row>
   </Container>
  )
}

export default Authorization