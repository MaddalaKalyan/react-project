import React from 'react'
import { Container, Table,Row, Form, Button, Col, Tab ,ButtonGroup,Dropdown,Tabs} from 'react-bootstrap'
import { Outlet ,Link} from 'react-router-dom'
import {Thead,Th, Tr, Td, Tbody} from 'react-super-responsive-table'
import Authorization from './Authorization';
import Params from './Params';
import HeaderAPi from './HeaderAPi';
import APITest from './APITest';
import APIBody from './APIBody';
import PreRequestScript from './PreRequestScript';
import API_Settings from './API_Settings'
const APIONe = () => {
  return (
    <Container>
        <Row>
          <Table striped bordered hover>
            <Thead>
                <Th>
                    <Row>
                        <Col sm="2" md="2" lg="2">
                                <select     
                                 className="form-select-sm select"
                                 aria-label="Default select example">
                                         <option defaultValue hidden></option>
                                         <option value="Action">GET</option>
                                         <option value="Action">POST</option>
                                         <option value="UpdateTable">PUT</option>
                                         <option value="SendEmail">PATCH</option>
                                         <option value="SendSms">DELETE</option>
                                         <option defaultValue hidden>LINK</option>
                                         <option value="Action">UNLINK</option>
                                         <option value="UpdateTable">HEAD</option>
                                         <option value="SendEmail">PURGE</option>
                                         <option value="SendSms">LOCK</option>
                                         <option value="SendSms">UNLOCK</option>
                                </select></Col>
                                <Col  sm="6" md="8" lg="8">
                                <Form.Control type='text'
                                 placeholder='Enter your "URL":"https://..." HERE' 
                                >

                                </Form.Control>
                                </Col>
                                <Col sm="2" md="2" lg="2">
                                <Dropdown as={ButtonGroup}>
                                    <Button variant="primary">POST</Button>
                                    <Dropdown.Toggle split variant="primary" id="dropdown-split-basic" />

                                    <Dropdown.Menu>
                                        <Dropdown.Item href="#/action-1">Send and Download </Dropdown.Item>
                                       
                                    </Dropdown.Menu>
                                    </Dropdown>
                                </Col>
                            </Row>
                           </Th>
                           </Thead>
                           <Thead>
                           <Tr>
                            <Row> <Col lg="11">
                          <Tabs  defaultActiveKey="profile"
                                id="justify-tab-example"
                                className="mb-3"
                                justify>
                            <Tab eventKey="Params" title="Params"><Params/></Tab>
                            <Tab eventKey="HeaderApi" title="Header"><HeaderAPi/></Tab>
                            <Tab eventKey="APITest" title="Tests"><APITest/></Tab>
                            <Tab eventKey="Authorization" title="Authorization"><Authorization/></Tab>
                            <Tab eventKey="APIBody" title="Body"><APIBody/></Tab>
                            <Tab eventKey="PreRequestScript" title="Prerequest-Script"><PreRequestScript/></Tab>
                            <Tab eventKey="API_Settings" title="Settings"><API_Settings/></Tab>
                          </Tabs>
                          </Col>
                         <Col lg="1 "><Link>Cookies</Link></Col>
                          </Row>
                          <Row>
                          <Tbody>
                     
                       
                            responsive
                          
                          
                         </Tbody>
                          </Row>
                          </Tr>
                          </Thead>
                        
          </Table>
          </Row>
        <Outlet/>
    </Container>
  )
}

export default APIONe