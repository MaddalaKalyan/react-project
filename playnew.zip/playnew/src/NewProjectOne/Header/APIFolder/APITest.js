import React from 'react'

const APITest = () => {
  return (
    <div>APITest</div>
  )
}

export default APITest