import {React ,useState,us} from 'react';
import { Container, Row ,Button,Offcanvas,Form,Col, Card,Tab,Tabs,InputGroup} from 'react-bootstrap';





const AddRowinOffCanVas = () => {
    
    
    function OffCanvasExample({ name, ...props }) {
        const [show, setShow] = useState(false);
      
        const handleClose = () => setShow(false);
        const handleShow = () => setShow(true);
     




        return (
          <>
            <Button variant="info" className=' '  onClick={handleShow}>
                Add Row
            </Button>  
            <Offcanvas show={show} onHide={handleClose} {...props} style={{"width":"600px"}}>
              <Offcanvas.Header closeButton>
                <Offcanvas.Title>
                 Table Components
                </Offcanvas.Title>
              </Offcanvas.Header>
              <Offcanvas.Body>
               <Container>
                    <Form noValidate>
                        <Row>
                            <Col className='d-flex justify-content-end' lg="4" md="4">
                            <Form.Label>TableName:</Form.Label> 
                            </Col>
                            <Col className='d-flex justify-content-start' lg="6" md="6">
                            <Form.Control     type="text"  id="inputPassword5"  aria-describedby="passwordHelpBlock"/></Col>
                        </Row>
                        <br/>
                        <Row>
                            <Col className='d-flex justify-content-end' lg="4" md="4">
                            <Form.Label >Display Name</Form.Label> 
                            </Col>
                            <Col className='d-flex justify-content-start' lg="6" md="6">
                            <Form.Control     type="text"  id="inputPassword5"  aria-describedby="passwordHelpBlock"/></Col>
                        </Row>
                        <br/>
                        <Row>
                            <Col className='d-flex justify-content-end' lg="4" md="4">
                            <Form.Label>Field Name:</Form.Label> 
                            </Col>
                            <Col className='d-flex justify-content-start' lg="6" md="6">
                            <Form.Control     type="text"  id="inputPassword5"  aria-describedby="passwordHelpBlock"/></Col>
                        </Row>
                        <br/>
                        <Row>
                            <Col className='d-flex justify-content-end' lg="4" md="4">
                            <Form.Label>Input Type:</Form.Label> 
                            </Col>
                            <Col className='d-flex justify-content-start' lg="6" md="6">
                            <Form.Select aria-label="Default select example">
                                <option>Open this select menu</option>
                                <option value="1">One</option>
                                <option value="2">Two</option>
                                <option value="3">Three</option>
                            </Form.Select>
                            </Col>
                        </Row>
                        <br/>
                        <Row>
                            <Col className='d-flex justify-content-end' lg="4" md="4">
                            <Form.Label>Constaint:</Form.Label> 
                            </Col>
                            <Col className='d-flex justify-content-start' lg="6" md="6">
                            <Form.Select aria-label="Default select example">
                                <option>Open this select menu</option>
                                <option value="1">One</option>
                                <option value="2">Two</option>
                                <option value="3">Three</option>
                            </Form.Select>
                            </Col>
                        </Row>
                        <br/>
                        <Row>
                            <Col className='d-flex justify-content-end' lg="4" md="4">
                            <Form.Label>Is Default:</Form.Label> 
                            </Col>
                            <Col className='d-flex justify-content-start' lg="6" md="6">
                               <InputGroup className="mb-3">
                              <InputGroup.Checkbox aria-label="Checkbox for following text input" />  </InputGroup>
                              
                            </Col>
                        </Row>
                        <br/>
                        <Row>
                            <Col className='d-flex justify-content-end' lg="4" md="4">
                            <Form.Label>Is Editable:</Form.Label> 
                            </Col>
                            <Col className='d-flex justify-content-start' lg="6" md="6">
                               <InputGroup className="mb-3">
                              <InputGroup.Checkbox aria-label="Checkbox for following text input" />  </InputGroup>
                              
                            </Col>
                        </Row>
                        <br/>
                        <Row>
                            <Col className='d-flex justify-content-end' lg="4" md="4">
                            <Form.Label>Is Unique:</Form.Label> 
                            </Col>
                            <Col className='d-flex justify-content-start' lg="6" md="6">
                               <InputGroup className="mb-3">
                              <InputGroup.Checkbox aria-label="Checkbox for following text input" />  </InputGroup>
                              
                            </Col>
                        </Row>
                        <br/>
                        <Row>
                            <Col className='d-flex justify-content-end' lg="4" md="4">
                            <Form.Label>AutoIncrement:</Form.Label> 
                            </Col>
                            <Col className='d-flex justify-content-start' lg="6" md="6">
                               <InputGroup className="mb-3">
                              <InputGroup.Checkbox aria-label="Checkbox for following text input" />  </InputGroup>
                              
                            </Col>
                        </Row>
                        <br/>
                        <Row>
                            <Col className='d-flex justify-content-end' lg="4" md="4">
                            <Form.Label>Is Unsigned:</Form.Label> 
                            </Col>
                            <Col className='d-flex justify-content-start' lg="6" md="6">
                               <InputGroup className="mb-3">
                              <InputGroup.Checkbox aria-label="Checkbox for following text input" />  </InputGroup>
                              
                            </Col>
                        </Row>
                        <br/>
                        <Row>
                            <Col className='d-flex justify-content-end' lg="4" md="4">
                            <Form.Label>Is Default:</Form.Label> 
                            </Col>
                            <Col className='d-flex justify-content-start' lg="6" md="6">
                               <InputGroup className="mb-3">
                              <InputGroup.Checkbox aria-label="Checkbox for following text input" />  </InputGroup>
                              
                            </Col>
                        </Row>
                        <br/>
                        <Row>
                            <Col className='d-flex justify-content-end' lg="4" md="4">
                            <Form.Label>Is Default:</Form.Label> 
                            </Col>
                            <Col className='d-flex justify-content-start' lg="6" md="6">
                               <InputGroup className="mb-3">
                              <InputGroup.Checkbox aria-label="Checkbox for following text input" />  </InputGroup>
                              
                            </Col>
                        </Row>
                        <br/>
                        <Row>
                            <Col className='d-flex justify-content-end' lg="4" md="4">
                            <Form.Label>Is Default:</Form.Label> 
                            </Col>
                            <Col className='d-flex justify-content-start' lg="6" md="6">
                               <InputGroup className="mb-3">
                              <InputGroup.Checkbox aria-label="Checkbox for following text input" />  </InputGroup>
                              
                            </Col>
                        </Row>
                        <br/>
                        <Row>
                            <Col className='d-flex justify-content-end' lg="2"> <Button variant='success' >
                        Save</Button></Col>
                        </Row>
                    </Form>
               </Container>

             

              </Offcanvas.Body>
            </Offcanvas>
          </>
        );
      }
      
  return (
    <Container>
        {['end'].map((placement, idx) => (
        <OffCanvasExample key={idx} placement={placement} name={placement} />
      ))}
   
    </Container>
  )
}

export default AddRowinOffCanVas