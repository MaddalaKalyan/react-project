import React from 'react'

const API_Settings = () => {
  return (
    <div>API_Settings</div>
  )
}

export default API_Settings