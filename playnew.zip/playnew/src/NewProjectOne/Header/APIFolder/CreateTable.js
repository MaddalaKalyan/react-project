import React, { useState } from 'react';
import { Container,Offcanvas,Row,Col,Form,Nav } from 'react-bootstrap';
import Button from '@mui/material/Button';
import Snackbar from '@mui/material/Snackbar';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';



function OffCanvasExample({ name, ...props }) {
  const [show, setShow] = useState(false);
  const handleClose1 = () => setShow(false);
  const handleShow = () => setShow(true);

  const [rows, setRows] = useState([{}]);
    const columnsArray = [''] ; // pass columns here dynamically
    const columnsArray1 = [''];
  
    
    const handleAddRow = () => {
      const item = {};
      setRows([...rows, item]);
    };
  
    const postResults = () => {
      console.log(rows); // There you go, do as you please
    };
    const handleRemoveSpecificRow = (idx) => {
      const tempRows = [...rows]; // to avoid  direct state mutation
      tempRows.splice(idx, 1);
      setRows(tempRows);
    };
  
    const updateState = (e) => {
      let prope = e.target.attributes.column.value; // The custom column attribute
      let index = e.target.attributes.index.value; // index of state array -rows
      let fieldValue = e.target.value; // value
  
      const tempRows = [...rows]; // avoid direct state mutation
      const tempObj = rows[index+1]; // copy state object at index to a temporary object
      tempObj[prope] = fieldValue; // modify temporary object
  
      // return object to rows` clone
      tempRows[index] = tempObj;
      setRows(tempRows); // update state
    };


    const [open, setOpen] = React.useState(false);

    const handleClick = () => {
      setOpen(true);
    };
  
    const handleClose = (event, reason) => {
      if (reason === 'clickaway') {
        return;
      }
  
      setOpen(false);
    };
  
    const action = (
      <React.Fragment>
        <Button color="secondary" size="small" onClick={handleClose1}>
          UNDO
        </Button>
        <IconButton
          size="small"
          aria-label="close"
          color="inherit"
          onClick={handleClose1}
        >
          <CloseIcon fontSize="small" />
        </IconButton>
      </React.Fragment>
    );
  return (
    <>
      <Button variant="primary" onClick={handleShow} className="me-2">
        Create Tables
      </Button>
      <Offcanvas show={show} onHide={handleClose1} {...props} style={{"width":"750px"}}>
        <Offcanvas.Header closeButton>
          <Offcanvas.Title>Table Description</Offcanvas.Title>
        </Offcanvas.Header>
        <Offcanvas.Body>
        <Container>
        {/* <Row>
          <Col lg={{span:3,offset:9}}><Nav.Link to="/FormControllers"><Tablespage/></Nav.Link></Col>
        </Row> */}
        <br/>
    <Row>
    <div className="col-md-12 column">
            <table className="table table-bordered table-hover" id="tab_logic">
              <thead>
                <tr>
                  <th className="text-center">S.no </th>
                  {columnsArray.map((column, index) => (
                    <th className="text-center" key={index}> Column1</th>
                  ))}
                  {columnsArray.map((column, index) => (
                    <th className="text-center" key={index+1}>Column2</th>
                  ))}
                    {columnsArray.map((column, index) => (
                    <th className="text-center" key={index+2}>Column3</th>
                  ))}
                  {columnsArray.map((column, index) => (
                    <th className="text-center" key={index+2}>Column4</th>
                  ))}
                  <th colSpan="4"><button className="btn btn-outline-success bi bi-plus-circle" onClick={handleAddRow} >Add</button>
                    </th>
                </tr>
              </thead>
              <tbody>
               
                {rows.map((item, idx) => (
                  <tr key={idx}>
                    <td>{idx + 1}</td>
                    {columnsArray.map((column, index) => (
                      <td key={index}>
                      <Form.Control type="Text" placeholder="" />
                      </td>
                    ))}
                    
                     {columnsArray.map((column, index) => (
                    <td key={index}>
                    <Form.Control type="Text" placeholder="" />
                     </td>
                     ))}
                       {columnsArray.map((column, index) => (
                    <td key={index}>
                    <Form.Control type="Text" placeholder="" />
                    </td>
                     ))}
                    {columnsArray.map((column, index) => (
                    <td key={index}>
                    <Form.Control type="Text" placeholder="" />
                    </td>
                     ))}
                     <td>
                      <Button
                      variant="danger" className="bi bi-trash3" onClick={() => handleRemoveSpecificRow(idx)}></Button>
                    </td>
                    <td><button className='btn btn-outline-info bi bi-pen-fill'></button></td>
                  </tr>
                ))}
                </tbody>
            </table>
           <Row>
             <Col  className="d-flex justify-content-end">
             <Button variant='success' onClick={handleClick}>save</Button>
              <Snackbar
                open={open}
                autoHideDuration={6000}
                onClose={handleClose}
                message="Note archived"
                action={action}
              /></Col>
            </Row>
          </div>
        
        
      
    </Row>
    
   </Container>
        </Offcanvas.Body>
      </Offcanvas>
    </>
  );
}

function CreateTable() {
  return (
    <div>
        {[ 'end',].map((placement, idx) => (
        <OffCanvasExample key={idx} placement={placement} name={placement} />
      ))}
    </div>
  )
}

export default CreateTable