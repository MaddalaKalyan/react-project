import React from 'react'

const APIBody = () => {
  return (
    <div>APIBody</div>
  )
}

export default APIBody