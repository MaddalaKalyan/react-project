import {React ,useState} from 'react';
import { Container, Row ,Button,Offcanvas,Form,Col, Card,Tab,Tabs, Nav, Table} from 'react-bootstrap';
import { Tbody, Thead, Tr,Td,Th } from 'react-super-responsive-table';
import FormControllers from './FormControllers/FormControllers';






const FormControllerOffCanvas = () => {
    function OffCanvasExample({ name, ...props }) {
        const [show, setShow] = useState(false);
       const handleClose = () => setShow(false);
        const handleShow = () => setShow(true);

      


        const [rows, setRows] = useState([{}]);
        const columnsArray = [''] ; // pass columns here dynamically
        const columnsArray1 = [''];
      
        
        const handleAddRow = () => {
          const item = {};
          setRows([...rows, item]);
        };
      
        const postResults = () => {
          console.log(rows); // there you go, do as you please
        };
        const handleRemoveSpecificRow = (idx) => {
          const tempRows = [...rows]; // to avoid  direct state mutation
          tempRows.splice(idx, 1);
          setRows(tempRows);
        };
      
        const updateState = (e) => {
          let prope = e.target.attributes.column.value; // the custom column attribute
          let index = e.target.attributes.index.value; // index of state array -rows
          let fieldValue = e.target.value; // value
      
          const tempRows = [...rows]; // avoid direct state mutation
          const tempObj = rows[index+1]; // copy state object at index to a temporary object
          tempObj[prope] = fieldValue; // modify temporary object
      
          // return object to rows` clone
          tempRows[index] = tempObj;
          setRows(tempRows); // update state
        };
        
      
        return (
          <>
            <Button variant="primary"  onClick={handleShow}>
          CREATETABLE123<span className='bi bi-plus-circle '></span>
            </Button>  
            <Offcanvas show={show} onHide={handleClose} {...props} style={{"width":"700px"}}>
              <Offcanvas.Header closeButton>
                <Offcanvas.Title>
             TABLE DESCRIPTION
                </Offcanvas.Title>
              </Offcanvas.Header>
                <Offcanvas.Body>
               <Nav.Link><FormControllers/></Nav.Link>

             

              </Offcanvas.Body>
            
            </Offcanvas>
          </>
        );
      }
      
  
}

export default FormControllerOffCanvas