import {React ,useState} from 'react';
import { Container, Row ,Button,Offcanvas,Form,Col, Card,Tab,Tabs, Table, Nav} from 'react-bootstrap';
import { Thead,Tbody,Tr,Td,Th } from 'react-super-responsive-table';
import FarmFunction from '../../FarmFunction';
import Send123 from './APIFolder/Send123';
import Receive from './Receive';




const DecisionOffCanvas = () => {
    const [rows, setRows] = useState([{}]);
    const columnsArray = [''] ; // pass columns here dynamically
    const columnsArray1 = [''];
  
    
    const handleAddRow = () => {
      const item = {};
      setRows([...rows, item]);
    };
  
    const postResults = () => {
      console.log(rows); // there you go, do as you please
    };
    const handleRemoveSpecificRow = (idx) => {
      const tempRows = [...rows]; // to avoid  direct state mutation
      tempRows.splice(idx, 1);
      setRows(tempRows);
    };
  
    const updateState = (e) => {
      let prope = e.target.attributes.column.value; // the custom column attribute
      let index = e.target.attributes.index.value; // index of state array -rows
      let fieldValue = e.target.value; // value
  
      const tempRows = [...rows]; // avoid direct state mutation
      const tempObj = rows[index+1]; // copy state object at index to a temporary object
      tempObj[prope] = fieldValue; // modify temporary object
  
      // return object to rows` clone
      tempRows[index] = tempObj;
      setRows(tempRows); // update state
    };
  
    function OffCanvasExample({ name, ...props }) {
        const [show, setShow] = useState(false);
      
        const handleClose = () => setShow(false);
        const handleShow = () => setShow(true);




        return (
          <>
            <Button variant="primary" className='bi bi-pen '  onClick={handleShow}>
          
            </Button>  
            <Offcanvas show={show} onHide={handleClose} {...props} style={{"width":"700PX"}}>
              <Offcanvas.Header closeButton>
                <Offcanvas.Title>
                Decision Page 
                </Offcanvas.Title>
              </Offcanvas.Header>
              <Offcanvas.Body>
              <Card>


              <Container>
    <Row>
    <Form>
           <Row className='d-flex'>
                <Col><Form.Label>Rule Name</Form.Label></Col>
                 <Col><Form.Control type="text" placeholder="Enter Your Rule Name" /></Col>
           </Row>
           <br/>
           <Row className='d-flex'>
                <Col><Form.Label>Rule Description</Form.Label></Col>
                 <Col><Form.Control type="text" placeholder="Enter Your Rule Description" /></Col>
           </Row>
           
        </Form>
        <div className="row clearfix">
          <div className="col-md-12 column">
            <Table className="table table-bordered table-hover" id="tab_logic">
              <Thead>
                <Tr>
                  <Th className="text-center">S.no </Th>
                  {columnsArray.map((column, index) => (
                    <Th className="text-center" key={index}>
                      {column}
                      Table Name
                    </Th>
                  ))}
                  {columnsArray.map((column, index) => (
                    <Th className="text-center" key={index+1}>
                      {column}Column Name
                    </Th>
                  ))}
                    {columnsArray.map((column, index) => (
                    <Th className="text-center" key={index+2}>
                      {column}Operators
                    </Th>
                  ))}
                  <Th />
                </Tr>
              </Thead>
              <Tbody>
               
                {rows.map((item, idx) => (
                  <Tr key={idx}>
                    <Td>{idx + 1}</Td>
                    {columnsArray.map((column, index) => (
                      <Td key={index}>
                        <Form.Select    column={column}
                          value={rows[idx][column]}
                          index={idx}
                          className="form-control"
                          onChange={(e) => updateState(e)}>
                            <option>TableNames</option>
                            <option>TableOne</option>
                            <option>TableTwo</option>
                            <option>TableThree</option>
                    </Form.Select>
                    
                      </Td>
                       
                      
                    ))}
                    
                     {columnsArray.map((column, index) => (
                    <Td key={index}>
                       <Form.Select     column={column}
                         value={rows[idx][column]}
                         index={idx+2}
                         className="form-control"
                         onChange={(e) => updateState(e)}>
                        <option>ColoumnNames</option>
                        <option>ColoumnOne</option>
                        <option>ColoumnTwo</option>
                        <option>ColoumnThree</option>
                   </Form.Select>
                   
                     </Td>
                     ))}
                       {columnsArray.map((column, index) => (
                    <Td key={index}>
                       <Form.Select     column={column}
                         value={rows[idx][column]}
                         index={idx+3}
                         className="form-control"
                         onChange={(e) => updateState(e)}>
                        <option>Operators</option>
                        <option>OperatorsOne</option>
                        <option>OperatorsTwo</option>
                        <option>OperatorsThree</option>
                   </Form.Select>
                    </Td>
                     ))}
                     {columnsArray.map((column, index1) => (
                    <Td key={index1}>
                        <input
                            type="text"
                            placeholder="value"
                          />
                     </Td>
                     ))}
                     <Td>
                      <Button
                      variant="danger" className="bi bi-trash3"
                        onClick={() => handleRemoveSpecificRow(idx)}
                      ></Button>
                      <Button variant="success" className="bi bi-plus-circle" onClick={handleAddRow} ></Button>
                    </Td>
                    
                   {columnsArray.map((column, index) => (
                    <Td key={index}>
                        <Form.Select column={column}
                         value={rows[idx][column]}
                         index={idx+3}
                         className="form-control"
                         onChange={(e) => updateState(e)}>
                            <option value="Select">Select</option>
                            <option value="And">And</option>
                            <option value="Or">Or</option>
                            </Form.Select>
                        
                    </Td>
                   ))}
                  </Tr>
                ))}
                </Tbody>
            </Table>
           
            <button
              onClick={postResults}
              className="btn btn-success float-right"
            >
              Save Results
            </button>
          </div>
        </div>
      
        
        <Row> 
        <Tabs  defaultActiveKey="profile"
                                id="justify-tab-example"
                                className="mb-3"
                                justify>
                            <Tab eventKey="Send123" title="Send"><Send123/></Tab>
                            <Tab eventKey="Receive" title="receive"><Receive/></Tab>
                          </Tabs>

        




    
    
          </Row>
          <Button variant='success'>Save</Button>
    </Row>
    <Row>
        <Nav.Link><FarmFunction/></Nav.Link>
    </Row>
</Container>

             </Card>

              </Offcanvas.Body>
            </Offcanvas>
          </>
        );
      }
      
  return (
    <Container>
        {['end'].map((placement, idx) => (
        <OffCanvasExample key={idx} placement={placement} name={placement} />
      ))}
   
    </Container>
  )
}

export default DecisionOffCanvas