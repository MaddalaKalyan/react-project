import React from 'react'
import { Container } from 'react-bootstrap'

const NewFormControls = () => {
  return (
    <Container>
        <Row>
            
        </Row>
    </Container>
  )
}

export default NewFormControls