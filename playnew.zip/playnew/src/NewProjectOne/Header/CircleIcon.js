import {React,useState} from 'react'
import { Container,Button,Offcanvas, Row} from 'react-bootstrap';
import { Link } from 'react-router-dom';
import CallOne from './CallOne';
import './Circle.css'
import CompanyOne from './CompanyOne';
import ContactsOne from './ContactsOne';
import DealsOne from './DealsOne';
import EventOne from './EventOne';
import ProductOne from './ProductOne';
import TaskOne from './TaskOne';
const CircleIcon = () => {
    function OffCanvasExample({ name, ...props }) {
        const [show, setShow] = useState(false);
      
        const handleClose = () => setShow(false);
        const handleShow = () => setShow(true);
      
        return (
          <>
            <Button variant="#eff3f7" onClick={handleShow} className="bi bi-plus-circle Circles ">
         
            </Button>
            <Offcanvas show={show} onHide={handleClose} {...props}>
              <Offcanvas.Header closeButton>
                <Offcanvas.Title>Create New Record</Offcanvas.Title>
              </Offcanvas.Header>
              <Offcanvas.Body>
                <Row className='RowOne'>
                  <Link to="DealsOne"><DealsOne/></Link>
                </Row>
                <Row className='RowOne'>
                  <Link to="ContactsOne"><ContactsOne/></Link>
                </Row>
                <Row className='RowOne'>
                  <Link to="CompanyOne"><CompanyOne/></Link>
                </Row>
                <Row className='RowOne'>
                  <Link to="ProductOne"><ProductOne/></Link>
                </Row>
                <Row className='RowOne'>
                  <Link to="TaskOne"><TaskOne/></Link>
                </Row>
                <Row className='RowOne'>
                  <Link to="EventOne"><EventOne/></Link>
                </Row>
                <Row className='RowOne'>
                  <Link to="CallOne"><CallOne/></Link>
                </Row>
              </Offcanvas.Body>
            </Offcanvas>
          </>
        );
      }
      

  return (
   <Container>
    {[ 'end'].map((placement, idx) => (
        <OffCanvasExample key={idx} placement={placement} name={placement} />
      ))}
   </Container>
  )
}

export default CircleIcon
