import {React, useState} from 'react'
import { Container,Button,Offcanvas, Row, Col,Dropdown,DropdownButton,Card} from 'react-bootstrap';
import { Link } from 'react-router-dom';
import './DealsOne.css'

const ProductOne = () => {
    function OffCanvasExample({ name, ...props }) {
        const [show, setShow] = useState(false);
      
        const handleClose = () => setShow(false);
        const handleShow = () => setShow(true);
      
        return (
          <>
            <Button variant="#eff3f7"  onClick={handleShow}>
            <Row className='d-flex justify-content-start'>
             <Col className='d-flex justify-content-start'>  <span className="bi bi-journal-bookmark">Products</span></Col>
            
             </Row>
            </Button>
            <Offcanvas show={show} onHide={handleClose} {...props}>
              <Offcanvas.Header closeButton>
                <Offcanvas.Title>Products</Offcanvas.Title>
              </Offcanvas.Header>
              <Offcanvas.Body>
              <Row>
                <Col md="5" lg="5"><h6>Products Information</h6></Col>
                <Col>Owner
                </Col>
                <Col>
                <DropdownButton id="dropdown-basic-button" title="UserDetails" variant="#eff3f7" className='DealsOne'>
      <Dropdown.Item href="#/action-1">No User Found</Dropdown.Item>
    </DropdownButton></Col>
              </Row>
              <Row>
              <Col>
           <Card className='FiColCard1'>
          <Card.Header>Products </Card.Header>
          <Card.Body>
            <Card.Title>Products Information</Card.Title>
            <Card className='FiCard1'>
           <Row className='d-flex FiCardRow1'><Col className="FiCard4" style={{"margin-top":"10px","marginLeft":"10px"}}><p>Deal Name</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"17px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard2'>
           <Row className='d-flex FiCardRow2'><Col   className="FiCard4" style={{"margin-top":"10px","marginLeft":"10px"}}><p>CompanyName</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"35px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard1'>
           <Row className='d-flex FiCardRow1'><Col  className="FiCard4" style={{"margin-top":"10px","marginLeft":"10px" }}><p>Contact Name</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"17px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard2'>
           <Row className='d-flex FiCardRow2'><Col   className="FiCard4"style={{"margin-top":"10px","marginLeft":"10px"}}><p>SecondaryContact</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"35px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard1'>
           <Row className='d-flex FiCardRow1'><Col  className="FiCard4" style={{"margin-top":"10px","marginLeft":"10px" }}><p>Pipelines&Stages</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"17px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard2'>
           <Row className='d-flex FiCardRow2'><Col   className="FiCard4"style={{"margin-top":"10px","marginLeft":"10px"}}><p>Amount</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"35px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard1'>
           <Row className='d-flex FiCardRow1'><Col  className="FiCard4" style={{"margin-top":"10px","marginLeft":"10px" }}><p>Closing Date</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"17px"}}></span></Col></Row>
            </Card>
            <Card className='FiCard2'>
           <Row className='d-flex FiCardRow2'><Col   className="FiCard4"style={{"margin-top":"10px","marginLeft":"10px"}}><p>Description</p></Col>
           <Col ><span className='bi bi-pencil-fill d-flex justify-content-end'
            style={{"margin-top":"15px","marginRight":"35px"}}></span></Col></Row>
            </Card>

          </Card.Body>
         
        
            <Card.Footer className='CardFooter'>
              <Row className='d-flex CardFooterCard1' >
                <Col xs="2" lg="6" className='CardFooterCol1'>
               
                <Card.Link href="#"> <span className='bi bi-plus '>CustomField
                </span></Card.Link>
          
                </Col>
                <Col  xs="2" lg="6" className='CardFooterCol2'>  <p> Use Custom Fields :</p> </Col>
              </Row>
              </Card.Footer>
           
          </Card>
           </Col>
           
              </Row>
              <Row>
                <Link>
                <span className='bi bi-plus'>Products</span></Link>
              </Row>
              </Offcanvas.Body>
            
                <Row>
                   <Col>
                   <Link>FieldSettings</Link></Col>
                   <Col>
                   <Button variant="secondary" onClick={handleClose}>Close</Button>
                    <Button variant="success" onClick={handleClose}> Save</Button>
                   </Col>
                </Row>
              
            </Offcanvas>
          </>
        );
      }
      
  return (
  <Container>
   <Row>
    {[ 'end'].map((placement, idx) => (
        <OffCanvasExample key={idx} placement={placement} name={placement} />
      ))}
</Row>
  </Container>
  )
}

export default ProductOne
