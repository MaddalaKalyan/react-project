import {React,useState} from 'react'
import { Container,Row,Col, Offcanvas,Button,} from 'react-bootstrap';
import './Account.css'
import { Link } from 'react-router-dom';

const Account = () => {
    function OffCanvasExample({ name, ...props }) {
        const [show, setShow] = useState(false);
      
        const handleClose = () => setShow(false);
        const handleShow = () => setShow(true);
      
        return (
          <>
            <Button variant="#eff3f7" className='bi bi-person Notification '  onClick={handleShow}>
          
            </Button>  
            <Offcanvas show={show} onHide={handleClose} {...props}>
              <Offcanvas.Header closeButton>
              
                <Row className='d-flex '>
                    <Col sm={2} lg={2} className='AccountCol d-flex' >
                        <span className='bi bi-person icon' ></span>
                    </Col>
                    <Col sm={7} lg={7}>
                     
                    </Col>
                    
                </Row>
                <Row>
                    <Col> 
                    <h5>User Name : _ _ _  </h5>
                    <h5>Id No:_ _ _ _</h5>
                    <h6>KALYAN CRM</h6> 

                    </Col>
                 
                </Row>
                <Row>
                <Col>
                    <Link>SignOut</Link></Col>
                </Row>
              </Offcanvas.Header>
              <Offcanvas.Body>
                <Row>
                    <Col>My Organization
                    </Col>
                    <Col>
                    
                    <h5>User Name:Kalyan </h5>
                    <h5>Id No:1234</h5>
                    <h6>KALYAN CRM</h6> </Col>
                
                </Row>
                
                <Row className='d-flex'>
                    <Col>
                     <p> Subcription</p>

                        
                    </Col>
                    <Row><Col><p>Free</p></Col><Col><Link><h4>Upgrade</h4></Link></Col>
                    </Row>
                </Row>
                <Row>
                    <h4>Upgrade to Kalyan CRM</h4>
                </Row>
                <Row>
                    <h5>Need Help ?</h5>
                    <Col>
                       <span className='bi bi-headset'>Talk To Us</span>
                    
                    </Col>
                    <Col> <span className='bi bi-card-text'>Help Guide</span></Col>
                </Row>
                <Row>
                    <Col>
                    <span className='bi bi-envelope'>Support@gmail.com</span></Col>
                    <Col><span className='bi bi-gift'>What's New</span></Col>
                </Row>
               
               <Row>
                <Col>
                <span className='bi bi-laptop'>Join Webifnars</span></Col>
               </Row>

              </Offcanvas.Body>
            </Offcanvas>
          </>
        );
      }
      
  return (
    <Container>
        {['end'].map((placement, idx) => (
        <OffCanvasExample key={idx} placement={placement} name={placement} />
      ))}
   
    </Container>
  )
}


export default Account
