import React from 'react'

const TemplateEvents = () => {
  return (
    <div>TemplateEvents</div>
  )
}

export default TemplateEvents