import React from 'react'
import {Container,Row,InputGroup} from 'react-bootstrap'
import { Outlet } from 'react-router-dom'
import {Table, Thead,Th,Tr, } from 'react-super-responsive-table'
const TemplateSharedWithMe = () => {
  return (
    <Container>
    <Row>
     <Table striped bordered>
             <Thead>
              <Tr>
                <Th> <InputGroup.Checkbox aria-label="Checkbox for following text input" /></Th>
                <Th> Template Name</Th>
                <Th>Subject</Th>
                <Th>All Modules<span className='bi bi-filter'></span></Th>
                <Th>Modified By</Th>
               
               </Tr>
             </Thead>
             
            </Table>
    </Row>
    <Row>
      <Outlet/>
    </Row>
  </Container>
  )
}

export default TemplateSharedWithMe