import React from 'react'
import {Container,Row,Col,Tabs,Tab} from 'react-bootstrap'
import { Outlet ,Link} from 'react-router-dom'
import Deliverability from './Deliverability'
import './EMail.css'
import EmailInsights from './EmailInsights'
import EMailsharing from './EMailsharing'
import OrganizationEmail from './OrganizationEmail'
import Template from './Template'




const EMail = () => {
  return (
   <Container>
    <Row className='EmRow1 d-flex'>

        <Col sm="6" lg="8" md="8" className='EmCol1'>
           <Row className='d-flex EmRow2'>
          <Col   className='EmCol2'><Link to="Email1">Email</Link></Col>
                <Col   className='EmCol2'><Link to="Template">Template</Link></Col>
                <Col   className='EmCol2'><Link to="EMailSharing">EmailSharing</Link></Col>
                <Col   className='EmCol2'><Link to="EmailInsights">EmailInsights</Link></Col>
                <Col   className='EmCol2'><Link to="OrganizationEmail">OrganizationEmail</Link></Col>
                <Col   className='EmCol2'><Link to="Deliverability">Deliverability</Link></Col> 
            </Row> 
        </Col>
        {/* <Col sm="6" lg={{span:2 , offset:2}} className='EmCol3'>
            
          <Link className='bi bi-question-circle'></Link>
          <Link className='bi bi-play-circle'></Link>
        </Col> */}
    </Row>
    <Row><Outlet/></Row>
   </Container>
  )
}

export default EMail