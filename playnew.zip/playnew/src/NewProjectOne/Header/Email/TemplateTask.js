import React from 'react'

const TemplateTask = () => {
  return (
    <div>TemplateTask</div>
  )
}

export default TemplateTask