import React from 'react'

const TemplateCompanies = () => {
  return (
    <div>TemplateCompanies</div>
  )
}

export default TemplateCompanies