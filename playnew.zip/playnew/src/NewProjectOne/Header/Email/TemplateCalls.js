import React from 'react'

const TemplateCalls = () => {
  return (
    <div>TemplateCalls</div>
  )
}

export default TemplateCalls