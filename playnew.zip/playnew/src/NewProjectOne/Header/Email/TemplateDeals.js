import React from 'react'

const TemplateDeals = () => {
  return (
    <div>TemplateDeals</div>
  )
}

export default TemplateDeals