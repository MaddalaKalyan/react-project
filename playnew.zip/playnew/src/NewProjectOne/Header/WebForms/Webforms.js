import React from 'react'
import { Container,Row,Col,Button, Table,  } from 'react-bootstrap'
import './WebForms.css'
import {Thead,Th,Tr } from 'react-super-responsive-table'
import { Outlet } from 'react-router-dom'


const Webforms = () => {
  return (
   <Container className='WFContainer'>
      <Row className='WFRow1'>
        <Col xs="4" lg="8"className="WFCol1" ><h6>Web Forms</h6>
        <p>Web forms let you build customizable contact forms that you can embed on your website.
           When visitors complete this form, the information they submit automatically gets added into Bigin as a contact.</p>
        </Col>
        <Col  xs="2"lg="2" className='WFCol2'>
            <Button variant='success' type='submit' className='WFBu3' ><span className='bi bi-plus'>Web Forms</span></Button>
        </Col>
        <Col xs="2" lg="1" className='WFCol3 d-flex justify-content-end'><span className='bi bi-question WFIcon2'></span></Col>

      </Row>
        <Row  className='WFRow3 d-flex'>
          <Col lg="2">Module : Contacts</Col></Row>
          <Row className='WFRow'>
          <Col  xs="6" lg="12" className='WFCol4'>
          <Table striped bordered hover>
           <Thead>
            <Tr>
              <Th>FullName</Th>
              <Th>Created By</Th>
              <Th>Status</Th>
              <Th>Embed Options</Th>
            </Tr>
           </Thead>
          </Table>
          </Col>
        </Row>

    <Row>

      
        <Outlet/>
    </Row>
   </Container>
  )
}

export default Webforms