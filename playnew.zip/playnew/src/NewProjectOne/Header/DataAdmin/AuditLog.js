import React from 'react'
import { Container,Row,Col,Button } from 'react-bootstrap'
import { Outlet } from 'react-router-dom'

const AuditLog = () => {
  return (
   <Container>
    <Row>
        <Col xs="2" lg="6">
            <h5>Audit Log</h5>
            <p>The Audit Log lists actions performed by users in this Bigin account in chronological order.</p>
        </Col>
        <Col xs="4" lg="6" className='d-flex justify-content-end'>
            <Button variant="lite" style={{'borderRadius':'100px 100px 100px 100px' ,"width":"150px" ,"height":"40px" ,"color":"green", "border-color":'green'}}>create</Button></Col>
    </Row>
    <Outlet/>
   </Container>
  )
}

export default AuditLog