import React from "react";
import "react-circular-progressbar/dist/styles.css";
import CircularProgressbar from "react-circular-progressbar";
import { Spring, config } from "react-spring";

import "./Circular.css";

function App() {
  return (
    <div
      style={{
        width: "200px",
        height: "200px"
      }}
    >
      <Spring
        from={{ percentage: 0 }}
        to={{ percentage: 80 }}
        config={config.molasses}
      >
        {({ percentage }) => {
          const roundedPercentage = Math.round(percentage);
          return (
            <CircularProgressbar
              percentage={roundedPercentage}
              text={`${roundedPercentage}%`}
              styles={{
                path: {
                  transform: "rotate(180deg)",
                  transformOrigin: "center center",
                  strokeLinecap: "butt",
                  stroke: percentage >= 70 ? "#bd2327" : "blue"
                },
                trail: {
                  strokeWidth: 0
                },
                text: {
                  fontSize: 22,
                  fontWeight: 800,
                  animation: "fadein 2s",
                  fill: percentage >= 70 ? "#bd2327" : "blue"
                }
              }}
            />
          );
        }}
      </Spring>
    </div>
  );
}

export  default App
