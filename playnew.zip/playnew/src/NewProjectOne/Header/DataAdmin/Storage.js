import React from 'react'
import { Card, Container,Col,Row } from 'react-bootstrap'
import { Outlet,Link } from 'react-router-dom'


const Storage = () => {
  return (
    <Container>
        <Row>
        <h5>Organization Storage</h5>

          
               <Card style={{"border-color":"none","width":"100%"}}>
                <Row>
                  <Col xs='2' lg="2">
                  <h1>005</h1>
                  </Col>
                  <Col>
                  <Row>
                    <Col>
                    <h6>Allowed Storage</h6>
                    <span className='bi bi-dot'></span>
                    </Col>
                    </Row>
                    <Row>
                    <Col>
                      <h6>Used Storage</h6>
                      <span className='bi bi-dot'></span>
                      </Col>
                      </Row></Col>
                </Row>
                  
                </Card>
        
        </Row>
        <Row>
          <h5>Storage Consumption by Users</h5>
        </Row>
        <Outlet/>
    </Container>
  )
}

export default Storage