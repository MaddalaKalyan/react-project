import React from 'react'
import { Container,Row,Col } from 'react-bootstrap'
import { Outlet,Link } from 'react-router-dom'
import './DataAdmin.css'


const DataAdmin = () => {
  return (
    <Container  className="DAContainer">
    <Row className='d-flex justify-content-between DAR1'>
       <Col  className='d-flex DACol ' sm="4" lg="8">
        <Link to="Import">Import</Link>
       <Link to="ExportData">Export Data</Link>
       <Link to="DataBackup">Data Back up</Link>
      
       <Link to="RecycleBin">Recycle Bin</Link>
       <Link to="AuditLog">Audit Log</Link>
       <Link to="Storage">Storage</Link>
       </Col>
       <Col sm="4" lg="2"  className='d-flex UacC2 '>
        
          <span className='bi bi-question-circle UacCL'></span>
        
       </Col>
       
         </Row>
         <Row>
            
         <Col>   <Outlet/> </Col>
         </Row>

   </Container>
  )
}

export default DataAdmin
