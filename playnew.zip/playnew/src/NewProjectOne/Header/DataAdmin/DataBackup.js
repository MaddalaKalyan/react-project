import React from 'react'
import { Container,Col,Row,Button } from 'react-bootstrap'
import { Outlet } from 'react-router-dom'

const DataBackup = () => {
  return (
    <Container>
        <Row>

        <Col xs="6" lg="6">
            <h4>Data Backup</h4>
            <p>Create a complete back up of your Bigin data for $5 per backup.</p>
        </Col>
        <Col xs="6" lg="6" className='d-flex justify-content-end'>
            <Button variant="success" style={{'borderRadius':'100px 100px 100px 100px' , "width":"150px","height":'30px'}}><p>Initiate Backup</p></Button></Col>
    
        </Row>






        <Row> <Outlet/></Row>
       
    </Container>
  )
}

export default DataBackup