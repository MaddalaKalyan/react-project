import React from 'react'
import { Container,Col,Row, Card, } from 'react-bootstrap'
import { Outlet } from 'react-router-dom'

const RecycleBin = () => {
  return (
  <Container>
    <Row>
        <Col xs="2" lg="8">
            <h5>Recycle Bin</h5>
            <p>Deleted records you can access appear in the Recycle Bin.</p>
        </Col>
        <Col xs="2" lg="10">
            <Card style={{"padding":"10px" , "lineHeight":"20px" , "backgroundColor":"#f5f8fa"}}>
                <ul>
                    <li>Once a record is deleted, it will be stored in the Recycle Bin for 60 days. 
                        After that, they will be permanently deleted.</li>
                    <li>Only users with an Administrator profile can delete records in the Recycle Bin</li>
                    <li>Users who don't have an Administrator profile can restore records from the Recycle Bin.</li>
                </ul>
            </Card>
        </Col>
    </Row>
    <Outlet/>
  </Container>
  )
}

export default RecycleBin