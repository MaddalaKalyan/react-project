import React from 'react'
import { Container, Row,Col,Card } from 'react-bootstrap'
import { Link, Outlet } from 'react-router-dom'

const Import = () => {
  return (
  <Container>
           <Row> 
               <Col xs="6" lg="12">
                <Col xs="1" lg="2">
                <h6>Migrate from other tools</h6>
                <Card className='d-flex justify-content-between'>
                   <Link to="#">
                   <span className='bi bi-Link ' style={{"fontSize":'30px',"textAlign":"center"}}></span>
                   <h5>Zoho CRM</h5>
                   </Link>
                </Card>
                </Col>
               </Col>
            </Row> 
          <Row>    <Outlet/></Row>
  </Container>
  )
}

export default Import