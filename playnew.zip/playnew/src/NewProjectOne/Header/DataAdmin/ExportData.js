import React from 'react'
import { Container,Row,Col,Form,Card, Button } from 'react-bootstrap'
import { Outlet } from 'react-router-dom'

const ExportData = () => {
  return (
    <Container>
        <Row>
            <h5>Export Data</h5>
          
        </Row>
        <Row>
            <p>You can export records from a specific module in your Bigin account as a CSV file.</p>
        </Row>
        <Row><Col  xs="1"lg="2">Select a Module :</Col>
            <Col xs="2"lg="5">
            <Form.Select aria-label="Default select example">
             
                <option>akm</option>
                <option value="1"><Row style={{"border":"2px solid red" , "backgroundColor":'red'}}><Col><Card style={{"border":"2px solid red" , "backgroundColor":'red'}}>  <Form.Control className="me-auto" placeholder="Add your item here..." /></Card></Col></Row></option>
                <option value="2">One</option>
                <option value="3">Two</option>
                <option value="4">Three</option>
    </Form.Select>
            </Col>
            </Row>
            <br/>
            <Row className='d-flex'>
                <Col xs="6" lg="6" className='d-flex justify-content-end'><Button variant="success" style={{'borderRadius':'100px 100px 100px 100px'}}>create</Button></Col>
                
            </Row>
       <Row> <Outlet/></Row>
    </Container>
  )
}

export default ExportData