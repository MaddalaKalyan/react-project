import React from 'react'
import { Container, Table,Row, Form, Button, Col, Tab } from 'react-bootstrap'
import { Outlet } from 'react-router-dom'
import { Tbody, Td, Th, Thead,Tr } from 'react-super-responsive-table'

const APIONe = () => {
  return (
    <Container>
        <Row>
          <Table striped bordered hover>
            <Thead>
                <Th>
                    <Tr>
                        <Td>
                            <Row>
                                <Col>
                                <select     
                                 className="form-select-sm select"
                                 aria-label="Default select example">
                                         <option defaultValue hidden>GET</option>
                                         <option value="Action">POST</option>
                                         <option value="UpdateTable">PUT</option>
                                         <option value="SendEmail">PATCH</option>
                                         <option value="SendSms">DELETE</option>
                                         <option defaultValue hidden>LINK</option>
                                         <option value="Action">UNLINK</option>
                                         <option value="UpdateTable">HEAD</option>
                                         <option value="SendEmail">PURGE</option>
                                         <option value="SendSms">LOCK</option>
                                         <option value="SendSms">UNLOCK</option>
                                </select></Col>
                                <Col>
                                <Form.Control type='text'>

                                </Form.Control>
                                </Col>
                                <Col>
                                <Dropdown as={ButtonGroup}>
                                    <Button variant="success">POST</Button>
                                    <Dropdown.Toggle split variant="success" id="dropdown-split-basic" />

                                    <Dropdown.Menu>
                                        <Dropdown.Item href="#/action-1">Send and Download </Dropdown.Item>
                                       
                                    </Dropdown.Menu>
                                    </Dropdown>
                                </Col>
                            </Row>
                        </Td>
                    </Tr>
                </Th>
            </Thead>
          </Table>
        </Row>
        <Outlet/>
    </Container>
  )
}

export default APIONe