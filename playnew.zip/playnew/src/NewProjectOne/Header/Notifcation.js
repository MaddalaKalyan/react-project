import {React ,useState} from 'react';
import { Container, Row ,Button,Offcanvas,Image} from 'react-bootstrap';


import './Notifcations.css';
import NoLogo from './NoLogo.jpg'




const Notifcation = () => {
    function OffCanvasExample({ name, ...props }) {
        const [show, setShow] = useState(false);
      
        const handleClose = () => setShow(false);
        const handleShow = () => setShow(true);
      
        return (
          <>
            <Button variant="#eff3f7" className='bi bi-bell Icon Notification '  onClick={handleShow}>
          
            </Button>  
            <Offcanvas show={show} onHide={handleClose} {...props}>
              <Offcanvas.Header closeButton>
                <Offcanvas.Title>Notifications</Offcanvas.Title>
              </Offcanvas.Header>
              <Offcanvas.Body>
                <Image src={NoLogo} alt="image" style={{"width":"300px","margin-top":"28px",'textAlign':'center'}}></Image>
                <h5 style={{"textAlign":"center"}}>Teamwork Works!</h5>
                <p  style={{"textAlign":"center"}}>Get notified whenever your team members<br/> mention you in a note or update any records that<br/> you own or follow.</p>

              </Offcanvas.Body>
            </Offcanvas>
          </>
        );
      }
      
  return (
    <Container>
        {['end'].map((placement, idx) => (
        <OffCanvasExample key={idx} placement={placement} name={placement} />
      ))}
   
    </Container>
  )
}

export default Notifcation