import React from "react";
import { Button, Card, Container,Form,Col,Row } from "react-bootstrap";
   const Actions=()=>{
    return(
             
        <Container>
            <Row>
                <Card>
                    <Card.Header>
                        <p>Actions</p>
                    </Card.Header>
                    <Card.Body>
                <Row>
                    <Col>
                    <Form.Select>
                    <option>Actions</option>
                    <option value="UpdateTable">Update Table</option>
                    <option value="SendEmail">Send Email</option>
                    <option value="SendSms">SendSms</option>
                    <option value="CallAPI">Call API</option>
                    <option value="SendWhat'sappMessage">Send What'sapp Message</option>

                    </Form.Select>
                    </Col>
                    <Col>
                    <Form.Select>
                        <option>TableNames</option>
                        <option>TableOne</option>
                        <option>TableTwo</option>
                        <option>TableThree</option>
                    </Form.Select>
                    </Col>
                    <Col>
                    <Form.Select>
                        <option>Cost</option>
                        <option>CostOne</option>
                        <option>CostTwo</option>
                        <option>CostThree</option>
                    </Form.Select>                    
                    </Col>
                    <Col>
                    <Button variant="secondary">=</Button>
                    </Col>
                    <Col>
                    <Form.Control
                            type="text"
                            placeholder="value"
                            id="inputPassword5"
                            aria-describedby="passwordHelpBlock"
                        />
                    </Col>
               
                </Row>
                <br/>
                <Row>
                    <Col lg="2">
                    <Form.Select>
                    <option>And</option>
                    <option>AndOne</option>
                    <option>AndTwo</option>
                    <option>AndThree</option>
                    </Form.Select>
                    </Col>
                </Row>
              </Card.Body>
                </Card>
            </Row>
        </Container>
    )
    
   }
   export default Actions