import React, { Component } from 'react';
import { Container,Row,Col,Card, Form,Button } from "react-bootstrap";
export default class EventTrigger2 extends Component {
    constructor(props){
    super(props);
    this.state ={
        message:''

    }
    this.handletypechange=this.handletypechange.bind(this)
}
handletypechange(event) {
    this.setState(
      { visibletype: event.target.value },
      console.log(this.state.visibletype)
    );
  }
  handlefaculty(event) {
    this.setState(
      { faculty: event.target.value },
      console.log(this.state.faculty)
    );
  }
  render() {
    return (
      
    <Container>
    <Row>
        <h4> EventTrigger Conditions</h4>
        <Card>
          <Card.Header><p>When</p></Card.Header>
          <Card.Body>
            <Row>
                <Col>
                <Form.Select 
                onChange={this.handletypechange}
                >
                <option value="TableName" >TableNames</option>
                <option>TableOne</option>
                <option>TableTwo</option>
                <option>TableThree</option>
                </Form.Select>
                </Col>
                <Col>
                <Form.Select 
                onChange={this.handletypechange}
                >
                    <option>ColoumnNames</option>
                    <option>ColoumnOne</option>
                    <option>ColoumnTwo</option>
                    <option>ColoumnThree</option>
                </Form.Select>
                </Col>
                <Col>
                <Form.Select 
                onChange={this.handletypechange}
                >
                    <option>Operators</option>
                    <option>OperatorsOne</option>
                    <option>OperatorsTwo</option>
                    <option>OperatorsThree</option>
                </Form.Select>                    
                </Col>
                <Col>
                <Form.Control
                        type="text"
                        placeholder="value"
                        id="inputPassword5"
                        aria-describedby="passwordHelpBlock"
                    />
                </Col>
                <Col>
                <Button variant="danger" className="bi bi-trash3"></Button>
                {this.state.visibletype==='TableName'&&(
                    <Button variant="success" className="bi bi-plus-circle"   onChange={this.handlefaculty}></Button>
                )
                }</Col>
            </Row>
            <br/>
            <Row>
                <Col lg="2">
                <Form.Select 
                onChange={this.handletypechange}
                >
                <option>And</option>
                <option>AndOne</option>
                <option>AndTwo</option>
                <option>AndThree</option>
                </Form.Select>
                </Col>
            </Row>
          </Card.Body>
        </Card>
    </Row>
</Container>
    )
  }
}
