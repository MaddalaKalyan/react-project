import React, { useState } from "react";
import { Button,Form } from "react-bootstrap";
const AddedRow = () => {
  const [rows, setRows] = useState([{}]);
  const columnsArray = [''] ; // pass columns here dynamically
  const columnsArray1 = [''];

  
  const handleAddRow = () => {
    const item = {};
    setRows([...rows, item]);
  };

  const postResults = () => {
    console.log(rows); // there you go, do as you please
  };
  const handleRemoveSpecificRow = (idx) => {
    const tempRows = [...rows]; // to avoid  direct state mutation
    tempRows.splice(idx, 1);
    setRows(tempRows);
  };

  const updateState = (e) => {
    let prope = e.target.attributes.column.value; // the custom column attribute
    let index = e.target.attributes.index.value; // index of state array -rows
    let fieldValue = e.target.value; // value

    const tempRows = [...rows]; // avoid direct state mutation
    const tempObj = rows[index+1]; // copy state object at index to a temporary object
    tempObj[prope] = fieldValue; // modify temporary object

    // return object to rows` clone
    tempRows[index] = tempObj;
    setRows(tempRows); // update state
  };

  return (
    <div>
      <div className="container">
        <div className="row clearfix">
          <div className="col-md-12 column">
            <table className="table table-bordered table-hover" id="tab_logic">
              <thead>
                <tr>
                  <th className="text-center">S.no </th>
                  {columnsArray.map((column, index) => (
                    <th className="text-center" key={index}>
                      {column}
                    </th>
                  ))}
                  {columnsArray.map((column, index) => (
                    <th className="text-center" key={index+1}>
                      {column}
                    </th>
                  ))}
                    {columnsArray.map((column, index) => (
                    <th className="text-center" key={index+2}>
                      {column}
                    </th>
                  ))}
                  <th />
                </tr>
              </thead>
              <tbody>
               
                {rows.map((item, idx) => (
                  <tr key={idx}>
                    <td>{idx + 1}</td>
                    {columnsArray.map((column, index) => (
                      <td key={index}>
                        <Form.Select    column={column}
                          value={rows[idx][column]}
                          index={idx}
                          className="form-control"
                          onChange={(e) => updateState(e)}>
                            <option>TableNames</option>
                            <option>TableOne</option>
                            <option>TableTwo</option>
                            <option>TableThree</option>
                    </Form.Select>
                    
                      </td>
                       
                      
                    ))}
                    
                     {columnsArray.map((column, index) => (
                    <td key={index}>
                       <Form.Select     column={column}
                         value={rows[idx][column]}
                         index={idx+2}
                         className="form-control"
                         onChange={(e) => updateState(e)}>
                        <option>ColoumnNames</option>
                        <option>ColoumnOne</option>
                        <option>ColoumnTwo</option>
                        <option>ColoumnThree</option>
                   </Form.Select>
                   
                     </td>
                     ))}
                       {columnsArray.map((column, index) => (
                    <td key={index}>
                       <Form.Select     column={column}
                         value={rows[idx][column]}
                         index={idx+3}
                         className="form-control"
                         onChange={(e) => updateState(e)}>
                        <option>Operators</option>
                        <option>OperatorsOne</option>
                        <option>OperatorsTwo</option>
                        <option>OperatorsThree</option>
                   </Form.Select>
                    </td>
                     ))}
                     {columnsArray.map((column, index1) => (
                    <td key={index1}>
                        <input
                            type="text"
                            placeholder="value"
                          />
                     </td>
                     ))}
                     <td>
                      <Button
                      variant="danger" className="bi bi-trash3"
                        onClick={() => handleRemoveSpecificRow(idx)}
                      ></Button>
                      <Button variant="success" className="bi bi-plus-circle" onClick={handleAddRow} ></Button>
                    </td>
                    
                   {columnsArray.map((column, index) => (
                    <td key={index}>
                        <Form.Select column={column}
                         value={rows[idx][column]}
                         index={idx+3}
                         className="form-control"
                         onChange={(e) => updateState(e)}>
                            <option value="Select">Select</option>
                            <option value="And">And</option>
                            <option value="Or">Or</option>
                            </Form.Select>
                        
                    </td>
                   ))}
                  </tr>
                ))}
                </tbody>
            </table>
           
            <button
              onClick={postResults}
              className="btn btn-success float-right"
            >
              Save Results
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AddedRow;
