import React from "react";

import { Card, Container, Row, Table,Form } from "react-bootstrap";
import { Link, Outlet} from "react-router-dom";
import { Th, Tr } from "react-super-responsive-table";



const Condition =() =>{
        
         
    return(
        <Container>
            <Row>
               <Card>
                 <Card.Header>
                    <p>Which Deals would you like to apply the workflow to?
                        Deals matching certain conditions 
                    All Deals</p>
                    <Form>
                        <Link to="Farm">
                    <Form.Check 
                      type="radio"
                      label="Yes"
                      name="Radio"
                      id="formHorizontalRadios1"
                      
                    />
                    </Link>
                    </Form>
                 </Card.Header>
               <Table>
                    <thead>
                        <Tr>
                            <Th>
                            <select 
                            className="form-select-sm select"
                            aria-label="Default select example"
                           
                            >
                                <option  defaultValue hidden>select type</option>
                                <option value="Amount">Amount</option>
                                <option value="Closingdate">ClosingDate</option>
                                <option value="CompanyName">CompanyName</option>
                                <option value="ContactName">ContactName</option>
                                <option value="CreatedBy">CreatedBy</option>
                                <option value="CreatedTime">CreatedTime</option>
                                <option value="DealName">DealName</option>
                                <option value="DealOwner">DealOwner</option>
                                <option value="Description">Description</option>
                                <option value="LastActivityTime">LastActivityTime</option>
                                <option value="ModifiedBy">ModifiedBy</option>
                                <option value="ModifiedTime">ModifiedTime</option>
                                <option value="PipeLine">PipeLine</option>
                                <option value="Stage">Stage</option>


                            </select>
                            </Th>
                            <Th>

                                <select
                                className="form-select-sm select"
                                aria-label="Default select example"
                             
                                >
                                    <option value="=">=</option>
                                    <option value="!=">!=</option>
                                    <option value="<"> lessthan </option>
                                    <option value="<=">LessthanEqualTo</option>
                                    <option value=">=">  greaterthan </option>
                                    <option value="Between">Between</option>
                                    <option value="NotBetween">NotBetween</option>
                                    <option value="IsEmpty">IsEmpty</option>
                                    <option value="IsNotEmpty">Is Not Empty</option>
                                    
                                </select>
                            </Th>
                            <Th>

                            </Th>
                            <Th>
                                <span className="bi bi-plus-circle-fill"></span>
                            </Th>
                            </Tr>
                    </thead>

                </Table>
               </Card>
            </Row>
            <Outlet/>
        </Container>
    )
}
export default Condition