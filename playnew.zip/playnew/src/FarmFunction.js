import React, { Component } from "react";
import { Card, Button, Badge, Modal, Container,Table, Row,Col, Form, ButtonGroup } from "react-bootstrap";
import axios from "axios";
import moment from "moment";
// import { RiDeleteBin6Line } from "react-icons/ri";
import { Link,} from "react-router-dom";
//import  '../NotificationBar/SideNotification.css';

class FarmFunction extends Component {
  constructor(props) {
    super(props);
    this.state = {
      message: "",
      posts: [],
      showModel: false,
      showConfirm: false,
      showDeleteConfirm: false,
      deletePost: "",
      editPost: { message: "", id: "" },
      visiblequestions: 10,
      visibletype: "",
      faculty:"",

 
      timenow:moment().format('H'),
     
    };
 

    this.handleChange = this.handleChange.bind(this);
    this.handleClick = this.handleClick.bind(this);
    this.loadmore = this.loadmore.bind(this);
    this.handletypechange = this.handletypechange.bind(this);
    this.handlefaculty = this.handlefaculty.bind(this);
    
  }

  handleChange(event) {
    this.setState({ message: event.target.value });
  }

  handleClick(event) {
    console.log(this.state.message);
    event.preventDefault();
    const message = { message: this.state.message ,faculty:this.state.faculty,privacytype:this.state.visibletype};

    axios.post("http://localhost:3000/Farm", message).then((res) => {
      console.log(res);
      console.log(res.data);
      this.handleCloseModal();
      this.getAllPosts();
    });

    this.setState({
      message: "",
    });
  }

  componentDidMount() {
    this.getAllPosts();
    this.timelimit();
   
  }

  getAllPosts = () => {
    axios
      .get("http://localhost:3000/Farm/home")
      .then((res) => this.setState({ posts: res.data.reverse() }));
  };

  deletePost = (id) => {
    axios
      .delete("http://localhost:3000/Farm/" + this.state.deletePost)
      .then((res) => {
        console.log(res);
        this.handleDeleteCloseModal();

        this.getAllPosts();
      });
  };

  editPost = (id, message) => {
    this.setState((currentState) => ({
      ...currentState,
      showModel: true,
      editPost: { message: message, id: id },
    }));
    console.log(this.state);
  };

  updatePost = () => {
    axios
      .patch("http://localhost:3000/Farm/" + this.state.editPost.id, {
        message: this.state.editPost.message,
      })
      .then((res) => {
        this.setState((currentState) => ({
          ...currentState,
          showModel: false,
        }));

        this.getAllPosts();
      });
  };

  onChangehandler = (e) => {
    e.persist();
    this.setState((currentState) => ({
      ...currentState,
      editPost: { ...currentState.editPost, message: e.target.value },
    }));
  };

  cancleEdit = () => {
    this.setState((currentState) => ({ ...currentState, showModel: false }));
    this.getAllPosts();
  };

  handleModal = () => {
    this.setState({ showConfirm: true });
  };

  handleCloseModal = () => {
    this.setState({ showConfirm: false });
  };

  handleDeleteModal = (id) => {
    this.setState(() => ({ showDeleteConfirm: true, deletePost: id }));
  };

  handleDeleteCloseModal = () => {
    this.setState({ showDeleteConfirm: false });
  };

  loadmore() {
    this.setState((old) => {
      return { visiblequestions: old.visiblequestions + 5 };
    });
  }

  handletypechange(event) {
    this.setState(
      { visibletype: event.target.value },
      console.log(this.state.visibletype)
    );
  }
  handlefaculty(event) {
    this.setState(
      { faculty: event.target.value },
      console.log(this.state.faculty)
    );
  }

  timelimit(id){
   if(this.state.timenow<2.30){
     console.log("yes");
   }else{
     console.log("no");
   }
    
    console.log(this.state.timenow);
    
  }
 
  

  render() {
    return (
    <Container style={{'overflow':'scroll','height':'450px'}}>
        <Row className="divstyle">
         <Card className="Farmstyle">
            <Card.Header as="h5">Action</Card.Header>
            <Card.Body>
                <Row>
            <Col>
              <select
                className="form-select-sm select"
                aria-label="Default select example"
                onChange={this.handletypechange}
              >
                <option defaultValue hidden>Select Type</option>
                <option value="Action">Action</option>
                <option value="UpdateTable">UpdateTable</option>
                <option value="SendEmail">SendEmail</option>
                <option value="SendSms">SendSms</option>
                <option value="CallAPI">CallAPI</option>
                <option value="SendWhat'sappMessage">SendWhat'sappMessage</option>
              </select>
              {this.state.visibletype === "UpdateTable" && (
                <select
                  className="form-select-sm select"
                  aria-label="Default select example"
                  onChange={this.handlefaculty}
                >
                  <option defaultValue hidden>Select Table Name</option>
                  <option value="TableOne">Table One</option>
                  <option value="TableTwo">TableTwo</option>
                  <option value="TableThree"> TableThree </option>
                
                </select>
                
              )}
               {this.state.visibletype === "UpdateTable" && (
                <select
                  className="form-select-sm select"
                  aria-label="Default select example"
                  onChange={this.handlefaculty}
                >
                  <option defaultValue hidden>ColoumnsNames</option>
                  <option value="ColumnsOne">ColumnsOne</option>
                  <option value="ColumnsTwo">ColumnsTwo</option>
                  <option value="ColumnsThree"> ColumnsThree </option>
                
                </select>
                
              )}
               {this.state.visibletype === "UpdateTable" && (
                <select
                  className="form-select-sm select"
                  aria-label="Default select example"
                  onChange={this.handlefaculty}
                >
                  <option defaultValue hidden>Operators</option>
                  <option value="=">=</option>
                  <option value="<">greaterthan</option>
                  <option value=">">   lessthan </option>
                
                </select>
             
              )}
                {this.state.visibletype==="UpdateTable"&&(
                     <Form.Control
                     style={{ width: "auto" }}
                     placeholder="Please write question here..."
                
                     onChange={this.handlefaculty}
                     ></Form.Control>
                )}
              {this.state.visibletype === "UpdateTable" && (
              <select
              className="form-select-sm select"
                  aria-label="Default select example"
                  onChange={this.handlefaculty}>
                <option value="And">And</option>
                <option value="Or">Or</option>
              </select>)}
              


              {this.state.visibletype === "SendEmail" && (
                <select
                  className="form-select-sm select"
                  aria-label="Default select example"
                  onChange={this.handlefaculty}
                >
                  <option defaultValue hidden>Select a Email Template</option>
                  <option value="PredefinedOne">PredefinedOne</option>
                  <option value="Custimised">Custimised</option>
                  <option value="Personal">Personal</option>
                
                </select>
                
              )}
              {this.state.visibletype==="SendEmail"&&(
            <select 
            className="form-select-sm-select"
            aria-label="Default select example"
            onChange={this.handlefaculty}
            >    
                <option defaultValue hidden>select Gate</option>
                <option value="And">And</option>
                <option value="Or">Or</option>
                
            </select>
              )}
              {this.state.visibletype==="SendSms"&&(
                <select
                className="form-select-sm-select"
                aria-label="Default select example"
                onChange={this.handlefaculty}
                >
                    <option defaultValue hidden>select Sms Type</option>
                    <option value="presefined">presefined</option>
                    <option value="Customise">Customise</option>

                </select>
              )}
              {this.state.visibletype==="CallAPI"&&(
                <select
                className="form-select-sm-select"
                aria-label="Default select example"
                onChange={this.handlefaculty}>
                    <option defaultValue hidden> select API</option>
                    <option value="AddNew">AddNew</option>
                    <option value="OldOne">OldOne</option>

                </select>
              )}


              {this.state.visibletype==="SendWhat'sappMessage"&&(
                <select
                className="form-select-sm-select"
                aria-label="Default select example"
                onChange={this.handlefaculty}>
                    <option defaultValue hidden> select API</option>
                    <option value="Predifined">Predefined</option>
                    <option value="Customised">Customised</option>

                </select>
              )}
            </Col>
            </Row>
            </Card.Body>
          </Card>
        
          <Button
            className="button"
            variant="primary"
            onClick={this.handleModal} style={{"border-radius":'100px 100px 100px 100px'}}
          >
            Post
          </Button>
         
        </Row>

        <Modal show={this.state.showModel}>
         <Modal.Header>
            <Modal.Title>Edit Question</Modal.Title>
          </Modal.Header>

          <Modal.Body>
            <textarea
              style={{ width: "29rem" }}
              value={this.state.editPost.message}
              onChange={this.onChangehandler}
            >
              {this.state.editPost.message}
            </textarea>
          </Modal.Body>

          <Modal.Footer>
            <Button variant="secondary" onClick={this.cancleEdit}>
              Close
            </Button>
            <Button variant="primary" onClick={this.updatePost}>
              Save
            </Button>
          </Modal.Footer>
        </Modal>

        <Modal show={this.state.showConfirm}>
          <Modal.Header>
            <Modal.Title>Post Question</Modal.Title>
          </Modal.Header>
          <Modal.Body>Do you want post this Question?</Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={this.handleCloseModal}>
              Close
            </Button>

            <Button variant="danger" onClick={this.handleClick}>
              Post Question
            </Button>
         
          </Modal.Footer>
        </Modal>

        <Modal show={this.state.showDeleteConfirm}>
          <Modal.Header>
            <Modal.Title>Delete Question</Modal.Title>
          </Modal.Header>
          <Modal.Body>Do you want Delete this Question?</Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={this.handleDeleteCloseModal}>
              Close
            </Button>

            <Button variant="danger" onClick={this.deletePost}>
              Delete Question
            </Button>
          </Modal.Footer>
        </Modal>
        
        </Container>
    );
  }
}

export default FarmFunction;