import React from "react";
import { Container,Row,Col,Card, Form,Button,Table } from "react-bootstrap";

  
const EventTrigger =()=>{
  return(


    <Container>
        <Row>
            <h4> EventTrigger Conditions</h4>
            <Card>
              <Card.Header><p>When</p></Card.Header>
              <Card.Body>
                <Row>
                  <Table>
                    <thead>
                      <th> <Col>
                    <Form.Select>
                    <option>TableNames</option>
                    <option>TableOne</option>
                    <option>TableTwo</option>
                    <option>TableThree</option>
                    </Form.Select>
                    </Col></th>
                   <th>
                    <Col>
                    <Form.Select>
                        <option>ColoumnNames</option>
                        <option>ColoumnOne</option>
                        <option>ColoumnTwo</option>
                        <option>ColoumnThree</option>
                    </Form.Select>
                    </Col>
                    </th>
                    <th>

                    
                    <Col>
                    <Form.Select>
                        <option>Operators</option>
                        <option>OperatorsOne</option>
                        <option>OperatorsTwo</option>
                        <option>OperatorsThree</option>
                    </Form.Select>                    
                    </Col>
                    </th>
                    <th>
                    <Col>
                    <Form.Control
                            type="text"
                            placeholder="value"
                            id="inputPassword5"
                            aria-describedby="passwordHelpBlock"
                        />
                    </Col>
                    </th>
                    <th>
                    <Col>
                    <Button variant="danger" className="bi bi-trash3"></Button>
                    <Button variant="success" className="bi bi-plus-circle"></Button></Col>
                    </th>
                    </thead>
                    </Table>
                </Row>
                <br/>
                <Row>
                    <Col lg="2">
                    <Form.Select>
                    <option>And</option>
                    <option>AndOne</option>
                    <option>AndTwo</option>
                    <option>AndThree</option>
                    </Form.Select>
                    </Col>
                </Row>
              </Card.Body>
            </Card>
        </Row>
    </Container>
  )   
}
export default EventTrigger